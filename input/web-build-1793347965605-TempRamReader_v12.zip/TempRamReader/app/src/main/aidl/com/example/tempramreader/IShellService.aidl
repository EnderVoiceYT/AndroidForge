package com.example.tempramreader;

interface IShellService {
    // Reserved transaction code: Shizuku calls this when the service must stop.
    void destroy() = 16777114;

    String exec(String command) = 1;
}
