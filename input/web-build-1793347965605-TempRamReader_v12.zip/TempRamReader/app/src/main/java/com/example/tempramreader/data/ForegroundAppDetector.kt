package com.example.tempramreader.data

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process

object ForegroundAppDetector {
    const val NO_PERMISSION = "Permission Required"
    private const val HOME_FALLBACK = "com.android.systemui"

    // UsageEvents.Event types (numeric values are stable; the *_FOREGROUND/BACKGROUND names are the old aliases)
    private const val EVT_RESUMED = 1                // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
    private const val EVT_PAUSED = 2                 // ACTIVITY_PAUSED  / MOVE_TO_BACKGROUND
    private const val EVT_SCREEN_NON_INTERACTIVE = 16
    private const val EVT_STOPPED = 23               // ACTIVITY_STOPPED
    private const val EVT_SHUTDOWN = 26              // DEVICE_SHUTDOWN

    private val SYSTEM_PACKAGES = setOf("com.android.systemui", "android")

    // Resumed activities, oldest first. Tracked per activity ("pkg/class") because Android 10+ (and
    // Android 16 split-screen / desktop windowing) can have several resumed at once, and two activities
    // of one app must not cancel each other out.
    private val resumed = LinkedHashSet<String>()
    private var lastQueryMs = 0L
    private val labelCache = HashMap<String, String>()

    fun hasUsageStatsPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    @Synchronized
    private fun refresh(context: Context) {
        try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            // First call looks back 24 h to learn what is open now; afterwards only new events are read.
            val from = if (lastQueryMs == 0L) now - 24L * 60 * 60 * 1000 else lastQueryMs
            val events = usm.queryEvents(from, now)
            val event = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val pkg = event.packageName ?: continue
                val key = pkg + "/" + (event.className ?: "")
                when (event.eventType) {
                    EVT_RESUMED -> {
                        resumed.remove(key)
                        resumed.add(key)
                    }
                    EVT_PAUSED, EVT_STOPPED -> resumed.remove(key)
                    EVT_SCREEN_NON_INTERACTIVE, EVT_SHUTDOWN -> resumed.clear()
                }
            }
            lastQueryMs = now - 1000 // small overlap; replaying events is harmless
        } catch (_: Exception) {
        }
    }

    /** Packages with a resumed activity, most recent first. Empty without Usage Access. */
    @Synchronized
    fun getResumedPackages(context: Context): List<String> {
        if (!hasUsageStatsPermission(context)) return emptyList()
        refresh(context)
        return resumed.toList().asReversed()
            .map { it.substringBefore('/') }
            .distinct()
    }

    fun getForegroundApp(context: Context): Pair<String, String> {
        if (!hasUsageStatsPermission(context)) {
            return Pair(NO_PERMISSION, "Grant Usage Access in Settings")
        }
        val pkg = getResumedPackages(context).firstOrNull { it !in SYSTEM_PACKAGES }
            ?: return Pair(HOME_FALLBACK, "System / Home")
        return Pair(pkg, labelFor(context, pkg))
    }

    private fun labelFor(context: Context, pkg: String): String =
        labelCache.getOrPut(pkg) {
            try {
                val pm = context.packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (_: Exception) {
                pkg
            }
        }
}
