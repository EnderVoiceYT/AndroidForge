package com.example.tempramreader.data

enum class DisplayMode { BOTH, TEMP_ONLY, RAM_ONLY }
enum class VisualizationType { BAR, GRAPH }
enum class ThermalStatus { COLD, MEDIUM, HOT }
enum class FpsSource { DISPLAY, GAME }

/** State of the GAME fps reading. Never shows a fake 0: paused / unavailable / calibrating are separate. */
enum class GameFpsState { UNAVAILABLE, CALIBRATING, PAUSED, LIVE, LIVE_ESTIMATED }

data class HardwareMetrics(
    val temperatureCelsius: Float = 0f,
    val isBatteryFallback: Boolean = false,
    val totalRamMb: Long = 1L,
    val usedRamMb: Long = 0L,
    val freeRamMb: Long = 1L,
    val currentFps: Int = 60,            // DISPLAY mode only: this app's own frame callbacks
    val displayHz: Int = 60,
    val tempHistory: List<Float> = emptyList(),
    val ramPercentHistory: List<Float> = emptyList(),
    val fpsHistory: List<Float> = emptyList(),
    // GAME mode (selected game's rendering). Completely separate from currentFps / fpsHistory above.
    val gameFps: Int = 0,
    val gameFpsState: GameFpsState = GameFpsState.UNAVAILABLE,
    val gameFpsHistory: List<Float> = emptyList(),
    val fpsStatus: String = "",
    val fpsSession: FpsSessionStats = FpsSessionStats()
) {
    val fpsIsGame: Boolean
        get() = gameFpsState == GameFpsState.LIVE || gameFpsState == GameFpsState.LIVE_ESTIMATED

    val ramUsageFraction: Float
        get() = (usedRamMb.toFloat() / totalRamMb.coerceAtLeast(1L)).coerceIn(0f, 1f)

    val thermalStatus: ThermalStatus
        get() = when {
            temperatureCelsius < 40f -> ThermalStatus.COLD
            temperatureCelsius < 47f -> ThermalStatus.MEDIUM
            else -> ThermalStatus.HOT
        }

    val isRamHigh: Boolean
        get() = ramUsageFraction >= 0.80f

    val statusQuote: String
        get() = when (thermalStatus) {
            ThermalStatus.COLD -> "Very sigma"
            ThermalStatus.MEDIUM -> "alr don't go far you little shit"
            ThermalStatus.HOT -> "Bro stop making your fucking phone into a heater god"
        }
}

data class OverlaySettings(
    val isOverlayVisible: Boolean = false,
    val showFps: Boolean = true,
    val fpsSource: FpsSource = FpsSource.DISPLAY,
    val displayMode: DisplayMode = DisplayMode.BOTH,
    val visualizationType: VisualizationType = VisualizationType.BAR,
    val pollingIntervalMs: Long = 1000L,
    val overlayWidthDp: Int = 220,
    val overlayHeightDp: Int = 175
)
