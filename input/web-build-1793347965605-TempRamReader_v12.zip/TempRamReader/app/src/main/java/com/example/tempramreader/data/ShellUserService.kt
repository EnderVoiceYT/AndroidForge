package com.example.tempramreader.data

import com.example.tempramreader.IShellService
import kotlin.system.exitProcess

/**
 * Runs inside the Shizuku-started process (shell/root privileges).
 * Needs a public no-argument constructor.
 */
class ShellUserService : IShellService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            val proc = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
            val out = proc.inputStream.bufferedReader().use { it.readText() }.trim()
            val code = proc.waitFor()
            "exit=$code\n$out"
        } catch (t: Throwable) {
            "exit=-1\nerror: ${t.javaClass.simpleName}: ${t.message}"
        }
    }
}
