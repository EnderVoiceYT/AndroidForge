package com.example.tempramreader.data

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.example.tempramreader.IShellService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

/**
 * Uses Shizuku (supported UserService API, no reflection) to run
 * `pm grant <this app> android.permission.DUMP` once.
 * After that the app no longer needs Shizuku: Game FPS works on its own.
 */
object ShizukuHelper {
    enum class State { NOT_RUNNING, NEEDS_PERMISSION, READY }

    private const val REQUEST_CODE = 4242

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() || Shizuku.isPreV11() -> State.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NEEDS_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
    }

    private fun userServiceArgs(context: Context) =
        Shizuku.UserServiceArgs(ComponentName(context.packageName, ShellUserService::class.java.name))
            .daemon(false)
            .processNameSuffix("shell")
            .version(1)

    /** Returns a short message for the UI. */
    suspend fun grantDump(context: Context): String = withContext(Dispatchers.IO) {
        if (state() != State.READY) return@withContext "Shizuku isn't ready."

        val args = userServiceArgs(context)
        val connected = CompletableDeferred<IShellService?>()
        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                connected.complete(
                    if (binder != null && binder.pingBinder()) IShellService.Stub.asInterface(binder) else null
                )
            }

            override fun onServiceDisconnected(name: ComponentName?) {}
        }

        try {
            Shizuku.bindUserService(args, connection)
            val service = withTimeoutOrNull(8_000L) { connected.await() }
                ?: return@withContext "Shizuku shell service didn't start in time."

            val reply = service.exec("pm grant ${context.packageName} android.permission.DUMP")

            if (context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED) {
                "Permission granted. Game FPS is ready."
            } else {
                "Grant didn't work: ${reply.take(140)}"
            }
        } catch (t: Throwable) {
            "Shizuku call failed: ${t.javaClass.simpleName}"
        } finally {
            try {
                Shizuku.unbindUserService(args, connection, true)
            } catch (_: Throwable) {
            }
        }
    }
}
