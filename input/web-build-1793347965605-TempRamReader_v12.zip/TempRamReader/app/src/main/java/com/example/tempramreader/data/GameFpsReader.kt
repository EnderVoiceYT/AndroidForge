package com.example.tempramreader.data

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * GAME fps: measures the selected game's own rendering via SurfaceFlinger (needs the DUMP permission).
 *
 * Strategy A (preferred) - real frame presentation timestamps:
 *     dumpsys SurfaceFlinger --latency <layer>
 *   -> live FPS, average FPS, 1% low, jank from actual per-frame intervals.
 * Strategy B (fallback)  - ESTIMATED from the per-layer frame counter (TimeStats):
 *     dumpsys SurfaceFlinger --timestats -dump
 *   -> frames / second from counter differences. No per-frame data, so no 1% low / jank.
 *
 * Not verified against any other app's method, and not verified on Android 16 devices.
 */
object GameFpsReader {
    class Result(
        val state: GameFpsState,
        val fps: Int = 0,
        val status: String,
        val session: FpsSessionStats? = null,
        val nextDelayMs: Long = 1000L
    )

    private const val NS = 1_000_000_000L
    private const val INVALID_TS = Long.MAX_VALUE
    private const val LAYER_RECHECK_MS = 20_000L
    private const val FRESH_WINDOW_NS = 1_500_000_000L
    private val WHITESPACE = Regex("\\s+")
    private val LAYER_RE = Regex("""(?:layerName|layer_name)\s*[=:]\s*"?([^"\r\n]+?)"?\s*$""")
    private val TOTAL_RE = Regex("""(?:totalFrames|total_frames)\s*[=:]\s*(\d+)""")
    private val TOP_ACTIVITY_RE = Regex("""ACTIVITY\s+([\w.]+)/""")

    private val recorder = FpsSessionRecorder()
    private var sessionPkg: String? = null   // the game the session statistics belong to
    private var currentPkg: String? = null   // the game currently being measured

    // Strategy A state
    private var layer: String? = null
    private var layerPickedAtMs = 0L
    private var useFrameReady = false        // timestamp column locked per layer
    private var lastTs = 0L
    private var staleStreak = 0
    private var latencyStale = false
    private var latencyFailStreak = 0
    private var latencyRetryAtMs = 0L

    // Strategy B state
    private var timeStatsEnabled = false
    private val tsHistory = HashMap<String, ArrayDeque<LongArray>>()   // layer -> [timeNs, totalFrames]

    private var failStreak = 0
    private var diagCaptured = false

    // Cached helpers
    private var homePkg: String? = null
    private var topCachePkg: String? = null
    private var topCacheAtMs = 0L

    /** Text report captured while a game was open but no FPS could be read (for sharing). */
    @Volatile
    var lastDiagnostics: String? = null
        private set

    fun hasPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED

    /** Clears the statistics immediately. The caller publishes the returned empty snapshot. */
    @Synchronized
    fun resetSession(): FpsSessionStats {
        val pkg = currentPkg ?: sessionPkg ?: ""
        recorder.reset(pkg)
        sessionPkg = if (pkg.isEmpty()) null else pkg
        return recorder.snapshot()
    }

    private fun unavailable(status: String) = Result(GameFpsState.UNAVAILABLE, 0, status)

    @Synchronized
    fun sample(context: Context): Result {
        if (!hasPermission(context)) return unavailable("Game FPS needs the DUMP permission.")

        val pkg = pickGamePackage(context)
            ?: return if (ForegroundAppDetector.hasUsageStatsPermission(context)) {
                unavailable("Open a game: no game app is in the foreground.")
            } else {
                unavailable("Grant Usage Access so the app knows which game is open.")
            }

        if (pkg != currentPkg) {
            currentPkg = pkg
            layer = null
            lastTs = 0L
            staleStreak = 0
            latencyStale = false
            latencyFailStreak = 0
            latencyRetryAtMs = 0L
            tsHistory.clear()
            failStreak = 0
            diagCaptured = false
            // The session is NOT reset here: it restarts only when this game actually produces frames.
        }

        val now = System.currentTimeMillis()

        // Strategy A: real frame timestamps
        if (now >= latencyRetryAtMs) {
            latencyStale = false
            val a = sampleLatency(pkg)
            if (a != null && !latencyStale) {
                latencyFailStreak = 0
                failStreak = 0
                return a
            }
            if (latencyStale && a != null) {
                // No new frames on the chosen layer: paused, or the wrong layer?
                // Cross-check with the frame counter before calling it a pause.
                val b = sampleTimeStats(pkg)
                if (b != null && b.state == GameFpsState.LIVE_ESTIMATED) {
                    latencyRetryAtMs = now + 30_000L
                    failStreak = 0
                    return b
                }
                failStreak = 0
                return a
            }
            latencyFailStreak++
            if (latencyFailStreak >= 3) {          // never produced usable data: stop spawning processes for a while
                latencyRetryAtMs = now + 30_000L
                latencyFailStreak = 0
            }
        }

        // Strategy B: estimated from the frame counter
        val b = sampleTimeStats(pkg)
        if (b != null) {
            failStreak = 0
            return b
        }

        failStreak++
        if (failStreak >= 6 && !diagCaptured) {
            lastDiagnostics = buildDiagnostics(context, pkg)
            diagCaptured = true
        }
        return unavailable("No frame data for $pkg. If this stays, tap \"Share diagnostics\" after a minute of play.")
    }

    // ---------------- Which app is the game? ----------------
    private fun pickGamePackage(context: Context): String? {
        val candidates: List<String> =
            if (ForegroundAppDetector.hasUsageStatsPermission(context)) {
                ForegroundAppDetector.getResumedPackages(context)
            } else {
                listOfNotNull(topResumedFromDumpsys())   // backup when Usage Access is missing
            }
        val ignore = ignoredPackages(context)
        return candidates.firstOrNull { it !in ignore }
    }

    private fun ignoredPackages(context: Context): Set<String> {
        if (homePkg == null) {
            homePkg = try {
                val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                context.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
                    ?.activityInfo?.packageName ?: ""
            } catch (_: Exception) {
                ""
            }
        }
        return setOf(context.packageName, "com.android.systemui", "android", homePkg ?: "")
    }

    private fun topResumedFromDumpsys(): String? {
        val now = System.currentTimeMillis()
        if (now - topCacheAtMs < 3_000L) return topCachePkg
        topCacheAtMs = now
        val out = runDumpsys("activity", "top")
        topCachePkg = out?.let { TOP_ACTIVITY_RE.find(it)?.groupValues?.get(1) }
        return topCachePkg
    }

    // ---------------- Strategy A: frame presentation timestamps ----------------
    private fun sampleLatency(pkg: String): Result? {
        val now = System.currentTimeMillis()

        if (layer == null || now - layerPickedAtMs > LAYER_RECHECK_MS) {
            val picked = findLayer(pkg)
            if (picked != null && picked.name != layer) {
                layer = picked.name
                useFrameReady = picked.useFrameReady
                lastTs = 0L
                staleStreak = 0
            }
            // No layer yet: look again in ~3 s instead of waiting a full recheck period.
            layerPickedAtMs = if (picked == null) now - LAYER_RECHECK_MS + 3_000L else now
        }
        val name = layer ?: return null

        val stamps = frameTimes(name, useFrameReady)
        if (stamps.size < 2) {
            staleStreak++
            if (staleStreak >= 3) layer = null
            return null
        }

        val newest = stamps.last()
        if (lastTs == 0L) {
            // First look at this layer: the buffer holds old frames, so only remember where we are.
            lastTs = newest
            return Result(GameFpsState.CALIBRATING, 0, "Game FPS: calibrating $pkg...", recorder.snapshot(), 700L)
        }
        if (newest == lastTs) {
            staleStreak++
            latencyStale = true
            if (staleStreak >= 2) {
                // Maybe the game moved to another surface: look again.
                val p = findLayer(pkg)
                if (p != null && p.name != name) {
                    layer = p.name
                    useFrameReady = p.useFrameReady
                    lastTs = 0L
                    staleStreak = 0
                    latencyStale = false
                    layerPickedAtMs = now
                    return Result(GameFpsState.CALIBRATING, 0, "Game FPS: switching layer...", recorder.snapshot())
                }
            }
            return Result(
                GameFpsState.PAUSED, 0,
                "Game FPS: no new frames from $pkg (paused or loading).",
                recorder.snapshot()
            )
        }
        staleStreak = 0

        // New session only when a different game really produces frames.
        if (sessionPkg != pkg) {
            recorder.reset(pkg)
            sessionPkg = pkg
        }

        // Feed only frames we haven't seen into the statistics.
        var prev: Long? = if (stamps.contains(lastTs)) lastTs else null   // null = we missed frames: skip that interval
        for (t in stamps) {
            if (t <= lastTs) continue
            val p = prev
            if (p != null) recorder.addFrame((t - p) / 1e6)
            prev = t
        }
        lastTs = newest

        // Live FPS: frames presented during the last second
        val inWindow = stamps.filter { it >= newest - NS }
        if (inWindow.size < 2) {
            return Result(GameFpsState.PAUSED, 0, "Game FPS: too few frames from $pkg.", recorder.snapshot())
        }
        val spanSec = max((newest - inWindow.first()) / 1e9, 0.25)
        val fps = ((inWindow.size - 1) / spanSec).roundToInt().coerceIn(1, 1000)
        recorder.addSecondFps(fps)

        val kind = if (useFrameReady) "frame-ready timestamps" else "frame presentation timestamps"
        return Result(
            GameFpsState.LIVE, fps,
            "Game FPS: $pkg ($kind)",
            recorder.snapshot(),
            if (fps >= 100) 700L else 1000L   // the buffer holds ~127 frames: poll faster at high FPS
        )
    }

    private class Picked(val name: String, val useFrameReady: Boolean)
    private class Cand(val name: String, val ready: Boolean, val newest: Long, val fps: Double, val surface: Boolean)

    /**
     * Picks the layer that renders the game: among the package's layers that are producing fresh frames,
     * prefer SurfaceViews and take the one with the highest sustained frame rate.
     */
    private fun findLayer(pkg: String): Picked? {
        val out = runDumpsys("SurfaceFlinger", "--list") ?: return null
        val names = out.lines()
            .map { it.trim() }
            .filter {
                it.contains(pkg) &&
                    !it.startsWith("Background for") && !it.startsWith("Bounds for") &&
                    !it.contains("Splash Screen") && !it.contains("Letterbox")
            }
            .distinct()
            .sortedByDescending { it.startsWith("SurfaceView") }
            .take(12)

        val cands = ArrayList<Cand>()
        for (n in names) {
            val (present, ready) = parseLatency(runDumpsys("SurfaceFlinger", "--latency", n) ?: continue)
            val useReady = present.size < 2
            val st = if (useReady) ready else present
            if (st.size < 2) continue
            val newest = st.last()
            val win = st.filter { it >= newest - NS }
            val spanSec = max((newest - win.first()) / 1e9, 0.25)
            val fps = if (win.size >= 2) (win.size - 1) / spanSec else 0.0
            cands.add(Cand(n, useReady, newest, fps, n.startsWith("SurfaceView")))
        }
        if (cands.isEmpty()) return null

        val freshest = cands.maxOf { it.newest }
        val fresh = cands.filter { it.newest >= freshest - FRESH_WINDOW_NS }
        val pool = fresh.filter { it.surface && it.fps >= 10.0 }.ifEmpty { fresh }
        val best = pool.maxByOrNull { it.fps } ?: return null
        return Picked(best.name, best.ready)
    }

    /** Returns (actualPresentTimes, frameReadyTimes), each in ns and ascending. */
    private fun parseLatency(out: String): Pair<List<Long>, List<Long>> {
        val present = ArrayList<Long>()
        val ready = ArrayList<Long>()
        out.lineSequence().drop(1).forEach { line ->   // line 0 is the refresh period
            val parts = line.trim().split(WHITESPACE)
            if (parts.size >= 3) {
                parts[1].toLongOrNull()?.let { if (it > 0L && it != INVALID_TS) present.add(it) }
                parts[2].toLongOrNull()?.let { if (it > 0L && it != INVALID_TS) ready.add(it) }
            }
        }
        return Pair(present.sorted(), ready.sorted())
    }

    /** Timestamps for one layer, always from the same column so intervals stay consistent between polls. */
    private fun frameTimes(layerName: String, frameReady: Boolean): List<Long> {
        val out = runDumpsys("SurfaceFlinger", "--latency", layerName) ?: return emptyList()
        val (present, ready) = parseLatency(out)
        return if (frameReady) ready else present
    }

    // ---------------- Strategy B: ESTIMATED from the frame counter ----------------
    private fun sampleTimeStats(pkg: String): Result? {
        if (!timeStatsEnabled) {
            runDumpsys("SurfaceFlinger", "--timestats", "-enable")
            timeStatsEnabled = true
        }
        val t0 = SystemClock.elapsedRealtimeNanos()
        val out = runDumpsys("SurfaceFlinger", "--timestats", "-dump", "-maxlayers", "50") ?: return null
        val t1 = SystemClock.elapsedRealtimeNanos()

        val totals = parseTimeStats(out, pkg)
        if (totals.isEmpty()) {
            timeStatsEnabled = false   // maybe it was switched off: re-enable on the next try
            return null
        }
        // The counters were read somewhere inside the dumpsys call: use its midpoint as the time.
        val tMid = (t0 + t1) / 2

        if (tsHistory.size > 100) tsHistory.clear()
        var bestFps = -1.0
        var stepFrames = 0L
        var stepSec = 0.0
        for ((name, total) in totals) {
            val hist = tsHistory.getOrPut(name) { ArrayDeque() }
            hist.addLast(longArrayOf(tMid, total))
            while (hist.size > 1 && tMid - hist.first()[0] > 2_200_000_000L) hist.removeFirst()
            if (hist.size < 2) continue

            val first = hist.first()
            val dt = (tMid - first[0]) / 1e9
            val d = total - first[1]
            if (dt < 0.5 || d < 0) continue
            val f = d / dt
            if (f > bestFps) {
                bestFps = f
                val prev = hist[hist.size - 2]
                stepFrames = total - prev[1]
                stepSec = (tMid - prev[0]) / 1e9
            }
        }

        if (bestFps < 0.0) {
            return Result(GameFpsState.CALIBRATING, 0, "Game FPS: calibrating (estimated, frame counter)...")
        }
        if (bestFps < 1.0) {
            return Result(
                GameFpsState.PAUSED, 0,
                "Game FPS: no new frames from $pkg (paused or loading).",
                recorder.snapshot()
            )
        }

        if (sessionPkg != pkg) {
            recorder.reset(pkg)
            sessionPkg = pkg
        }
        val fps = bestFps.roundToInt().coerceIn(1, 1000)
        recorder.addCounterDelta(stepFrames, stepSec)
        recorder.addSecondFps(fps)
        return Result(
            GameFpsState.LIVE_ESTIMATED, fps,
            "Game FPS ESTIMATED from the frame counter ($pkg). No per-frame data: 1% low and jank unavailable.",
            recorder.snapshot()
        )
    }

    private fun parseTimeStats(out: String, pkg: String): Map<String, Long> {
        val result = HashMap<String, Long>()
        var cur: String? = null
        for (line in out.lineSequence()) {
            val t = line.trim()
            val lm = LAYER_RE.find(t)
            if (lm != null) {
                cur = lm.groupValues[1]
                continue
            }
            val tm = TOTAL_RE.find(t)
            val c = cur
            if (tm != null && c != null) {
                if (c.contains(pkg)) {
                    val v = tm.groupValues[1].toLongOrNull()
                    if (v != null) result[c] = v
                }
                cur = null
            }
        }
        return result
    }

    // ---------------- Diagnostics ----------------
    private fun buildDiagnostics(context: Context, pkg: String): String {
        val sb = StringBuilder()
        sb.appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("DUMP granted: ${hasPermission(context)}")
        sb.appendLine("Usage Access: ${ForegroundAppDetector.hasUsageStatsPermission(context)}")
        sb.appendLine("Game package: $pkg")
        sb.appendLine("Resumed packages: ${ForegroundAppDetector.getResumedPackages(context)}")

        val list = runDumpsys("SurfaceFlinger", "--list")
        if (list == null) {
            sb.appendLine("--list: failed to run")
        } else {
            val lines = list.lines()
            val matches = lines.filter { it.contains(pkg) }
            sb.appendLine("--list: ${lines.size} lines, ${matches.size} match the package")
            lines.take(3).forEach { sb.appendLine("  list head: ${it.take(100)}") }
            for (m in matches.take(8)) {
                sb.appendLine("LAYER: ${m.take(160)}")
                val lat = runDumpsys("SurfaceFlinger", "--latency", m.trim())
                sb.appendLine("  latency: " + (lat?.lines()?.take(5)?.joinToString(" | ") { it.take(70) } ?: "failed"))
            }
        }

        val ts = runDumpsys("SurfaceFlinger", "--timestats", "-dump", "-maxlayers", "50")
        if (ts == null) {
            sb.appendLine("timestats: failed to run")
        } else {
            sb.appendLine("timestats: ${ts.length} chars")
            ts.lines()
                .filter { it.contains(pkg) || it.contains("otalFrames") || it.contains("otal_frames") || it.contains("ayer") }
                .take(25)
                .forEach { sb.appendLine("  ${it.trim().take(120)}") }
        }
        return sb.toString()
    }

    private fun runDumpsys(vararg args: String): String? {
        var proc: Process? = null
        return try {
            proc = ProcessBuilder(listOf("dumpsys") + args).redirectErrorStream(true).start()
            proc.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            proc?.destroy()
        }
    }
}
