package com.example.tempramreader.data

import android.app.AppOpsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Process
import android.app.usage.UsageStatsManager
import android.os.Build

object ForegroundAppDetector {
    fun hasUsageStatsPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun getForegroundApp(context: Context): Pair<String, String> {
        if (!hasUsageStatsPermission(context)) {
            return Pair("Permission Required", "Grant Usage Access in Settings")
        }

        try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val time = System.currentTimeMillis()
            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, time - 10000, time)
            
            if (!stats.isNullOrEmpty()) {
                val sortedStats = stats.sortedBy { it.lastTimeUsed }
                val recent = sortedStats.lastOrNull { it.totalTimeInForeground > 0 || it.lastTimeUsed > 0 }
                if (recent != null) {
                    val pkg = recent.packageName
                    val pm = context.packageManager
                    val ai = try {
                        pm.getApplicationInfo(pkg, 0)
                    } catch (_: Exception) {
                        null
                    }
                    val appName = if (ai != null) pm.getApplicationLabel(ai).toString() else pkg
                    return Pair(pkg, appName)
                }
            }
        } catch (_: Exception) {}

        return Pair("com.android.systemui", "System / Home")
    }
}
