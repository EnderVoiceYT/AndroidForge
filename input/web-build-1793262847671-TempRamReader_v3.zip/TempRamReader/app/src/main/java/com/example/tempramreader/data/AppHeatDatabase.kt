package com.example.tempramreader.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [AppHeatEntity::class], version = 1, exportSchema = false)
abstract class AppHeatDatabase : RoomDatabase() {
    abstract fun appHeatDao(): AppHeatDao

    companion object {
        @Volatile
        private var INSTANCE: AppHeatDatabase? = null

        fun getDatabase(context: Context): AppHeatDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppHeatDatabase::class.java,
                    "app_heat_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
