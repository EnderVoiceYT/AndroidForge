package com.example.tempramreader.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

data class AppHeatSummary(
    val packageName: String,
    val appName: String,
    val sampleCount: Int,
    val avgTemp: Float,
    val peakTemp: Float,
    val totalDurationMinutes: Int
)

@Dao
interface AppHeatDao {
    @Insert
    suspend fun insertSample(sample: AppHeatEntity)

    @Query("""
        SELECT packageName, appName, 
               COUNT(*) as sampleCount, 
               AVG(temperatureCelsius) as avgTemp, 
               MAX(temperatureCelsius) as peakTemp,
               (COUNT(*) * 1) as totalDurationMinutes
        FROM app_heat_samples 
        GROUP BY packageName 
        ORDER BY peakTemp DESC
    """)
    fun getAppHeatSummaries(): Flow<List<AppHeatSummary>>

    @Query("DELETE FROM app_heat_samples")
    suspend fun clearHistory()
}
