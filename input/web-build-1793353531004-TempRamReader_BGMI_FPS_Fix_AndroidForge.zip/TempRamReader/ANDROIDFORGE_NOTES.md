# TempRamReader v13 — AndroidForge source (BGMI Real-Time FPS Fix)

This archive preserves the AndroidForge project structure and package name (`com.example.tempramreader`). Upload the ZIP to AndroidForge and build the `app` module / debug APK as usual.

## BGMI (`com.pubg.imobile`) Real-Time FPS Diagnostic & Acquisition Fixes

1. **Detailed SurfaceFlinger Diagnostic (Executed First & On-Demand)**:
   - **Complete TimeStats Search**: Queries the complete `SurfaceFlinger --timestats` dump without the previous `-maxlayers 50` truncation (and flushes in-flight `mTimeStatsTracker` records via `-disable -dump` + `-enable`) to find all `com.pubg.imobile` layer records across the entire output.
   - **Dynamic BGMI BLAST SurfaceView Discovery**: Discovers the current active BGMI BLAST `SurfaceView` layer (`SurfaceView[com.pubg.imobile/com.epicgames.ue4.GameActivity](BLAST)#<seq>` and `SurfaceViewcom.pubg.imobile/com.epicgames.ue4.GameActivity#<seq>`), ranking by `SurfaceView`, `(BLAST)`, `GameActivity`, live `--list` presence, and highest `#<sequence>` ID.
   - **Layer-Specific `--latency` Query & Header Separation**: Executes `dumpsys SurfaceFlinger --latency <exact_layer_name>` (with automatic Shizuku UID 2000 shell fallback if direct `untrusted_app` dumpsys is restricted by Android 16 SELinux) and parses the single-integer refresh-period header strictly separately from the 3-column frame timestamp rows (`desiredPresentTime`, `actualPresentTime`, `frameReadyTime`).
   - **Two-Sample 2-Second Verification**: Takes Sample 1 and Sample 2 two seconds apart, reporting valid non-zero timestamp counts in each sample and how many new timestamps appeared.
   - **Structured Failure Logging**: Logs and reports exact failure reasons (`EMPTY_DATA`, `PERMISSION_ERROR`, `UNRECOGNIZED_OUTPUT`, `NO_VALID_TIMESTAMPS`, `NO_NEW_TIMESTAMPS`, `NO_MATCHING_LAYER`).
2. **Real-Time FPS Acquisition**:
   - **Primary**: Uses actual presentation timestamps (`actualPresentTime`, column 2) from `SurfaceFlinger --latency <exact_layer_name>` whenever valid advancing presentation timestamps are available.
   - **Fallback**: Uses the BGMI-specific `TimeStats` `totalFrames` counter delta on the active BGMI `SurfaceView` layer only when presentation timestamps are unavailable, dynamically tracking all BGMI layers so recreated `SurfaceView` instances (`#<seq>`) are picked up immediately.
   - **Guardrails**: Never uses display refresh rate as game FPS, never fabricates an FPS value, and preserves floating HUD refresh-rate behavior and existing UI.
