package com.example.tempramreader.data

/** Summary of one game session. Values without frame timings are estimates from TimeStats windows. */
data class FpsSessionStats(
    val pkg: String = "",
    val avgFps: Float = 0f,
    val lowFps1: Float = 0f,
    val minFps: Int = 0,
    val maxFps: Int = 0,
    val jank: Int = 0,
    val bigJank: Int = 0,
    val seconds: Int = 0,
    /** True only when intervals between individual frame timestamps were collected. */
    val frameTimingsAvailable: Boolean = false,
    /** A genuine 1% low needs a sufficiently large set of individual frame intervals. */
    val onePercentLowAvailable: Boolean = false,
    /** True when the average is based on TimeStats frame-counter deltas, not frame timestamps. */
    val averageIsEstimated: Boolean = false
)

private const val BIN_MS = 0.1
private const val BINS = 10000 // 0.1 ms bins up to 1000 ms

class FpsSessionRecorder {
    private val hist = LongArray(BINS + 1)
    private var pkg = ""
    private var startMs = System.currentTimeMillis()
    private var frames = 0L
    private var totalMs = 0.0
    private var estimatedFrames = 0L
    private var estimatedMs = 0.0
    private var minFps = Int.MAX_VALUE
    private var maxFps = 0
    private var jank = 0
    private var bigJank = 0
    private var fpsSum = 0.0
    private var fpsSamples = 0
    private val last3 = DoubleArray(3)
    private var last3Count = 0
    private var last3Pos = 0

    @Synchronized
    fun reset(newPkg: String) {
        hist.fill(0L)
        pkg = newPkg
        startMs = System.currentTimeMillis()
        frames = 0L
        totalMs = 0.0
        estimatedFrames = 0L
        estimatedMs = 0.0
        minFps = Int.MAX_VALUE
        maxFps = 0
        jank = 0
        bigJank = 0
        fpsSum = 0.0
        fpsSamples = 0
        last3Count = 0
        last3Pos = 0
    }

    /** Records one measured interval between two individual frame timestamps. */
    @Synchronized
    fun addFrame(dtMs: Double) {
        if (!dtMs.isFinite() || dtMs <= 0.0) return
        if (dtMs > 1000.0) {
            last3Count = 0 // pause/loading gap: do not count it as a slow frame
            return
        }
        frames++
        totalMs += dtMs
        hist[(dtMs / BIN_MS).toInt().coerceIn(0, BINS)]++

        if (last3Count == 3) {
            val avg = (last3[0] + last3[1] + last3[2]) / 3.0
            if (dtMs > 2.0 * avg && dtMs > 20.0) {
                jank++
                if (dtMs > 3.0 * avg && dtMs > 50.0) bigJank++
            }
        }
        last3[last3Pos] = dtMs
        last3Pos = (last3Pos + 1) % 3
        if (last3Count < 3) last3Count++
    }

    /**
     * Records a TimeStats counter delta over a known sample window. This gives a
     * time-weighted average, but cannot provide per-frame 1% lows or jank.
     */
    @Synchronized
    fun addEstimatedBatch(frameCount: Long, elapsedMs: Double, sampleFps: Int) {
        if (frameCount < 0L || !elapsedMs.isFinite() || elapsedMs <= 0.0) return
        if (frameCount > 0L) {
            estimatedFrames += frameCount
            estimatedMs += elapsedMs
        }
        addSecondFps(sampleFps)
    }

    /** One poll-window FPS reading, used for sampled minimum / maximum and fallback average. */
    @Synchronized
    fun addSecondFps(fps: Int) {
        if (fps <= 0) return
        if (fps < minFps) minFps = fps
        if (fps > maxFps) maxFps = fps
        fpsSum += fps
        fpsSamples++
    }

    @Synchronized
    fun snapshot(): FpsSessionStats {
        val combinedFrames = frames + estimatedFrames
        val combinedMs = totalMs + estimatedMs
        val intervalAverageAvailable = combinedFrames > 20L && combinedMs > 0.0
        val avg = when {
            intervalAverageAvailable -> combinedFrames * 1000.0 / combinedMs
            fpsSamples > 0 -> fpsSum / fpsSamples
            else -> 0.0
        }

        val completeFrameTimingCoverage = frames > 0L && estimatedFrames == 0L
        val lowAvailable = frames >= 100L && estimatedFrames == 0L
        val low = if (lowAvailable) {
            val target = ((frames + 99L) / 100L).coerceAtLeast(1L)
            var accumulated = 0L
            var index = BINS
            while (index >= 0) {
                accumulated += hist[index]
                if (accumulated >= target) break
                index--
            }
            1000.0 / ((index.coerceAtLeast(0) + 1) * BIN_MS)
        } else 0.0

        return FpsSessionStats(
            pkg = pkg,
            avgFps = avg.toFloat(),
            lowFps1 = low.toFloat(),
            minFps = if (minFps == Int.MAX_VALUE) 0 else minFps,
            maxFps = maxFps,
            jank = jank,
            bigJank = bigJank,
            seconds = ((System.currentTimeMillis() - startMs) / 1000L).toInt(),
            frameTimingsAvailable = completeFrameTimingCoverage,
            onePercentLowAvailable = lowAvailable,
            averageIsEstimated = estimatedFrames > 0L || !intervalAverageAvailable
        )
    }
}
