package com.example.tempramreader.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit

/**
 * Uses Shizuku to grant `android.permission.DUMP` and optionally execute
 * privileged shell `dumpsys SurfaceFlinger` commands as UID 2000 (`shell`)
 * when Android 16+ SELinux restricts direct untrusted_app dumpsys calls.
 */
object ShizukuHelper {
    enum class State { NOT_RUNNING, NEEDS_PERMISSION, READY }

    data class ShellExecResult(
        val stdout: String,
        val stderr: String,
        val exitCode: Int,
        val error: String? = null
    )

    private const val REQUEST_CODE = 4242

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() || Shizuku.isPreV11() -> State.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NEEDS_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
    }

    // Shizuku.newProcess is private in API 13+, so it is called through reflection (a common approach).
    private fun newShellProcess(command: Array<String>): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, command, null, null) as Process
    }

    /**
     * Executes a command directly via Shizuku's privileged shell process (UID 2000) when READY.
     * Passing the command array directly avoids shell word-splitting or '#' comment truncation
     * on SurfaceFlinger layer names like `SurfaceView[com.pubg.imobile/...](BLAST)#2852`.
     */
    fun execProcess(command: Array<String>, timeoutMs: Long = 4000L): ShellExecResult? {
        if (state() != State.READY) return null
        var proc: Process? = null
        return try {
            proc = newShellProcess(command)
            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()
            val outThread = Thread {
                try {
                    proc.inputStream.bufferedReader().use { stdoutBuilder.append(it.readText()) }
                } catch (_: Throwable) {
                }
            }
            val errThread = Thread {
                try {
                    proc.errorStream.bufferedReader().use { stderrBuilder.append(it.readText()) }
                } catch (_: Throwable) {
                }
            }
            outThread.start()
            errThread.start()
            val finished = proc.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!finished) {
                proc.destroyForcibly()
            }
            outThread.join(500L)
            errThread.join(500L)
            ShellExecResult(
                stdout = stdoutBuilder.toString(),
                stderr = stderrBuilder.toString(),
                exitCode = if (finished) proc.exitValue() else -1,
                error = if (finished) null else "Timed out after ${timeoutMs}ms"
            )
        } catch (t: Throwable) {
            ShellExecResult(
                stdout = "",
                stderr = "",
                exitCode = -1,
                error = "${t.javaClass.simpleName}: ${t.message ?: "unknown error"}"
            )
        } finally {
            try {
                proc?.destroy()
            } catch (_: Throwable) {
            }
        }
    }

    /** Returns a short message for the UI. */
    suspend fun grantDump(context: Context): String = withContext(Dispatchers.IO) {
        if (state() != State.READY) return@withContext "Shizuku isn't ready."
        var proc: Process? = null
        try {
            val cmd = arrayOf("sh", "-c", "pm grant ${context.packageName} android.permission.DUMP")
            proc = newShellProcess(cmd)
            val output = proc.inputStream.bufferedReader().use { it.readText() }.trim()
            val err = proc.errorStream.bufferedReader().use { it.readText() }.trim()
            proc.waitFor()
            if (context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED) {
                "Permission granted. Game FPS is ready."
            } else {
                "Grant didn't work: ${(err.ifEmpty { output }).take(120).ifEmpty { "no output" }}"
            }
        } catch (t: Throwable) {
            "Shizuku call failed: ${t.javaClass.simpleName}"
        } finally {
            proc?.destroy()
        }
    }
}
