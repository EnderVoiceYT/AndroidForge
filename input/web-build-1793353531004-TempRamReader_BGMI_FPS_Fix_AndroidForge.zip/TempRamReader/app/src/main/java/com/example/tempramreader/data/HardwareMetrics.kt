package com.example.tempramreader.data

enum class DisplayMode { BOTH, TEMP_ONLY, RAM_ONLY }
enum class VisualizationType { BAR, GRAPH }
enum class ThermalStatus { COLD, MEDIUM, HOT }
enum class FpsSource { DISPLAY, GAME }

data class HardwareMetrics(
    val temperatureCelsius: Float = 0f,
    val isBatteryFallback: Boolean = false,
    val totalRamMb: Long = 1L,
    val usedRamMb: Long = 0L,
    val freeRamMb: Long = 1L,
    val currentFps: Int = 60,
    val displayHz: Int = 60,
    val tempHistory: List<Float> = emptyList(),
    val ramPercentHistory: List<Float> = emptyList(),
    val fpsHistory: List<Float> = emptyList(),
    val fpsIsGame: Boolean = false,
    val fpsStatus: String = "",
    val fpsSession: FpsSessionStats = FpsSessionStats()
) {
    val ramUsageFraction: Float
        get() = (usedRamMb.toFloat() / totalRamMb.coerceAtLeast(1L)).coerceIn(0f, 1f)

    val thermalStatus: ThermalStatus
        get() = when {
            temperatureCelsius < 40f -> ThermalStatus.COLD
            temperatureCelsius < 47f -> ThermalStatus.MEDIUM
            else -> ThermalStatus.HOT
        }

    val isRamHigh: Boolean
        get() = ramUsageFraction >= 0.80f

    val statusQuote: String
        get() = when (thermalStatus) {
            ThermalStatus.COLD -> "Very sigma"
            ThermalStatus.MEDIUM -> "alr don't go far you little shit"
            ThermalStatus.HOT -> "Bro stop making your fucking phone into a heater god"
        }
}

data class OverlaySettings(
    val isOverlayVisible: Boolean = false,
    val showFps: Boolean = true,
    val fpsSource: FpsSource = FpsSource.DISPLAY,
    val displayMode: DisplayMode = DisplayMode.BOTH,
    val visualizationType: VisualizationType = VisualizationType.BAR,
    val pollingIntervalMs: Long = 1000L,
    val overlayWidthDp: Int = 220,
    val overlayHeightDp: Int = 175
)
