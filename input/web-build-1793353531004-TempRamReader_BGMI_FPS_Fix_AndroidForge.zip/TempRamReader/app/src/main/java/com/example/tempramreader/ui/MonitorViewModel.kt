package com.example.tempramreader.ui

import androidx.lifecycle.ViewModel
import com.example.tempramreader.data.*
import kotlinx.coroutines.flow.StateFlow

class MonitorViewModel : ViewModel() {
    val metrics: StateFlow<HardwareMetrics> = HardwareRepository.metrics
    val settings: StateFlow<OverlaySettings> = HardwareRepository.settings
    val hasShownFallbackDialog: StateFlow<Boolean> = HardwareRepository.hasShownFallbackDialog

    fun toggleOverlay(enabled: Boolean) {
        HardwareRepository.updateSettings { it.copy(isOverlayVisible = enabled) }
    }

    fun toggleFps(enabled: Boolean) {
        HardwareRepository.updateSettings { it.copy(showFps = enabled) }
    }

    fun setFpsSource(source: FpsSource) {
        HardwareRepository.updateSettings { it.copy(fpsSource = source) }
    }

    fun setDisplayMode(mode: DisplayMode) {
        HardwareRepository.updateSettings { it.copy(displayMode = mode) }
    }

    fun setVisualizationType(type: VisualizationType) {
        HardwareRepository.updateSettings { it.copy(visualizationType = type) }
    }

    fun setPollingInterval(intervalMs: Long) {
        HardwareRepository.updateSettings { it.copy(pollingIntervalMs = intervalMs) }
    }

    fun setOverlayDimensions(widthDp: Int, heightDp: Int) {
        HardwareRepository.updateSettings {
            it.copy(overlayWidthDp = widthDp, overlayHeightDp = heightDp)
        }
    }

    fun dismissFallbackDialog() {
        HardwareRepository.markFallbackDialogShown()
    }
}
