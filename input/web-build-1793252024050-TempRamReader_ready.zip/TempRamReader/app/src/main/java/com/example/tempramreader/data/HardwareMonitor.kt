package com.example.tempramreader.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.view.Choreographer
import android.view.Display
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

object HardwareRepository {
    private val _metrics = MutableStateFlow(HardwareMetrics())
    val metrics: StateFlow<HardwareMetrics> = _metrics.asStateFlow()

    private val _settings = MutableStateFlow(OverlaySettings())
    val settings: StateFlow<OverlaySettings> = _settings.asStateFlow()

    private val _hasShownFallbackDialog = MutableStateFlow(false)
    val hasShownFallbackDialog: StateFlow<Boolean> = _hasShownFallbackDialog.asStateFlow()

    private var frameCount = 0
    private var lastFpsTimestampNanos = 0L
    private var isFpsTracking = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isFpsTracking) return
            if (lastFpsTimestampNanos == 0L) lastFpsTimestampNanos = frameTimeNanos
            frameCount++

            val elapsedNanos = frameTimeNanos - lastFpsTimestampNanos
            if (elapsedNanos >= 500_000_000L) {
                val calculatedFps = ((frameCount * 1_000_000_000L) / elapsedNanos).toInt()
                _metrics.update { current ->
                    val clampedFps = calculatedFps.coerceIn(1, current.displayHz.coerceAtLeast(144))
                    current.copy(
                        currentFps = clampedFps,
                        fpsHistory = (current.fpsHistory + clampedFps.toFloat()).takeLast(30)
                    )
                }
                frameCount = 0
                lastFpsTimestampNanos = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun startFpsTracker() {
        if (isFpsTracking) return
        isFpsTracking = true
        frameCount = 0
        lastFpsTimestampNanos = 0L
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    fun stopFpsTracker() {
        isFpsTracking = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    fun updateSettings(transform: (OverlaySettings) -> OverlaySettings) {
        _settings.update(transform)
    }

    fun markFallbackDialogShown() {
        _hasShownFallbackDialog.value = true
    }

    suspend fun pollHardware(context: Context) = withContext(Dispatchers.IO) {
        val (temp, isFallback) = readTemperature(context)
        val (totalMb, usedMb, freeMb) = readRam(context)
        val hz = readDisplayRefreshRate(context)

        _metrics.update { current ->
            val ramPct = (usedMb.toFloat() / totalMb.coerceAtLeast(1L)) * 100f
            current.copy(
                temperatureCelsius = temp,
                isBatteryFallback = isFallback,
                totalRamMb = totalMb,
                usedRamMb = usedMb,
                freeRamMb = freeMb,
                displayHz = hz,
                tempHistory = (current.tempHistory + temp).takeLast(30),
                ramPercentHistory = (current.ramPercentHistory + ramPct).takeLast(30)
            )
        }
    }

    private fun readDisplayRefreshRate(context: Context): Int {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        return display?.refreshRate?.roundToInt() ?: 60
    }

    private fun readTemperature(context: Context): Pair<Float, Boolean> {
        val thermalDir = File("/sys/class/thermal")
        val targetTypes = listOf("cpu", "soc", "tsens", "ap", "mtktscpu", "xo_therm")

        if (thermalDir.exists() && thermalDir.canRead()) {
            val zones = thermalDir.listFiles { file -> file.name.startsWith("thermal_zone") }
            val validTemps = mutableListOf<Float>()

            zones?.forEach { zone ->
                try {
                    val typeFile = File(zone, "type")
                    val tempFile = File(zone, "temp")
                    if (typeFile.canRead() && tempFile.canRead()) {
                        val type = typeFile.readText().trim().lowercase()
                        if (targetTypes.any { type.contains(it) }) {
                            val raw = tempFile.readText().trim().toFloatOrNull()
                            if (raw != null) {
                                val normalized = if (raw > 1000f) raw / 1000f else if (raw > 200f) raw / 10f else raw
                                if (normalized in 15f..115f) validTemps.add(normalized)
                            }
                        }
                    }
                } catch (_: Exception) { }
            }
            if (validTemps.isNotEmpty()) return Pair(validTemps.average().toFloat(), false)
        }

        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawBatteryTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        return Pair(rawBatteryTemp / 10f, true)
    }

    private fun readRam(context: Context): Triple<Long, Long, Long> {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val totalMb = memoryInfo.totalMem / (1024 * 1024)
        val freeMb = memoryInfo.availMem / (1024 * 1024)
        val usedMb = totalMb - freeMb
        return Triple(totalMb, usedMb, freeMb)
    }
}
