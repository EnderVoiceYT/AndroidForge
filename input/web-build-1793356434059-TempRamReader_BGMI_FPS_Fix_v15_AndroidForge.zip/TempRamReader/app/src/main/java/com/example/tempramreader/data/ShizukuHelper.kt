package com.example.tempramreader.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import moe.shizuku.server.IRemoteProcess
import moe.shizuku.server.IShizukuService
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess
import java.lang.reflect.InvocationTargetException

/**
 * Executes privileged shell commands (UID 2000 `shell` / UID 0 `root`) through Shizuku's
 * remote process API (`Shizuku.newProcess` / `IShizukuService.newProcess`).
 */
object ShizukuHelper {
    private const val TAG = "ShizukuHelper"
    private const val REQUEST_CODE = 4242

    enum class State { NOT_RUNNING, NEEDS_PERMISSION, READY }

    data class AuthorizationReport(
        val state: State,
        val binderAlive: Boolean,
        val isPreV11: Boolean,
        val permissionGranted: Boolean,
        val serverUid: Int,
        val serverVersion: Int,
        val selinuxContext: String?,
        val error: String? = null
    )

    data class ShellExecResult(
        val commandDisplay: String,
        val stdout: String,
        val stderr: String,
        val exitCode: Int,
        val processCreated: Boolean,
        val timedOut: Boolean = false,
        val error: String? = null
    )

    data class ShellIdentityConfirmation(
        val confirmed: Boolean,
        val auth: AuthorizationReport,
        val identityOutput: String,
        val sfProbeResult: ShellExecResult?,
        val failureReason: String?
    )

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() || Shizuku.isPreV11() -> State.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NEEDS_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun inspectAuthorization(): AuthorizationReport {
        return try {
            val alive = Shizuku.pingBinder()
            if (!alive) {
                return AuthorizationReport(
                    state = State.NOT_RUNNING,
                    binderAlive = false,
                    isPreV11 = false,
                    permissionGranted = false,
                    serverUid = -1,
                    serverVersion = -1,
                    selinuxContext = null,
                    error = "Shizuku binder is not alive (pingBinder=false)."
                )
            }
            val preV11 = Shizuku.isPreV11()
            val granted = !preV11 && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            val uid = try { Shizuku.getUid() } catch (_: Throwable) { -1 }
            val ver = try { Shizuku.getVersion() } catch (_: Throwable) { -1 }
            val ctx = try { Shizuku.getSELinuxContext() } catch (_: Throwable) { null }
            val st = when {
                preV11 -> State.NOT_RUNNING
                granted -> State.READY
                else -> State.NEEDS_PERMISSION
            }
            AuthorizationReport(
                state = st,
                binderAlive = true,
                isPreV11 = preV11,
                permissionGranted = granted,
                serverUid = uid,
                serverVersion = ver,
                selinuxContext = ctx,
                error = if (granted) null else "Shizuku user authorization not granted (checkSelfPermission != PERMISSION_GRANTED)."
            )
        } catch (t: Throwable) {
            val unwrapped = unwrapThrowable(t)
            AuthorizationReport(
                state = State.NOT_RUNNING,
                binderAlive = false,
                isPreV11 = false,
                permissionGranted = false,
                serverUid = -1,
                serverVersion = -1,
                selinuxContext = null,
                error = "${unwrapped.javaClass.simpleName}: ${unwrapped.message ?: "unknown error"}"
            )
        }
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
    }

    private fun unwrapThrowable(t: Throwable): Throwable =
        if (t is InvocationTargetException && t.targetException != null) t.targetException else t

    /**
     * Creates a remote process via Shizuku's remote process API.
     * Primary: `Shizuku.newProcess(String[], String[], String)` -> `ShizukuRemoteProcess`.
     * Fallback: `Shizuku.requireService().newProcess(...)` wrapped in `ShizukuRemoteProcess`.
     */
    private fun createRemoteProcess(command: Array<String>): Process {
        try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val proc = m.invoke(null, command, null, null) as? Process
            if (proc != null) return proc
        } catch (t: Throwable) {
            val real = unwrapThrowable(t)
            Log.w(TAG, "Shizuku.newProcess reflection failed, trying requireService(): ${real.javaClass.simpleName}: ${real.message}")
            try {
                val reqMethod = Shizuku::class.java.getDeclaredMethod("requireService")
                reqMethod.isAccessible = true
                val service = reqMethod.invoke(null) as? IShizukuService
                val remote: IRemoteProcess? = service?.newProcess(command, null, null)
                if (remote != null) {
                    val ctor = ShizukuRemoteProcess::class.java.getDeclaredConstructor(IRemoteProcess::class.java)
                    ctor.isAccessible = true
                    return ctor.newInstance(remote)
                }
            } catch (fallbackErr: Throwable) {
                throw unwrapThrowable(fallbackErr)
            }
            throw real
        }
        throw IllegalStateException("Shizuku.newProcess returned null Process instance")
    }

    /**
     * Quotes a single argument for POSIX `sh -c` so special characters in SurfaceFlinger
     * layer names (`[`, `]`, `(`, `)`, `#`, spaces) are never interpreted by the shell.
     */
    fun shellQuote(arg: String): String = "'" + arg.replace("'", "'\\''") + "'"

    /**
     * Executes a command through Shizuku's remote shell (`sh -c '<arg1>' '<arg2>' ...`).
     *
     * IMPORTANT: `ShizukuRemoteProcess` does NOT override `java.lang.Process.waitFor(long, TimeUnit)`.
     * Calling `Process.waitFor(long, TimeUnit)` immediately invokes `exitValue()`, which throws
     * `RuntimeException` across Binder IPC while the remote process is still running.
     * Therefore, we always use the 0-arg `proc.waitFor()` on a dedicated waiter thread with
     * `waitThread.join(timeoutMs)` and drain `stdout` and `stderr` on separate reader threads.
     */
    fun execShellArgs(args: List<String>, timeoutMs: Long = 5000L): ShellExecResult {
        val displayCmd = args.joinToString(" ")
        val auth = inspectAuthorization()
        if (auth.state != State.READY) {
            val errMsg = auth.error ?: "Shizuku state is ${auth.state} (not READY)"
            Log.w(TAG, "execShellArgs aborted [$displayCmd]: $errMsg")
            return ShellExecResult(
                commandDisplay = displayCmd,
                stdout = "",
                stderr = "",
                exitCode = -1,
                processCreated = false,
                timedOut = false,
                error = errMsg
            )
        }

        val quotedShellCmd = args.joinToString(" ") { shellQuote(it) }
        val shArray = arrayOf("sh", "-c", quotedShellCmd)
        return execRawCommandArray(shArray, displayCmd, timeoutMs)
    }

    fun execRawCommandArray(
        commandArray: Array<String>,
        displayCmd: String = commandArray.joinToString(" "),
        timeoutMs: Long = 5000L
    ): ShellExecResult {
        var proc: Process? = null
        return try {
            proc = createRemoteProcess(commandArray)
            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()
            var stdoutReadErr: String? = null
            var stderrReadErr: String? = null

            val outThread = Thread {
                try {
                    proc.inputStream.bufferedReader().use { reader ->
                        val buf = CharArray(4096)
                        var n: Int
                        while (reader.read(buf).also { n = it } != -1) {
                            stdoutBuilder.append(buf, 0, n)
                        }
                    }
                } catch (t: Throwable) {
                    val real = unwrapThrowable(t)
                    stdoutReadErr = "${real.javaClass.simpleName}: ${real.message}"
                }
            }

            val errThread = Thread {
                try {
                    proc.errorStream.bufferedReader().use { reader ->
                        val buf = CharArray(4096)
                        var n: Int
                        while (reader.read(buf).also { n = it } != -1) {
                            stderrBuilder.append(buf, 0, n)
                        }
                    }
                } catch (t: Throwable) {
                    val real = unwrapThrowable(t)
                    stderrReadErr = "${real.javaClass.simpleName}: ${real.message}"
                }
            }

            var exitCode = -1
            var waitException: Throwable? = null
            val waitThread = Thread {
                try {
                    // Use 0-arg ShizukuRemoteProcess.waitFor() which blocks on IRemoteProcess.waitFor()
                    exitCode = proc.waitFor()
                } catch (t: Throwable) {
                    waitException = unwrapThrowable(t)
                }
            }

            outThread.start()
            errThread.start()
            waitThread.start()

            waitThread.join(timeoutMs)
            val timedOut = waitThread.isAlive
            if (timedOut) {
                try {
                    proc.destroy()
                } catch (_: Throwable) {
                }
                waitThread.join(400L)
            }

            outThread.join(1500L)
            errThread.join(1500L)

            val stdoutStr = stdoutBuilder.toString()
            val stderrStr = stderrBuilder.toString()

            val errSummary = when {
                timedOut -> "Shizuku remote process timed out after ${timeoutMs}ms"
                waitException != null -> "waitFor failed: ${waitException?.javaClass?.simpleName}: ${waitException?.message}"
                stdoutStr.isEmpty() && stderrStr.isEmpty() && stdoutReadErr != null -> "stdout read error: $stdoutReadErr"
                stdoutStr.isEmpty() && stderrStr.isEmpty() && stderrReadErr != null -> "stderr read error: $stderrReadErr"
                else -> null
            }

            Log.d(
                TAG,
                "Shizuku exec [$displayCmd] -> exit=$exitCode, stdout=${stdoutStr.length}B, stderr=${stderrStr.length}B, err=${errSummary ?: "none"}"
            )

            ShellExecResult(
                commandDisplay = displayCmd,
                stdout = stdoutStr,
                stderr = stderrStr,
                exitCode = exitCode,
                processCreated = true,
                timedOut = timedOut,
                error = errSummary
            )
        } catch (t: Throwable) {
            val real = unwrapThrowable(t)
            val msg = "Shizuku process creation/execution failed (${real.javaClass.simpleName}: ${real.message ?: "no message"})"
            Log.e(TAG, "execRawCommandArray failed [$displayCmd]: $msg", real)
            ShellExecResult(
                commandDisplay = displayCmd,
                stdout = "",
                stderr = "",
                exitCode = -1,
                processCreated = false,
                timedOut = false,
                error = msg
            )
        } finally {
            try {
                proc?.destroy()
            } catch (_: Throwable) {
            }
        }
    }

    /**
     * Verifies:
     * 1. Shizuku user authorization (`checkSelfPermission() == PERMISSION_GRANTED`) and binder health.
     * 2. Remote process creation and shell identity (`id` runs as `uid=2000(shell)` or `uid=0(root)`).
     * 3. `dumpsys SurfaceFlinger --list` actually runs under the Shizuku shell identity without Permission Denial.
     */
    fun confirmSurfaceFlingerUnderShizukuShell(): ShellIdentityConfirmation {
        val auth = inspectAuthorization()
        if (auth.state != State.READY) {
            return ShellIdentityConfirmation(
                confirmed = false,
                auth = auth,
                identityOutput = "",
                sfProbeResult = null,
                failureReason = auth.error ?: "Shizuku is ${auth.state} (not READY)."
            )
        }

        val idRes = execShellArgs(listOf("id"), timeoutMs = 4000L)
        val idOut = idRes.stdout.trim()
        if (!idRes.processCreated || idRes.error != null) {
            return ShellIdentityConfirmation(
                confirmed = false,
                auth = auth,
                identityOutput = idOut,
                sfProbeResult = null,
                failureReason = "Shizuku 'id' process execution failed: ${idRes.error ?: idRes.stderr.trim()}"
            )
        }

        val isShellOrRoot = idOut.contains("uid=2000") ||
            idOut.contains("(shell)") ||
            idOut.contains("uid=0") ||
            idOut.contains("(root)") ||
            auth.serverUid == 2000 ||
            auth.serverUid == 0

        if (!isShellOrRoot) {
            return ShellIdentityConfirmation(
                confirmed = false,
                auth = auth,
                identityOutput = idOut,
                sfProbeResult = null,
                failureReason = "Unexpected Shizuku process identity (expected uid=2000/shell or uid=0/root): '$idOut'"
            )
        }

        val sfRes = execShellArgs(listOf("dumpsys", "SurfaceFlinger", "--list"), timeoutMs = 5000L)
        val combinedSf = "${sfRes.stdout}\n${sfRes.stderr}"
        val hasPermissionDenial = combinedSf.contains("Permission Denial", ignoreCase = true) ||
            combinedSf.contains("SecurityException", ignoreCase = true) ||
            combinedSf.contains("can't dump SurfaceFlinger", ignoreCase = true) ||
            combinedSf.contains("avc: denied", ignoreCase = true)

        if (!sfRes.processCreated || sfRes.error != null) {
            return ShellIdentityConfirmation(
                confirmed = false,
                auth = auth,
                identityOutput = idOut,
                sfProbeResult = sfRes,
                failureReason = "SurfaceFlinger probe via Shizuku failed to execute: ${sfRes.error}"
            )
        }

        if (hasPermissionDenial) {
            return ShellIdentityConfirmation(
                confirmed = false,
                auth = auth,
                identityOutput = idOut,
                sfProbeResult = sfRes,
                failureReason = "SurfaceFlinger probe via Shizuku returned Permission Denial (exit=${sfRes.exitCode}, stderr='${sfRes.stderr.trim().take(120)}', stdout='${sfRes.stdout.trim().take(120)}')."
            )
        }

        if (sfRes.stdout.isBlank()) {
            return ShellIdentityConfirmation(
                confirmed = false,
                auth = auth,
                identityOutput = idOut,
                sfProbeResult = sfRes,
                failureReason = "SurfaceFlinger --list via Shizuku returned empty stdout (exit=${sfRes.exitCode}, stderr='${sfRes.stderr.trim().take(120)}')."
            )
        }

        Log.i(
            TAG,
            "Confirmed SurfaceFlinger access under Shizuku shell identity: id='$idOut', --list lines=${sfRes.stdout.lines().size}, exit=${sfRes.exitCode}"
        )
        return ShellIdentityConfirmation(
            confirmed = true,
            auth = auth,
            identityOutput = idOut,
            sfProbeResult = sfRes,
            failureReason = null
        )
    }

    /** Returns a short message for the UI. */
    suspend fun grantDump(context: Context): String = withContext(Dispatchers.IO) {
        if (state() != State.READY) return@withContext "Shizuku isn't ready."
        val res = execShellArgs(
            listOf("pm", "grant", context.packageName, Manifest.permission.DUMP),
            timeoutMs = 4000L
        )
        if (context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED) {
            "Permission granted. Game FPS is ready."
        } else if (res.processCreated && res.exitCode == 0) {
            "Shizuku shell active (UID ${inspectAuthorization().serverUid}). Game FPS will use Shizuku shell directly."
        } else {
            val detail = (res.error ?: res.stderr.ifEmpty { res.stdout }).trim().take(120).ifEmpty { "no output" }
            "Grant note: $detail"
        }
    }
}
