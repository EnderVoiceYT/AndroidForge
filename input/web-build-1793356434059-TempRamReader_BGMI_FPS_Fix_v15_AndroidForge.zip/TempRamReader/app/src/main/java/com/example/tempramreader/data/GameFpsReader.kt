package com.example.tempramreader.data

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Reads real-time game FPS from SurfaceFlinger (prioritizing BGMI `com.pubg.imobile`).
 *
 * Execution Layer Guarantees:
 * - Verifies Shizuku user authorization and confirms that SurfaceFlinger commands actually run
 *   under the Shizuku shell identity (`uid=2000(shell)` / `uid=0(root)`) before FPS acquisition begins.
 * - Routes ALL SurfaceFlinger commands (`--list`, `--timestats -dump`, `--latency <layer>`) through
 *   Shizuku's remote process API whenever Shizuku is READY or direct `dumpsys` is denied.
 * - Captures `stdout`, `stderr`, and `exitCode` separately and never treats `exitCode=0` as success
 *   if `stderr` or `stdout` contains `Permission Denial`.
 * - Logs the execution method (`direct` or `Shizuku`) for every command and never silently falls
 *   back to unprivileged `direct` execution when Shizuku is READY.
 */
object GameFpsReader {
    private const val TAG = "GameFpsReader"
    const val BGMI_PACKAGE = "com.pubg.imobile"

    class Result(
        val fps: Int?,
        val status: String,
        val session: FpsSessionStats? = null,
        val nextDelayMs: Long = 1000L
    )

    enum class FailureType {
        NONE,
        PERMISSION_ERROR,
        SHIZUKU_EXEC_ERROR,
        EMPTY_DATA,
        UNRECOGNIZED_OUTPUT,
        NO_VALID_TIMESTAMPS,
        NO_NEW_TIMESTAMPS,
        NO_MATCHING_LAYER,
        COMMAND_ERROR
    }

    data class CommandOutput(
        val command: String,
        val stdout: String,
        val stderr: String,
        val exitCode: Int,
        val executedVia: String, // "Shizuku" or "direct"
        val failureType: FailureType,
        val failureReason: String?
    )

    data class TimeStatsLayerRecord(
        val layerName: String,
        val packageName: String,
        val uid: Int?,
        val totalFrames: Long,
        val droppedFrames: Long?,
        val lateLatchingFrames: Long?,
        val averageFps: Double?,
        val rawLines: List<String>
    )

    data class CompleteTimeStatsDump(
        val commandOutput: CommandOutput,
        val globalHeaderLines: List<String>,
        val allRecords: List<TimeStatsLayerRecord>,
        val targetRecords: List<TimeStatsLayerRecord>,
        val bgmiRecords: List<TimeStatsLayerRecord>,
        val failureType: FailureType,
        val failureReason: String?
    )

    data class DiscoveredLayerCandidate(
        val exactName: String,
        val source: String,
        val score: Int,
        val sequenceNumber: Long,
        val isSurfaceView: Boolean,
        val isBlast: Boolean,
        val isGameActivity: Boolean,
        val isInLiveList: Boolean
    )

    data class LayerDiscoveryReport(
        val listCommandOutput: CommandOutput,
        val totalListLayers: Int,
        val listMatchingLayers: List<String>,
        val candidates: List<DiscoveredLayerCandidate>,
        val primaryLayer: String?,
        val testedVariants: List<String>,
        val failureType: FailureType,
        val failureReason: String?
    )

    data class LatencySampleReport(
        val layerName: String,
        val commandOutput: CommandOutput,
        val refreshPeriodNs: Long?,
        val totalFrameRows: Int,
        val zeroFrameRows: Int,
        val pendingPresentRows: Int,
        val malformedRows: Int,
        val validDesiredPresentNs: List<Long>,
        val validActualPresentNs: List<Long>,
        val validFrameReadyNs: List<Long>,
        val failureType: FailureType,
        val failureReason: String?,
        val sampleElapsedRealtimeNs: Long
    )

    private const val INVALID_TS = Long.MAX_VALUE
    private val WHITESPACE = Regex("\\s+")
    private val SEQ_SUFFIX_RE = Regex("""#(\d+)\s*$""")
    private val UNBRACKETED_SV_RE = Regex("""^SurfaceView([^\[\]()#]+)#(\d+)$""")
    private val BRACKETED_BLAST_SV_RE = Regex("""^SurfaceView\[([^\]]+)\]\(BLAST\)#(\d+)$""")
    private val BRACKETED_PLAIN_SV_RE = Regex("""^SurfaceView\[([^\]]+)\]#(\d+)$""")
    private val DASH_SV_RE = Regex("""^SurfaceView\s*-\s*([^\[\]()#]+)#(\d+)$""")
    private val SF_DUMP_LAYER_RE = Regex("""(?:BufferStateLayer|BufferQueueLayer|Layer|SurfaceView)\s*\(?((?:SurfaceView)[^\r\n()]*?(?:\(BLAST\))?#\d+)\)?""")

    // Complete TimeStats regexes supporting both multi-line and inline key-value formats
    private val TS_LAYER_RE = Regex(
        """(?:layerName|layer_name)\s*[=:]\s*(.+?)(?=\s+(?:packageName|package_name|uid|totalFrames|total_frames|droppedFrames|dropped_frames|lateLatchingFrames|averageFPS|average_fps|gameMode)\s*[=:]|$)"""
    )
    private val TS_PKG_RE = Regex("""(?:packageName|package_name)\s*[=:]\s*([^\s,"\]]+)""")
    private val TS_UID_RE = Regex("""\buid\s*[=:]\s*(\d+)""")
    private val TS_TOTAL_RE = Regex("""(?:totalFrames|total_frames)\s*[=:]\s*(\d+)""")
    private val TS_DROPPED_RE = Regex("""(?:droppedFrames|dropped_frames)\s*[=:]\s*(\d+)""")
    private val TS_LATE_RE = Regex("""(?:lateLatchingFrames|late_latching_frames)\s*[=:]\s*(\d+)""")
    private val TS_AVG_FPS_RE = Regex("""(?:averageFPS|average_fps)\s*[=:]\s*([0-9]+(?:\.[0-9]+)?)""")

    private val IGNORABLE_SYSTEM_PACKAGES = setOf(
        "android",
        "com.android.systemui",
        "com.android.intentresolver",
        "com.transsion.resolver",
        "com.transsion.smartpanel",
        "com.transsion.magicshow",
        "com.transsion.gamespace",
        "com.transsion.gameassistant",
        "com.transsion.kolun.assistant",
        "com.android.launcher",
        "com.android.launcher3",
        "com.transsion.XOSLauncher",
        "com.transsion.hilauncher",
        "com.transsion.itel.launcher",
        "com.google.android.apps.nexuslauncher",
        "com.sec.android.app.launcher",
        "com.miui.home",
        "com.oppo.launcher",
        "com.vivo.launcher",
        "com.android.settings",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller",
        "moe.shizuku.privileged.api"
    )

    private val recorder = FpsSessionRecorder()
    private var currentPkg: String? = null
    private var lastActiveStatus: String = ""
    private var cachedHomePackage: String? = null

    // Execution layer state
    @Volatile
    private var directDumpDenied = false
    @Volatile
    private var shizukuShellConfirmed = false
    private var lastShizukuConfirmation: ShizukuHelper.ShellIdentityConfirmation? = null

    // Strategy A (actual presentation timestamps from SurfaceFlinger --latency)
    private var layer: String? = null
    private var lastTs = 0L
    private var staleStreak = 0
    private var latencyFailStreak = 0
    private var latencyRetryAtMs = 0L

    // Strategy B (fallback: BGMI-specific TimeStats totalFrames counter delta)
    private var timeStatsEnabled = false
    private var timeStatsLayer: String? = null
    private val previousLayerTotals = LinkedHashMap<String, Long>()
    private var previousTimeStatsAtNs = 0L
    private var lastTimeStatsFps: Int? = null

    private var diagCapturedForPkg: String? = null

    @Volatile
    var lastDiagnostics: String? = null
        private set

    fun hasDirectDumpPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED

    fun hasPermission(context: Context): Boolean =
        hasDirectDumpPermission(context) || ShizukuHelper.state() == ShizukuHelper.State.READY

    @Synchronized
    fun resetSession() {
        val pkg = currentPkg ?: ""
        recorder.reset(pkg)
        lastTs = 0L
        staleStreak = 0
        previousLayerTotals.clear()
        previousTimeStatsAtNs = 0L
        lastTimeStatsFps = null
    }

    /**
     * Runs the complete two-sample diagnostic on demand (defaulting to BGMI `com.pubg.imobile`
     * or the currently tracked game package) and updates `lastDiagnostics`.
     */
    @Synchronized
    fun runDiagnosticNow(context: Context, explicitPkg: String? = null): String {
        val targetPkg = explicitPkg
            ?: currentPkg?.takeIf { it.isNotBlank() && !isIgnorableNonGamePackage(context, it) }
            ?: BGMI_PACKAGE
        val outcome = executeDetailedDiagnostic(context, targetPkg)
        lastDiagnostics = outcome.diagnosticText
        if (outcome.shizukuOrDirectConfirmed) {
            diagCapturedForPkg = targetPkg
        }
        return outcome.diagnosticText
    }

    @Synchronized
    fun sample(context: Context): Result {
        val directGranted = hasDirectDumpPermission(context)
        val shizukuState = ShizukuHelper.state()
        if (!directGranted && shizukuState != ShizukuHelper.State.READY) {
            val reason = "PERMISSION_ERROR: DUMP permission is false and Shizuku state is $shizukuState."
            Log.w(TAG, reason)
            return Result(null, "Game FPS needs Shizuku READY or the DUMP permission.")
        }

        // Gate 0: Before any FPS acquisition, confirm SurfaceFlinger execution under Shizuku shell identity
        // whenever Shizuku is READY or direct dump is not granted / was denied.
        if (shizukuState == ShizukuHelper.State.READY || !directGranted || directDumpDenied) {
            if (!shizukuShellConfirmed) {
                val confirmation = ShizukuHelper.confirmSurfaceFlingerUnderShizukuShell()
                lastShizukuConfirmation = confirmation
                shizukuShellConfirmed = confirmation.confirmed
                if (!confirmation.confirmed) {
                    val failMsg = "Shizuku shell verification failed: ${confirmation.failureReason}"
                    Log.e(TAG, failMsg)
                    lastDiagnostics = buildExecutionFailureDiagnostic(context, BGMI_PACKAGE, confirmation)
                    return Result(null, failMsg, recorder.snapshot(), 1500L)
                }
            }
        }

        val (detectedPkg, _) = ForegroundAppDetector.getForegroundApp(context)
        if (detectedPkg == ForegroundAppDetector.NO_PERMISSION) {
            return Result(null, "Grant Usage Access so the app knows which game is open.", recorder.snapshot())
        }

        // Resolve target package: if the user has TempRamReader open in a floating window over BGMI
        // or opened the system Share resolver (`com.transsion.resolver`), keep tracking the active game (`com.pubg.imobile`).
        val pkg: String = when {
            detectedPkg == ForegroundAppDetector.NO_FOREGROUND_APP || isIgnorableNonGamePackage(context, detectedPkg) -> {
                val existingGame = currentPkg?.takeIf { !isIgnorableNonGamePackage(context, it) }
                val activeGame = existingGame ?: detectLiveBgmiIfPresent()
                if (activeGame == null) {
                    return Result(
                        null,
                        "Open BGMI ($BGMI_PACKAGE) or another game to start real-time FPS.",
                        recorder.snapshot()
                    )
                }
                activeGame
            }
            else -> detectedPkg
        }

        if (pkg != currentPkg) {
            Log.i(TAG, "Switching tracked game package from $currentPkg to $pkg")
            currentPkg = pkg
            layer = null
            lastTs = 0L
            staleStreak = 0
            latencyFailStreak = 0
            latencyRetryAtMs = 0L
            timeStatsLayer = null
            previousLayerTotals.clear()
            previousTimeStatsAtNs = 0L
            lastTimeStatsFps = null
            diagCapturedForPkg = null
            recorder.reset(pkg)
        }

        // First: run the detailed diagnostic (which also confirms Shizuku shell identity) before starting live polling.
        if (diagCapturedForPkg != pkg) {
            val outcome = executeDetailedDiagnostic(context, pkg)
            lastDiagnostics = outcome.diagnosticText
            if (!outcome.shizukuOrDirectConfirmed) {
                return Result(
                    null,
                    outcome.initialResult?.status ?: "SurfaceFlinger execution verification failed; share diagnostics.",
                    recorder.snapshot(),
                    1500L
                )
            }
            diagCapturedForPkg = pkg
            if (outcome.initialResult != null) {
                lastActiveStatus = outcome.initialResult.status
                return outcome.initialResult
            }
        }

        // Primary live FPS: actual presentation timestamps from SurfaceFlinger --latency <exact_layer_name>.
        val nowMs = System.currentTimeMillis()
        if (nowMs >= latencyRetryAtMs) {
            val latencyResult = sampleLatency(context, pkg)
            if (latencyResult != null) {
                latencyFailStreak = 0
                lastActiveStatus = latencyResult.status
                return latencyResult
            }
            latencyFailStreak++
            if (latencyFailStreak >= 3) {
                latencyRetryAtMs = nowMs + 10_000L
                latencyFailStreak = 0
            }
        }

        // Fallback live FPS: BGMI-specific SurfaceFlinger TimeStats totalFrames counter delta.
        val timeStatsResult = sampleTimeStats(context, pkg)
        if (timeStatsResult != null) {
            lastActiveStatus = timeStatsResult.status
            return timeStatsResult
        }

        val failMsg = "No usable frame data for $pkg yet. Share diagnostics for exact SurfaceFlinger details."
        lastActiveStatus = failMsg
        return Result(null, failMsg, recorder.snapshot(), 1000L)
    }

    /**
     * Checks if BGMI (`com.pubg.imobile`) currently has live layers in SurfaceFlinger
     * (e.g., when TempRamReader is open in a floating multi-window on top of BGMI).
     */
    private fun detectLiveBgmiIfPresent(): String? {
        val probe = lastShizukuConfirmation?.sfProbeResult
        if (probe != null && probe.stdout.contains(BGMI_PACKAGE, ignoreCase = true)) {
            return BGMI_PACKAGE
        }
        val listOut = runSurfaceFlingerCommand(null, "--list", timeoutMs = 2500L)
        if (listOut.failureType == FailureType.NONE && listOut.stdout.contains(BGMI_PACKAGE, ignoreCase = true)) {
            return BGMI_PACKAGE
        }
        return null
    }

    // =========================================================================================
    // 1. Detailed Two-Sample Diagnostic (2 Seconds Apart) & Shizuku Identity Confirmation
    // =========================================================================================

    private data class DiagnosticOutcome(
        val diagnosticText: String,
        val shizukuOrDirectConfirmed: Boolean,
        val initialResult: Result?
    )

    private fun buildExecutionFailureDiagnostic(
        context: Context,
        pkg: String,
        confirmation: ShizukuHelper.ShellIdentityConfirmation
    ): String {
        val sb = StringBuilder()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US)
        val dumpGranted = hasDirectDumpPermission(context)
        sb.appendLine("=== TempRamReader SurfaceFlinger / BGMI FPS Diagnostic ===")
        sb.appendLine("Timestamp: ${dateFormat.format(Date())}")
        sb.appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE} / ${Build.PRODUCT})")
        sb.appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine("Target Package: $pkg (BGMI target: $BGMI_PACKAGE)")
        sb.appendLine("DUMP Permission Granted: $dumpGranted | Shizuku State: ${confirmation.auth.state}")
        sb.appendLine()
        appendShizukuConfirmationSection(sb, confirmation)
        sb.appendLine()
        sb.appendLine("[Diagnostic Aborted] SurfaceFlinger command did not succeed under Shizuku shell identity.")
        return sb.toString()
    }

    private fun appendShizukuConfirmationSection(
        sb: StringBuilder,
        confirmation: ShizukuHelper.ShellIdentityConfirmation
    ) {
        val auth = confirmation.auth
        sb.appendLine("[Step 0] Shizuku Authorization & Shell Identity Confirmation")
        sb.appendLine("  Shizuku State: ${auth.state} | Binder Alive: ${auth.binderAlive} | Pre-v11: ${auth.isPreV11}")
        sb.appendLine("  Shizuku User Authorization Granted: ${auth.permissionGranted}")
        sb.appendLine("  Shizuku Server UID: ${auth.serverUid} | Server Version: ${auth.serverVersion} | SELinux Context: ${auth.selinuxContext ?: "N/A"}")
        sb.appendLine("  Shell 'id' Output: ${confirmation.identityOutput.ifEmpty { "NONE" }}")
        val sfProbe = confirmation.sfProbeResult
        if (sfProbe != null) {
            sb.appendLine(
                "  SurfaceFlinger Probe (via=Shizuku): cmd='${sfProbe.commandDisplay}', processCreated=${sfProbe.processCreated}, " +
                    "exit=${sfProbe.exitCode}, stdout=${sfProbe.stdout.length} chars (${sfProbe.stdout.lines().size} lines), " +
                    "stderr=${sfProbe.stderr.length} chars"
            )
            if (sfProbe.stderr.isNotBlank()) {
                sb.appendLine("  SurfaceFlinger Probe stderr: ${sfProbe.stderr.trim().take(200)}")
            }
        }
        sb.appendLine("  SurfaceFlinger Under Shizuku Shell Confirmed: ${confirmation.confirmed}")
        if (confirmation.failureReason != null) {
            sb.appendLine("  Confirmation Failure Reason: ${confirmation.failureReason}")
        }
    }

    private fun executeDetailedDiagnostic(context: Context, pkg: String): DiagnosticOutcome {
        val sb = StringBuilder()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z", Locale.US)
        val dumpGranted = hasDirectDumpPermission(context)
        val shizukuState = ShizukuHelper.state()

        sb.appendLine("=== TempRamReader SurfaceFlinger / BGMI FPS Diagnostic ===")
        sb.appendLine("Timestamp: ${dateFormat.format(Date())}")
        sb.appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE} / ${Build.PRODUCT})")
        sb.appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine("Target Package: $pkg (BGMI target: $BGMI_PACKAGE)")
        sb.appendLine("DUMP Permission Granted: $dumpGranted | Shizuku State: $shizukuState")
        sb.appendLine()

        // Step 0: Verify Shizuku authorization and confirm SurfaceFlinger command execution under Shizuku shell identity.
        val confirmation = ShizukuHelper.confirmSurfaceFlingerUnderShizukuShell()
        lastShizukuConfirmation = confirmation
        shizukuShellConfirmed = confirmation.confirmed
        appendShizukuConfirmationSection(sb, confirmation)
        sb.appendLine()

        if (!confirmation.confirmed && (!dumpGranted || directDumpDenied || shizukuState == ShizukuHelper.State.READY)) {
            val reason = confirmation.failureReason ?: "SurfaceFlinger command failed under Shizuku shell identity."
            sb.appendLine("[Diagnostic Halted] Cannot begin FPS acquisition until SurfaceFlinger succeeds under Shizuku shell identity: $reason")
            val text = sb.toString()
            Log.e(TAG, text)
            return DiagnosticOutcome(
                diagnosticText = text,
                shizukuOrDirectConfirmed = false,
                initialResult = Result(null, "Shizuku execution error: $reason", recorder.snapshot(), 1500L)
            )
        }

        // Step 1: Search COMPLETE SurfaceFlinger TimeStats output for all BGMI layer records.
        val enableCmd = ensureTimeStatsEnabled(context)
        sb.appendLine("[Step 1] Search COMPLETE SurfaceFlinger TimeStats Output")
        sb.appendLine(
            "  TimeStats enable command: ${enableCmd.command} (via=${enableCmd.executedVia}, exit=${enableCmd.exitCode}, " +
                "stdout=${enableCmd.stdout.length} chars, stderr=${enableCmd.stderr.length} chars)"
        )
        if (enableCmd.failureReason != null) {
            sb.appendLine("  TimeStats enable warning: [${enableCmd.failureType}] ${enableCmd.failureReason}")
        }

        val tsSample1AtNs = SystemClock.elapsedRealtimeNanos()
        val tsDump1 = queryCompleteTimeStats(context, pkg, flushActive = true)
        appendTimeStatsSection(sb, "Sample 1 (t = 0.0s)", pkg, tsDump1)

        // Step 2: Dynamically discover the current BGMI BLAST SurfaceView layer.
        sb.appendLine()
        sb.appendLine("[Step 2] Dynamically Discover Current BGMI BLAST SurfaceView Layer")
        val discovery = discoverBlastSurfaceViewLayer(context, pkg, tsDump1)
        sb.appendLine(
            "  --list command: ${discovery.listCommandOutput.command} (via=${discovery.listCommandOutput.executedVia}, " +
                "exit=${discovery.listCommandOutput.exitCode}, stdout=${discovery.listCommandOutput.stdout.length} chars, " +
                "stderr=${discovery.listCommandOutput.stderr.length} chars)"
        )
        if (discovery.listCommandOutput.failureReason != null) {
            sb.appendLine("  --list failure reason: [${discovery.listCommandOutput.failureType}] ${discovery.listCommandOutput.failureReason}")
        } else {
            sb.appendLine("  --list total layers: ${discovery.totalListLayers} | Matching '$pkg' layers: ${discovery.listMatchingLayers.size}")
            discovery.listMatchingLayers.forEach { l ->
                sb.appendLine("    list match: $l")
            }
        }

        if (discovery.candidates.isEmpty()) {
            sb.appendLine("  Discovered candidates: 0")
            sb.appendLine("  Discovery failure reason: [${discovery.failureType}] ${discovery.failureReason}")
            Log.e(TAG, "Layer discovery failed for $pkg: [${discovery.failureType}] ${discovery.failureReason}")
        } else {
            sb.appendLine("  Ranked candidate layers (${discovery.candidates.size}):")
            discovery.candidates.take(10).forEachIndexed { idx, c ->
                sb.appendLine(
                    "    #${idx + 1}: \"${c.exactName}\" [source=${c.source}, score=${c.score}, seq=#${c.sequenceNumber}, " +
                        "SurfaceView=${c.isSurfaceView}, BLAST=${c.isBlast}, GameActivity=${c.isGameActivity}, inLiveList=${c.isInLiveList}]"
                )
            }
            sb.appendLine("  Selected primary BLAST SurfaceView layer: \"${discovery.primaryLayer ?: "NONE"}\"")
            sb.appendLine("  Exact layer variants to probe: ${discovery.testedVariants.joinToString(" | ") { "\"$it\"" }}")
        }

        // Step 3: Execute layer-specific SurfaceFlinger --latency query using its exact name,
        // parse refresh-period header separately from actual frame timestamps, report valid non-zero
        // timestamps, take two samples 2 seconds apart, and report how many new timestamps appeared.
        sb.appendLine()
        sb.appendLine("[Step 3] Layer-Specific SurfaceFlinger --latency Query (Two Samples 2.0s Apart)")

        val variantsToProbe = discovery.testedVariants.ifEmpty {
            listOfNotNull(discovery.primaryLayer)
        }

        val sample1Reports = LinkedHashMap<String, LatencySampleReport>()
        for (variant in variantsToProbe) {
            sample1Reports[variant] = queryLayerLatency(context, variant)
        }

        val bestVariantSample1 = sample1Reports.entries
            .sortedWith(
                compareByDescending<Map.Entry<String, LatencySampleReport>> { it.value.validActualPresentNs.size }
                    .thenByDescending { it.value.validFrameReadyNs.size }
            )
            .firstOrNull()?.key ?: discovery.primaryLayer

        if (sample1Reports.isEmpty()) {
            sb.appendLine("  Skipped --latency query: no layer name discovered for $pkg.")
        } else {
            sample1Reports.forEach { (variantName, rep1) ->
                val tag = if (variantName == bestVariantSample1) "PRIMARY" else "ALTERNATE VARIANT"
                appendLatencySampleReport(sb, "Sample 1 ($tag, t = 0.0s)", rep1)
            }
        }

        // Wait 2.0 seconds between Sample 1 and Sample 2 as required.
        try {
            Thread.sleep(2000L)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }

        val sample2Reports = LinkedHashMap<String, LatencySampleReport>()
        for (variant in variantsToProbe) {
            sample2Reports[variant] = queryLayerLatency(context, variant)
        }

        val tsSample2AtNs = SystemClock.elapsedRealtimeNanos()
        val tsDump2 = queryCompleteTimeStats(context, pkg, flushActive = true)

        var activeLatencyLayer: String? = null
        var activeLatencyFps: Int? = null
        var activeSample1: LatencySampleReport? = null
        var activeSample2: LatencySampleReport? = null
        var bestNewActualCount = 0

        for (variant in variantsToProbe) {
            val rep1 = sample1Reports[variant] ?: continue
            val rep2 = sample2Reports[variant] ?: continue
            val isPrimary = (variant == bestVariantSample1)
            val label = if (isPrimary) "Sample 2 (PRIMARY, t = +2.0s)" else "Sample 2 (ALTERNATE VARIANT, t = +2.0s)"
            appendLatencySampleReport(sb, label, rep2)

            val elapsedMs = ((rep2.sampleElapsedRealtimeNs - rep1.sampleElapsedRealtimeNs) / 1e6).coerceAtLeast(1.0)
            val maxActual1 = rep1.validActualPresentNs.lastOrNull() ?: 0L
            val newActualStamps = if (maxActual1 > 0L) {
                rep2.validActualPresentNs.filter { it > maxActual1 }
            } else {
                rep2.validActualPresentNs
            }

            val maxReady1 = rep1.validFrameReadyNs.lastOrNull() ?: 0L
            val newReadyStamps = if (maxReady1 > 0L) {
                rep2.validFrameReadyNs.filter { it > maxReady1 }
            } else {
                rep2.validFrameReadyNs
            }

            sb.appendLine("  Two-Sample Comparison for \"$variant\" (${"%.0f".format(elapsedMs)} ms apart):")
            sb.appendLine("    Sample 1 valid non-zero actualPresentTime timestamps: ${rep1.validActualPresentNs.size}")
            sb.appendLine("    Sample 2 valid non-zero actualPresentTime timestamps: ${rep2.validActualPresentNs.size}")
            sb.appendLine("    New valid non-zero actualPresentTime timestamps in Sample 2: ${newActualStamps.size}")
            sb.appendLine("    New valid non-zero frameReadyTime timestamps in Sample 2: ${newReadyStamps.size}")

            if (newActualStamps.isEmpty()) {
                val failReason = when {
                    rep2.failureType != FailureType.NONE ->
                        "[${rep2.failureType}] ${rep2.failureReason}"
                    rep2.validActualPresentNs.isNotEmpty() ->
                        "[${FailureType.NO_NEW_TIMESTAMPS}] Sample 1 and Sample 2 both returned latest actualPresentTime=${rep2.validActualPresentNs.last()} ns (0 new timestamps appeared in ${"%.0f".format(elapsedMs)} ms)."
                    else ->
                        "[${FailureType.NO_VALID_TIMESTAMPS}] 0 valid non-zero actualPresentTime timestamps returned."
                }
                sb.appendLine("    --latency 2s status: FAILED — $failReason")
                Log.w(TAG, "Diagnostic --latency 2s check failed for '$variant': $failReason")
            } else {
                val derivedFps = computeFpsFromActualTimestamps(rep1.validActualPresentNs, rep2.validActualPresentNs, elapsedMs)
                sb.appendLine("    --latency 2s status: OK — ${newActualStamps.size} new presentation timestamps (derived FPS: ${derivedFps ?: "--"})")
                if (newActualStamps.size > bestNewActualCount && derivedFps != null) {
                    bestNewActualCount = newActualStamps.size
                    activeLatencyLayer = variant
                    activeLatencyFps = derivedFps
                    activeSample1 = rep1
                    activeSample2 = rep2
                }
            }
        }

        // Step 4: Compare COMPLETE TimeStats Sample 1 and Sample 2 across the same 2-second window.
        sb.appendLine()
        sb.appendLine("[Step 4] COMPLETE SurfaceFlinger TimeStats 2-Second Delta Check (Fallback)")
        appendTimeStatsSection(sb, "Sample 2 (t = +2.0s)", pkg, tsDump2)

        val tsElapsedMs = ((tsSample2AtNs - tsSample1AtNs) / 1e6).coerceAtLeast(1.0)
        val totals1 = tsDump1.targetRecords.associate { it.layerName to it.totalFrames }
        val totals2 = tsDump2.targetRecords.associate { it.layerName to it.totalFrames }

        var bestTsLayer: String? = null
        var bestTsDelta = 0L
        var bestTsScore = Int.MIN_VALUE

        val allTsLayerNames = (totals1.keys + totals2.keys).distinct()
        if (allTsLayerNames.isEmpty()) {
            sb.appendLine("  TimeStats 2s comparison: 0 records found for $pkg in complete TimeStats dump.")
        } else {
            sb.appendLine("  TimeStats 2s comparison across ${allTsLayerNames.size} '$pkg' layer record(s) (${"%.0f".format(tsElapsedMs)} ms):")
            for (lName in allTsLayerNames) {
                val t1 = totals1[lName]
                val t2 = totals2[lName]
                val delta = if (t1 != null && t2 != null && t2 >= t1) (t2 - t1) else (t2 ?: 0L)
                val sc = scoreLayerName(lName, pkg, discovery.listMatchingLayers.contains(lName))
                val estFps = if (delta > 0L) (delta * 1000.0 / tsElapsedMs).roundToInt() else 0
                sb.appendLine("    * \"$lName\" (score=$sc, seq=#${extractSequenceNumber(lName)}): Sample1=${t1 ?: "N/A"} -> Sample2=${t2 ?: "N/A"} | delta=+$delta frames (~$estFps FPS)")
                if (sc >= 0 && (delta > 0L && (sc > bestTsScore || (sc == bestTsScore && delta > bestTsDelta)))) {
                    bestTsScore = sc
                    bestTsDelta = delta
                    bestTsLayer = lName
                }
            }
        }

        // Step 5: Seed live tracking state from the diagnostic results
        var seededResult: Result? = null
        sb.appendLine()
        sb.appendLine("[Step 5] Diagnostic Summary & Active FPS Pipeline Selection")
        if (activeLatencyLayer != null && activeLatencyFps != null && activeSample2 != null) {
            layer = activeLatencyLayer
            staleStreak = 0
            latencyFailStreak = 0
            latencyRetryAtMs = 0L

            val prevLatest = activeSample1?.validActualPresentNs?.lastOrNull() ?: 0L
            var prev = if (prevLatest > 0L && activeSample2.validActualPresentNs.binarySearch(prevLatest) >= 0) prevLatest else null
            for (ts in activeSample2.validActualPresentNs) {
                if (prevLatest > 0L && ts <= prevLatest) continue
                if (prev != null) recorder.addFrame((ts - prev) / 1e6)
                prev = ts
            }
            lastTs = activeSample2.validActualPresentNs.last()
            recorder.addSecondFps(activeLatencyFps)

            val status = "Game FPS: $pkg (presented • $activeLatencyLayer)"
            sb.appendLine("  Selected Live Pipeline: ACTUAL_PRESENTATION_TIMESTAMPS (--latency via ${activeSample2.commandOutput.executedVia})")
            sb.appendLine("  Active Layer: $activeLatencyLayer")
            sb.appendLine("  Initial Live FPS: $activeLatencyFps FPS")
            seededResult = Result(
                activeLatencyFps,
                status,
                recorder.snapshot(),
                if (activeLatencyFps >= 90) 700L else 1000L
            )
        } else {
            previousLayerTotals.clear()
            for ((k, v) in totals2) {
                previousLayerTotals[k] = v
            }
            previousTimeStatsAtNs = tsSample2AtNs
            latencyRetryAtMs = System.currentTimeMillis() + 10_000L

            if (bestTsLayer != null && bestTsDelta > 0L) {
                timeStatsLayer = bestTsLayer
                val fallbackFps = (bestTsDelta * 1000.0 / tsElapsedMs).roundToInt().coerceIn(1, 1000)
                lastTimeStatsFps = fallbackFps
                recorder.addEstimatedBatch(bestTsDelta, tsElapsedMs, fallbackFps)
                val status = "Game FPS: $pkg (TimeStats fallback • $bestTsLayer)"
                sb.appendLine("  Selected Live Pipeline: BGMI_TIMESTATS_COUNTER_FALLBACK (--timestats via ${tsDump2.commandOutput.executedVia})")
                sb.appendLine("  Reason --latency was not used: No advancing actualPresentTime timestamps on probed layer(s).")
                sb.appendLine("  Active TimeStats Layer: $bestTsLayer (+$bestTsDelta frames in ${"%.0f".format(tsElapsedMs)} ms)")
                sb.appendLine("  Initial Fallback Live FPS: $fallbackFps FPS")
                seededResult = Result(
                    fallbackFps,
                    status,
                    recorder.snapshot(),
                    1000L
                )
            } else {
                val chosenTsCandidate = chooseBestTimeStatsLayer(totals2, emptyMap(), pkg, discovery.listMatchingLayers.toSet())
                timeStatsLayer = chosenTsCandidate
                sb.appendLine("  Selected Live Pipeline: PENDING (0 new frames detected across 2.0s diagnostic window)")
                sb.appendLine("  Tracked Fallback Layer: ${chosenTsCandidate ?: "NONE"}")
            }
        }

        val fullReport = sb.toString()
        Log.i(TAG, fullReport)
        return DiagnosticOutcome(
            diagnosticText = fullReport,
            shizukuOrDirectConfirmed = true,
            initialResult = seededResult
        )
    }

    private fun appendTimeStatsSection(
        sb: StringBuilder,
        title: String,
        pkg: String,
        dump: CompleteTimeStatsDump
    ) {
        sb.appendLine("  --- TimeStats $title ---")
        sb.appendLine(
            "  Command: ${dump.commandOutput.command} (via=${dump.commandOutput.executedVia}, exit=${dump.commandOutput.exitCode}, " +
                "stdout=${dump.commandOutput.stdout.length} chars, stderr=${dump.commandOutput.stderr.length} chars)"
        )
        if (dump.commandOutput.stderr.isNotBlank()) {
            sb.appendLine("  stderr: ${dump.commandOutput.stderr.trim().take(200)}")
        }
        sb.appendLine("  Output size: ${dump.commandOutput.stdout.length} chars, ${dump.commandOutput.stdout.lines().size} lines")
        sb.appendLine("  Total layer records parsed in COMPLETE dump: ${dump.allRecords.size}")
        if (dump.globalHeaderLines.isNotEmpty()) {
            sb.appendLine("  Global header: ${dump.globalHeaderLines.joinToString(" | ")}")
        }
        if (dump.failureType != FailureType.NONE) {
            sb.appendLine("  Failure reason: [${dump.failureType}] ${dump.failureReason}")
        }
        val recordsToShow = (dump.bgmiRecords + dump.targetRecords).distinctBy { it.layerName }
        sb.appendLine("  Matching BGMI / '$pkg' layer records found: ${recordsToShow.size}")
        recordsToShow.forEachIndexed { idx, rec ->
            sb.appendLine(
                "    Record #${idx + 1}: layerName=\"${rec.layerName}\" | packageName=\"${rec.packageName}\" | " +
                    "uid=${rec.uid ?: "N/A"} | totalFrames=${rec.totalFrames} | droppedFrames=${rec.droppedFrames ?: "N/A"} | " +
                    "lateLatchingFrames=${rec.lateLatchingFrames ?: "N/A"} | averageFPS=${rec.averageFps ?: "N/A"}"
            )
        }
    }

    private fun appendLatencySampleReport(
        sb: StringBuilder,
        label: String,
        rep: LatencySampleReport
    ) {
        sb.appendLine("  --- $label ---")
        sb.appendLine("    Exact Layer Name: \"${rep.layerName}\"")
        sb.appendLine(
            "    Command: ${rep.commandOutput.command} (via=${rep.commandOutput.executedVia}, exit=${rep.commandOutput.exitCode}, " +
                "stdout=${rep.commandOutput.stdout.length} chars, stderr=${rep.commandOutput.stderr.length} chars)"
        )
        if (rep.commandOutput.stderr.isNotBlank()) {
            sb.appendLine("    stderr: ${rep.commandOutput.stderr.trim().take(200)}")
        }
        val hzNote = if (rep.refreshPeriodNs != null && rep.refreshPeriodNs > 0L) {
            val hz = (1_000_000_000.0 / rep.refreshPeriodNs).roundToInt()
            "${rep.refreshPeriodNs} ns (~$hz Hz display vsync period; parsed separately, never used as game FPS)"
        } else {
            "${rep.refreshPeriodNs ?: "NONE"}"
        }
        sb.appendLine("    Refresh-Period Header: $hzNote")
        sb.appendLine(
            "    Frame Rows (post-header): total=${rep.totalFrameRows}, zeroRows=${rep.zeroFrameRows}, " +
                "pending(INT64_MAX)=${rep.pendingPresentRows}, malformed=${rep.malformedRows}"
        )
        sb.appendLine("    Valid non-zero actualPresentTime (col 2) timestamps: ${rep.validActualPresentNs.size}")
        sb.appendLine("    Valid non-zero frameReadyTime (col 3) timestamps: ${rep.validFrameReadyNs.size}")
        sb.appendLine("    Valid non-zero desiredPresentTime (col 1) timestamps: ${rep.validDesiredPresentNs.size}")
        if (rep.validActualPresentNs.isNotEmpty()) {
            val first = rep.validActualPresentNs.first()
            val last = rep.validActualPresentNs.last()
            val spanMs = (last - first) / 1e6
            sb.appendLine("    actualPresentTime range: first=$first ns, last=$last ns (span=${"%.1f".format(spanMs)} ms)")
        }
        if (rep.failureType != FailureType.NONE) {
            sb.appendLine("    Failure Reason: [${rep.failureType}] ${rep.failureReason}")
        } else {
            sb.appendLine("    Failure Reason: NONE (valid actualPresentTime timestamps present)")
        }
    }

    // =========================================================================================
    // 2. Live FPS Acquisition: Primary (Actual Presentation Timestamps via --latency)
    // =========================================================================================

    private fun sampleLatency(context: Context, pkg: String): Result? {
        if (layer == null || staleStreak >= 2) {
            val discovery = discoverBlastSurfaceViewLayer(context, pkg, null)
            val chosen = selectBestReadableLatencyLayer(context, discovery)
            if (chosen != layer) {
                layer = chosen
                lastTs = 0L
                staleStreak = 0
            }
        }
        val targetLayer = layer ?: return null
        val report = queryLayerLatency(context, targetLayer)
        if (report.failureType != FailureType.NONE) {
            Log.w(TAG, "Live --latency failed for '$targetLayer' (via=${report.commandOutput.executedVia}): [${report.failureType}] ${report.failureReason}")
            staleStreak++
            return null
        }

        val stamps = report.validActualPresentNs
        if (stamps.size < 2) {
            Log.w(TAG, "Live --latency returned < 2 valid actualPresentTime timestamps (${stamps.size}) for '$targetLayer'")
            staleStreak++
            return null
        }

        val newest = stamps.last()
        val prevLastTs = lastTs
        if (prevLastTs == 0L) {
            lastTs = newest
            return Result(
                null,
                "Game FPS: calibrating presentation timestamps for $pkg...",
                recorder.snapshot(),
                400L
            )
        }
        if (newest <= prevLastTs) {
            staleStreak++
            Log.d(TAG, "Live --latency no new timestamps on '$targetLayer' (newest=$newest <= lastTs=$prevLastTs, streak=$staleStreak)")
            return null
        }
        staleStreak = 0

        var previous: Long? = if (stamps.binarySearch(prevLastTs) >= 0) prevLastTs else null
        var newFrameCount = 0
        for (timestamp in stamps) {
            if (timestamp <= prevLastTs) continue
            newFrameCount++
            val before = previous
            if (before != null) recorder.addFrame((timestamp - before) / 1e6)
            previous = timestamp
        }
        lastTs = newest

        val inWindow = stamps.filter { it >= newest - 1_000_000_000L }
        val fps: Int = when {
            inWindow.size >= 2 && inWindow.last() > inWindow.first() -> {
                val spanSec = (inWindow.last() - inWindow.first()) / 1e9
                ((inWindow.size - 1) / spanSec).roundToInt().coerceIn(1, 1000)
            }
            newFrameCount >= 1 && newest > prevLastTs -> {
                val spanSec = (newest - prevLastTs) / 1e9
                if (spanSec > 0.0) (newFrameCount / spanSec).roundToInt().coerceIn(1, 1000) else return null
            }
            else -> return Result(
                null,
                "Game FPS: waiting for more presented frames ($pkg)...",
                recorder.snapshot(),
                500L
            )
        }

        recorder.addSecondFps(fps)
        return Result(
            fps,
            "Game FPS: $pkg (presented • ${report.commandOutput.executedVia})",
            recorder.snapshot(),
            if (fps >= 90) 700L else 1000L
        )
    }

    private fun selectBestReadableLatencyLayer(context: Context, discovery: LayerDiscoveryReport): String? {
        val candidatesToProbe = discovery.testedVariants.ifEmpty {
            discovery.candidates.map { it.exactName }.take(4)
        }
        var bestLayer: String? = null
        var bestValidCount = 0
        var bestNewestTs = 0L

        for (candidate in candidatesToProbe) {
            val rep = queryLayerLatency(context, candidate)
            val validCount = rep.validActualPresentNs.size
            val newestTs = rep.validActualPresentNs.lastOrNull() ?: 0L
            if (validCount >= 2 && (validCount > bestValidCount || (validCount == bestValidCount && newestTs > bestNewestTs))) {
                bestValidCount = validCount
                bestNewestTs = newestTs
                bestLayer = candidate
            }
        }
        return bestLayer
    }

    private fun computeFpsFromActualTimestamps(
        sample1Stamps: List<Long>,
        sample2Stamps: List<Long>,
        elapsedWallMs: Double
    ): Int? {
        if (sample2Stamps.size < 2) return null
        val newest = sample2Stamps.last()
        val inLastSecond = sample2Stamps.filter { it >= newest - 1_000_000_000L }
        if (inLastSecond.size >= 2 && inLastSecond.last() > inLastSecond.first()) {
            val spanSec = (inLastSecond.last() - inLastSecond.first()) / 1e9
            if (spanSec > 0.0) {
                return ((inLastSecond.size - 1) / spanSec).roundToInt().coerceIn(1, 1000)
            }
        }
        val max1 = sample1Stamps.lastOrNull() ?: 0L
        if (max1 > 0L && newest > max1) {
            val newStamps = sample2Stamps.filter { it > max1 }
            if (newStamps.isNotEmpty()) {
                val spanSec = (newest - max1) / 1e9
                if (spanSec > 0.0) {
                    return (newStamps.size / spanSec).roundToInt().coerceIn(1, 1000)
                }
            }
        }
        if (elapsedWallMs > 0.0 && sample2Stamps.last() > sample2Stamps.first()) {
            val spanSec = (sample2Stamps.last() - sample2Stamps.first()) / 1e9
            if (spanSec > 0.0) {
                return ((sample2Stamps.size - 1) / spanSec).roundToInt().coerceIn(1, 1000)
            }
        }
        return null
    }

    // =========================================================================================
    // 3. Live FPS Acquisition: Fallback (BGMI-Specific SurfaceFlinger TimeStats Counter)
    // =========================================================================================

    private fun sampleTimeStats(context: Context, pkg: String): Result? {
        if (!timeStatsEnabled) {
            ensureTimeStatsEnabled(context)
        }

        val nowNs = SystemClock.elapsedRealtimeNanos()
        val dump = queryCompleteTimeStats(context, pkg, flushActive = true)
        if (dump.failureType != FailureType.NONE && dump.targetRecords.isEmpty()) {
            Log.w(TAG, "TimeStats fallback failed for $pkg (via=${dump.commandOutput.executedVia}): [${dump.failureType}] ${dump.failureReason}")
            return null
        }

        val currentTotals = LinkedHashMap<String, Long>()
        for (rec in dump.targetRecords) {
            val existing = currentTotals[rec.layerName]
            if (existing == null || rec.totalFrames > existing) {
                currentTotals[rec.layerName] = rec.totalFrames
            }
        }
        if (currentTotals.isEmpty()) {
            Log.w(TAG, "TimeStats fallback: 0 matching records for $pkg across ${dump.allRecords.size} total layers")
            return null
        }

        if (previousLayerTotals.isEmpty() || previousTimeStatsAtNs == 0L) {
            previousLayerTotals.clear()
            previousLayerTotals.putAll(currentTotals)
            previousTimeStatsAtNs = nowNs
            timeStatsLayer = chooseBestTimeStatsLayer(currentTotals, emptyMap(), pkg, emptySet())
            return Result(
                null,
                "Game FPS: warming up TimeStats fallback for $pkg...",
                recorder.snapshot(),
                500L
            )
        }

        val elapsedMs = (nowNs - previousTimeStatsAtNs) / 1e6
        if (elapsedMs < 250.0) {
            return Result(
                lastTimeStatsFps,
                "Game FPS: collecting TimeStats window for $pkg...",
                recorder.snapshot(),
                450L
            )
        }

        val deltas = LinkedHashMap<String, Long>()
        for ((lName, total) in currentTotals) {
            val prev = previousLayerTotals[lName]
            if (prev != null && total >= prev) {
                deltas[lName] = total - prev
            }
        }

        val selected = chooseBestTimeStatsLayer(currentTotals, deltas, pkg, emptySet()) ?: return null
        timeStatsLayer = selected

        val currentTotal = currentTotals[selected] ?: return null
        val prevTotal = previousLayerTotals[selected]

        if (prevTotal == null || currentTotal < prevTotal) {
            previousLayerTotals.clear()
            previousLayerTotals.putAll(currentTotals)
            previousTimeStatsAtNs = nowNs
            return Result(
                null,
                "Game FPS: switched to new BGMI layer ($selected)...",
                recorder.snapshot(),
                500L
            )
        }

        val delta = currentTotal - prevTotal
        if (delta <= 0L) {
            if (elapsedMs >= 1800.0) {
                previousLayerTotals.clear()
                previousLayerTotals.putAll(currentTotals)
                previousTimeStatsAtNs = nowNs
                lastTimeStatsFps = null
                return Result(
                    null,
                    "Game paused or no new frames ($pkg, TimeStats).",
                    recorder.snapshot(),
                    1000L
                )
            }
            return Result(
                lastTimeStatsFps,
                "Game FPS: waiting for TimeStats frame batch ($pkg)...",
                recorder.snapshot(),
                500L
            )
        }

        previousLayerTotals.clear()
        previousLayerTotals.putAll(currentTotals)
        previousTimeStatsAtNs = nowNs

        val fps = (delta * 1000.0 / elapsedMs).roundToInt().coerceIn(1, 1000)
        lastTimeStatsFps = fps
        recorder.addEstimatedBatch(delta, elapsedMs, fps)
        return Result(
            fps,
            "Game FPS: $pkg (TimeStats fallback • ${dump.commandOutput.executedVia})",
            recorder.snapshot(),
            1000L
        )
    }

    private fun chooseBestTimeStatsLayer(
        currentTotals: Map<String, Long>,
        deltas: Map<String, Long>,
        pkg: String,
        liveListLayers: Set<String>
    ): String? {
        if (currentTotals.isEmpty()) return null

        val validCandidates = currentTotals.keys.filter { scoreLayerName(it, pkg, liveListLayers.contains(it)) >= 0 }
        val pool = validCandidates.ifEmpty { currentTotals.keys.toList() }

        val locked = timeStatsLayer
        if (locked != null && pool.contains(locked)) {
            val lockedDelta = deltas[locked] ?: 0L
            val lockedIsSv = locked.contains("SurfaceView", ignoreCase = true)
            if (lockedDelta > 0L && (lockedIsSv || pool.none { it.contains("SurfaceView", ignoreCase = true) && (deltas[it] ?: 0L) > 0L })) {
                return locked
            }
        }

        val activeLayers = pool.filter { (deltas[it] ?: 0L) > 0L }
        if (activeLayers.isNotEmpty()) {
            return activeLayers.sortedWith(
                compareByDescending<String> { scoreLayerName(it, pkg, liveListLayers.contains(it)) }
                    .thenByDescending { extractSequenceNumber(it) }
                    .thenByDescending { deltas[it] ?: 0L }
            ).firstOrNull()
        }

        return pool.sortedWith(
            compareByDescending<String> { scoreLayerName(it, pkg, liveListLayers.contains(it)) }
                .thenByDescending { extractSequenceNumber(it) }
                .thenByDescending { currentTotals[it] ?: 0L }
        ).firstOrNull()
    }

    // =========================================================================================
    // 4. Dynamic BLAST SurfaceView Layer Discovery & Exact Name Variant Resolution
    // =========================================================================================

    private fun discoverBlastSurfaceViewLayer(
        context: Context,
        pkg: String,
        preFetchedTimeStats: CompleteTimeStatsDump?
    ): LayerDiscoveryReport {
        val listCmd = runSurfaceFlingerCommand(context, "--list")
        val allListLines = if (listCmd.failureType == FailureType.NONE && listCmd.stdout.isNotBlank()) {
            listCmd.stdout.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        } else {
            emptyList()
        }

        val listMatches = allListLines.filter { it.contains(pkg, ignoreCase = true) }.distinct()
        val liveSet = listMatches.toSet()

        val timeStatsDump = preFetchedTimeStats ?: queryCompleteTimeStats(context, pkg, flushActive = false)
        val timeStatsLayerNames = (timeStatsDump.targetRecords + timeStatsDump.bgmiRecords)
            .map { it.layerName.trim() }
            .filter { it.contains(pkg, ignoreCase = true) }
            .distinct()

        val sfDumpMatches = ArrayList<String>()
        if (listMatches.none { it.contains("SurfaceView", ignoreCase = true) } &&
            timeStatsLayerNames.none { it.contains("SurfaceView", ignoreCase = true) }
        ) {
            val fullDump = runSurfaceFlingerCommand(context)
            if (fullDump.failureType == FailureType.NONE && fullDump.stdout.isNotBlank()) {
                fullDump.stdout.lineSequence()
                    .filter { it.contains(pkg, ignoreCase = true) && it.contains("SurfaceView", ignoreCase = true) }
                    .forEach { line ->
                        val m = SF_DUMP_LAYER_RE.find(line)
                        if (m != null) {
                            sfDumpMatches.add(m.groupValues[1].trim())
                        } else {
                            sfDumpMatches.add(line.trim())
                        }
                    }
            }
        }

        val candidateMap = LinkedHashMap<String, DiscoveredLayerCandidate>()
        fun registerCandidate(rawName: String, source: String) {
            val clean = rawName.trim()
            if (clean.isEmpty() || !clean.contains(pkg, ignoreCase = true)) return
            val inLive = liveSet.contains(clean)
            val sc = scoreLayerName(clean, pkg, inLive)
            if (sc < 0) return
            val seq = extractSequenceNumber(clean)
            val candidate = DiscoveredLayerCandidate(
                exactName = clean,
                source = source,
                score = sc,
                sequenceNumber = seq,
                isSurfaceView = clean.contains("SurfaceView", ignoreCase = true),
                isBlast = clean.contains("BLAST", ignoreCase = true),
                isGameActivity = clean.contains("GameActivity", ignoreCase = true) || clean.contains("ue4", ignoreCase = true),
                isInLiveList = inLive
            )
            val existing = candidateMap[clean]
            if (existing == null || candidate.score > existing.score) {
                candidateMap[clean] = candidate
            }
        }

        listMatches.forEach { registerCandidate(it, "--list") }
        timeStatsLayerNames.forEach { registerCandidate(it, "TimeStats") }
        sfDumpMatches.distinct().forEach { registerCandidate(it, "SurfaceFlinger-dump") }

        val baseSurfaceViews = candidateMap.values.filter { it.isSurfaceView }.toList()
        for (sv in baseSurfaceViews) {
            for (variant in expandBlastSurfaceViewVariants(sv.exactName)) {
                if (!candidateMap.containsKey(variant)) {
                    registerCandidate(variant, "synthesized-BLAST-variant")
                }
            }
        }

        val sortedCandidates = candidateMap.values.sortedWith(
            compareByDescending<DiscoveredLayerCandidate> { it.isInLiveList && it.isSurfaceView && it.isBlast }
                .thenByDescending { it.isSurfaceView }
                .thenByDescending { it.sequenceNumber }
                .thenByDescending { it.isBlast }
                .thenByDescending { it.isGameActivity }
                .thenByDescending { it.score }
        )

        val primary = sortedCandidates.firstOrNull()?.exactName
        val variantsToTest = LinkedHashSet<String>()
        if (primary != null) {
            val topSeq = sortedCandidates.first().sequenceNumber
            sortedCandidates
                .filter { it.sequenceNumber == topSeq || it.exactName == primary }
                .forEach { variantsToTest.add(it.exactName) }
            expandBlastSurfaceViewVariants(primary).forEach { variantsToTest.add(it) }
        }
        sortedCandidates.filter { it.isInLiveList && it.isSurfaceView }.take(3).forEach {
            variantsToTest.add(it.exactName)
        }

        val failureType: FailureType
        val failureReason: String?
        if (primary == null) {
            if (listCmd.failureType != FailureType.NONE && timeStatsDump.failureType != FailureType.NONE) {
                failureType = listCmd.failureType
                failureReason = "Both --list (${listCmd.failureReason}) and TimeStats (${timeStatsDump.failureReason}) failed."
            } else {
                failureType = FailureType.NO_MATCHING_LAYER
                failureReason = "No SurfaceView or game layer matching '$pkg' found in --list (${allListLines.size} lines) or TimeStats (${timeStatsDump.allRecords.size} records)."
            }
        } else {
            failureType = FailureType.NONE
            failureReason = null
        }

        return LayerDiscoveryReport(
            listCommandOutput = listCmd,
            totalListLayers = allListLines.size,
            listMatchingLayers = listMatches,
            candidates = sortedCandidates,
            primaryLayer = primary,
            testedVariants = variantsToTest.take(4),
            failureType = failureType,
            failureReason = failureReason
        )
    }

    fun expandBlastSurfaceViewVariants(layerName: String): List<String> {
        val trimmed = layerName.trim()
        val variants = LinkedHashSet<String>()
        variants.add(trimmed)

        UNBRACKETED_SV_RE.matchEntire(trimmed)?.let { m ->
            val inner = m.groupValues[1].trim()
            val seq = m.groupValues[2]
            variants.add("SurfaceView[$inner](BLAST)#$seq")
            variants.add("SurfaceView$inner#$seq")
            variants.add("SurfaceView[$inner]#$seq")
        }

        BRACKETED_BLAST_SV_RE.matchEntire(trimmed)?.let { m ->
            val inner = m.groupValues[1].trim()
            val seq = m.groupValues[2]
            variants.add("SurfaceView[$inner](BLAST)#$seq")
            variants.add("SurfaceView$inner#$seq")
            variants.add("SurfaceView[$inner]#$seq")
        }

        BRACKETED_PLAIN_SV_RE.matchEntire(trimmed)?.let { m ->
            val inner = m.groupValues[1].trim()
            val seq = m.groupValues[2]
            variants.add("SurfaceView[$inner](BLAST)#$seq")
            variants.add("SurfaceView$inner#$seq")
            variants.add("SurfaceView[$inner]#$seq")
        }

        DASH_SV_RE.matchEntire(trimmed)?.let { m ->
            val inner = m.groupValues[1].trim()
            val seq = m.groupValues[2]
            variants.add("SurfaceView[$inner](BLAST)#$seq")
            variants.add("SurfaceView$inner#$seq")
        }

        return variants.toList()
    }

    private fun extractSequenceNumber(layerName: String): Long {
        val m = SEQ_SUFFIX_RE.find(layerName.trim()) ?: return 0L
        return m.groupValues[1].toLongOrNull() ?: 0L
    }

    private fun scoreLayerName(name: String, pkg: String, isInLiveList: Boolean): Int {
        val trimmed = name.trim()
        if (!trimmed.contains(pkg, ignoreCase = true)) return -1000
        if (trimmed.startsWith("Background for", ignoreCase = true) ||
            trimmed.contains("Background for", ignoreCase = true) ||
            trimmed.startsWith("Bounds for", ignoreCase = true) ||
            trimmed.contains("Bounds for", ignoreCase = true) ||
            trimmed.contains("SurfaceControl", ignoreCase = true) ||
            trimmed.contains("Letterbox", ignoreCase = true) ||
            trimmed.contains("Splash Screen", ignoreCase = true) ||
            trimmed.contains("SnapshotStartingWindow", ignoreCase = true) ||
            trimmed.contains("InputMethod", ignoreCase = true)
        ) {
            return -500
        }

        var score = 0
        if (trimmed.contains("SurfaceView", ignoreCase = true)) score += 200
        if (trimmed.contains("(BLAST)", ignoreCase = true)) score += 120
        else if (trimmed.contains("BLAST", ignoreCase = true)) score += 90
        if (trimmed.contains("GameActivity", ignoreCase = true)) score += 80
        if (trimmed.contains("ue4", ignoreCase = true)) score += 40
        if (isInLiveList) score += 100
        return score
    }

    // =========================================================================================
    // 5. Layer-Specific `SurfaceFlinger --latency` Parser (Header vs. Timestamps Separated)
    // =========================================================================================

    fun queryLayerLatency(context: Context?, layerName: String): LatencySampleReport {
        val sampleNs = SystemClock.elapsedRealtimeNanos()
        val cmdOut = runSurfaceFlingerCommand(context, "--latency", layerName)
        return parseLatencyCommandOutput(layerName, cmdOut, sampleNs)
    }

    fun parseLatencyCommandOutput(
        layerName: String,
        cmdOut: CommandOutput,
        sampleElapsedRealtimeNs: Long
    ): LatencySampleReport {
        if (cmdOut.failureType != FailureType.NONE) {
            return LatencySampleReport(
                layerName = layerName,
                commandOutput = cmdOut,
                refreshPeriodNs = null,
                totalFrameRows = 0,
                zeroFrameRows = 0,
                pendingPresentRows = 0,
                malformedRows = 0,
                validDesiredPresentNs = emptyList(),
                validActualPresentNs = emptyList(),
                validFrameReadyNs = emptyList(),
                failureType = cmdOut.failureType,
                failureReason = cmdOut.failureReason,
                sampleElapsedRealtimeNs = sampleElapsedRealtimeNs
            )
        }

        val nonEmptyLines = cmdOut.stdout.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()

        if (nonEmptyLines.isEmpty()) {
            val reason = "SurfaceFlinger --latency \"$layerName\" (via=${cmdOut.executedVia}) returned only whitespace/empty lines."
            return LatencySampleReport(
                layerName = layerName,
                commandOutput = cmdOut,
                refreshPeriodNs = null,
                totalFrameRows = 0,
                zeroFrameRows = 0,
                pendingPresentRows = 0,
                malformedRows = 0,
                validDesiredPresentNs = emptyList(),
                validActualPresentNs = emptyList(),
                validFrameReadyNs = emptyList(),
                failureType = FailureType.EMPTY_DATA,
                failureReason = reason,
                sampleElapsedRealtimeNs = sampleElapsedRealtimeNs
            )
        }

        val headerLine = nonEmptyLines.first()
        val headerTokens = headerLine.split(WHITESPACE)
        val refreshPeriodNs = if (headerTokens.size == 1) headerTokens[0].toLongOrNull() else null
        if (refreshPeriodNs == null || refreshPeriodNs < 0L) {
            val reason = "Unrecognized --latency output for \"$layerName\" (via=${cmdOut.executedVia}): expected single non-negative integer refresh-period header on line 1, got \"${headerLine.take(120)}\"."
            return LatencySampleReport(
                layerName = layerName,
                commandOutput = cmdOut,
                refreshPeriodNs = null,
                totalFrameRows = 0,
                zeroFrameRows = 0,
                pendingPresentRows = 0,
                malformedRows = nonEmptyLines.size,
                validDesiredPresentNs = emptyList(),
                validActualPresentNs = emptyList(),
                validFrameReadyNs = emptyList(),
                failureType = FailureType.UNRECOGNIZED_OUTPUT,
                failureReason = reason,
                sampleElapsedRealtimeNs = sampleElapsedRealtimeNs
            )
        }

        var totalRows = 0
        var zeroRows = 0
        var pendingRows = 0
        var malformedRows = 0
        val validDesired = ArrayList<Long>()
        val validActual = ArrayList<Long>()
        val validReady = ArrayList<Long>()

        for (line in nonEmptyLines.drop(1)) {
            val parts = line.split(WHITESPACE)
            if (parts.size < 3) {
                malformedRows++
                continue
            }
            val desired = parts[0].toLongOrNull()
            val actual = parts[1].toLongOrNull()
            val ready = parts[2].toLongOrNull()
            if (desired == null || actual == null || ready == null) {
                malformedRows++
                continue
            }
            totalRows++
            if (desired == 0L && actual == 0L && ready == 0L) {
                zeroRows++
                continue
            }
            if (actual == INVALID_TS) {
                pendingRows++
            }
            if (desired > 0L && desired != INVALID_TS) validDesired.add(desired)
            if (actual > 0L && actual != INVALID_TS) validActual.add(actual)
            if (ready > 0L && ready != INVALID_TS) validReady.add(ready)
        }

        validDesired.sort()
        validActual.sort()
        validReady.sort()

        val failureType: FailureType
        val failureReason: String?
        when {
            totalRows == 0 && malformedRows > 0 -> {
                failureType = FailureType.UNRECOGNIZED_OUTPUT
                failureReason = "Refresh-period header ($refreshPeriodNs ns) parsed, but all $malformedRows subsequent lines were malformed."
            }
            validActual.isEmpty() -> {
                failureType = FailureType.NO_VALID_TIMESTAMPS
                failureReason = when {
                    totalRows == 0 ->
                        "Header-only output (refreshPeriod=$refreshPeriodNs ns, 0 frame rows, via=${cmdOut.executedVia}). Layer \"$layerName\" did not match an active BufferQueue/BLAST FrameTracker in SurfaceFlinger."
                    zeroRows == totalRows ->
                        "Refresh-period header ($refreshPeriodNs ns) followed by $totalRows all-zero (0 0 0) rows; 0 valid non-zero timestamps returned for \"$layerName\" (via=${cmdOut.executedVia})."
                    validReady.isNotEmpty() ->
                        "0 valid non-zero actualPresentTime timestamps returned ($pendingRows pending INT64_MAX rows, ${validReady.size} valid frameReadyTime rows, refreshPeriod=$refreshPeriodNs ns, via=${cmdOut.executedVia})."
                    else ->
                        "0 valid non-zero timestamps returned across $totalRows frame rows (refreshPeriod=$refreshPeriodNs ns, via=${cmdOut.executedVia})."
                }
            }
            else -> {
                failureType = FailureType.NONE
                failureReason = null
            }
        }

        return LatencySampleReport(
            layerName = layerName,
            commandOutput = cmdOut,
            refreshPeriodNs = refreshPeriodNs,
            totalFrameRows = totalRows,
            zeroFrameRows = zeroRows,
            pendingPresentRows = pendingRows,
            malformedRows = malformedRows,
            validDesiredPresentNs = validDesired,
            validActualPresentNs = validActual,
            validFrameReadyNs = validReady,
            failureType = failureType,
            failureReason = failureReason,
            sampleElapsedRealtimeNs = sampleElapsedRealtimeNs
        )
    }

    // =========================================================================================
    // 6. Complete SurfaceFlinger TimeStats Query & Parser
    // =========================================================================================

    private fun ensureTimeStatsEnabled(context: Context?): CommandOutput {
        val out = runSurfaceFlingerCommand(context, "--timestats", "-enable")
        if (out.failureType == FailureType.NONE) {
            timeStatsEnabled = true
        }
        return out
    }

    fun queryCompleteTimeStats(
        context: Context?,
        targetPkg: String,
        flushActive: Boolean
    ): CompleteTimeStatsDump {
        var cmdOut: CommandOutput
        if (flushActive) {
            cmdOut = runSurfaceFlingerCommand(context, "--timestats", "-disable", "-dump")
            ensureTimeStatsEnabled(context)
            if (cmdOut.failureType == FailureType.NONE &&
                (cmdOut.stdout.isBlank() || (!cmdOut.stdout.contains("layerName") && !cmdOut.stdout.contains("TimeStats")))
            ) {
                cmdOut = runSurfaceFlingerCommand(context, "--timestats", "-dump")
            }
        } else {
            cmdOut = runSurfaceFlingerCommand(context, "--timestats", "-dump")
        }

        var parsed = parseCompleteTimeStatsOutput(cmdOut, targetPkg)

        if (parsed.allRecords.isEmpty() && cmdOut.failureType == FailureType.NONE) {
            val highLimitOut = if (flushActive) {
                val r = runSurfaceFlingerCommand(context, "--timestats", "-disable", "-dump", "-maxlayers", "4096")
                ensureTimeStatsEnabled(context)
                r
            } else {
                runSurfaceFlingerCommand(context, "--timestats", "-dump", "-maxlayers", "4096")
            }
            val highLimitParsed = parseCompleteTimeStatsOutput(highLimitOut, targetPkg)
            if (highLimitParsed.allRecords.size > parsed.allRecords.size ||
                highLimitOut.stdout.length > cmdOut.stdout.length
            ) {
                parsed = highLimitParsed
            }
        }

        return parsed
    }

    fun parseCompleteTimeStatsOutput(cmdOut: CommandOutput, targetPkg: String): CompleteTimeStatsDump {
        if (cmdOut.failureType != FailureType.NONE) {
            return CompleteTimeStatsDump(
                commandOutput = cmdOut,
                globalHeaderLines = emptyList(),
                allRecords = emptyList(),
                targetRecords = emptyList(),
                bgmiRecords = emptyList(),
                failureType = cmdOut.failureType,
                failureReason = cmdOut.failureReason
            )
        }

        val globalLines = ArrayList<String>()
        val allRecords = ArrayList<TimeStatsLayerRecord>()

        var curLayerName: String? = null
        var curPkgName: String = ""
        var curUid: Int? = null
        var curTotalFrames: Long? = null
        var curDroppedFrames: Long? = null
        var curLateLatchingFrames: Long? = null
        var curAvgFps: Double? = null
        var curLines = ArrayList<String>()

        fun flushCurrentRecord() {
            val name = curLayerName
            val total = curTotalFrames
            if (name != null && total != null) {
                allRecords.add(
                    TimeStatsLayerRecord(
                        layerName = name,
                        packageName = curPkgName,
                        uid = curUid,
                        totalFrames = total,
                        droppedFrames = curDroppedFrames,
                        lateLatchingFrames = curLateLatchingFrames,
                        averageFps = curAvgFps,
                        rawLines = curLines.toList()
                    )
                )
            }
            curLayerName = null
            curPkgName = ""
            curUid = null
            curTotalFrames = null
            curDroppedFrames = null
            curLateLatchingFrames = null
            curAvgFps = null
            curLines = ArrayList()
        }

        for (rawLine in cmdOut.stdout.lineSequence()) {
            val trimmed = rawLine.trim()
            if (trimmed.isEmpty()) continue

            val layerMatch = TS_LAYER_RE.find(trimmed)
            if (layerMatch != null) {
                flushCurrentRecord()
                curLayerName = cleanTimeStatsValue(layerMatch.groupValues[1])
            }

            if (curLayerName == null) {
                if (globalLines.size < 12) {
                    globalLines.add(trimmed)
                }
                continue
            }

            curLines.add(trimmed)
            TS_PKG_RE.find(trimmed)?.let { m ->
                curPkgName = cleanTimeStatsValue(m.groupValues[1])
            }
            TS_UID_RE.find(trimmed)?.let { m ->
                curUid = m.groupValues[1].toIntOrNull()
            }
            TS_TOTAL_RE.find(trimmed)?.let { m ->
                curTotalFrames = m.groupValues[1].toLongOrNull()
            }
            TS_DROPPED_RE.find(trimmed)?.let { m ->
                curDroppedFrames = m.groupValues[1].toLongOrNull()
            }
            TS_LATE_RE.find(trimmed)?.let { m ->
                curLateLatchingFrames = m.groupValues[1].toLongOrNull()
            }
            TS_AVG_FPS_RE.find(trimmed)?.let { m ->
                curAvgFps = m.groupValues[1].toDoubleOrNull()
            }
        }
        flushCurrentRecord()

        val looksLikeTimeStats = cmdOut.stdout.contains("TimeStats", ignoreCase = true) ||
            cmdOut.stdout.contains("totalFrames", ignoreCase = true) ||
            allRecords.isNotEmpty()

        val targetRecords = allRecords.filter {
            it.layerName.contains(targetPkg, ignoreCase = true) ||
                it.packageName.contains(targetPkg, ignoreCase = true)
        }
        val bgmiRecords = allRecords.filter {
            it.layerName.contains(BGMI_PACKAGE, ignoreCase = true) ||
                it.packageName.contains(BGMI_PACKAGE, ignoreCase = true)
        }

        val failureType: FailureType
        val failureReason: String?
        when {
            !looksLikeTimeStats -> {
                failureType = FailureType.UNRECOGNIZED_OUTPUT
                failureReason = "Unrecognized SurfaceFlinger --timestats output (via=${cmdOut.executedVia}): \"${cmdOut.stdout.take(140).replace('\n', ' ')}\""
            }
            targetRecords.isEmpty() -> {
                failureType = FailureType.NO_MATCHING_LAYER
                failureReason = "Parsed ${allRecords.size} layer record(s) in complete TimeStats dump (via=${cmdOut.executedVia}), but 0 records matched '$targetPkg'."
            }
            else -> {
                failureType = FailureType.NONE
                failureReason = null
            }
        }

        return CompleteTimeStatsDump(
            commandOutput = cmdOut,
            globalHeaderLines = globalLines,
            allRecords = allRecords,
            targetRecords = targetRecords,
            bgmiRecords = bgmiRecords,
            failureType = failureType,
            failureReason = failureReason
        )
    }

    private fun cleanTimeStatsValue(raw: String): String {
        var s = raw.trim().trim('"').trim()
        if (s.startsWith("[") && s.endsWith("]") && s.length >= 2) {
            val inner = s.substring(1, s.length - 1)
            var depth = 0
            var balanced = true
            for (ch in inner) {
                if (ch == '[') depth++
                else if (ch == ']') {
                    depth--
                    if (depth < 0) {
                        balanced = false
                        break
                    }
                }
            }
            if (balanced && depth == 0) {
                s = inner.trim()
            }
        }
        return s
    }

    // =========================================================================================
    // 7. SurfaceFlinger Execution Layer (Shizuku Privileged Shell Priority & Strict Classification)
    // =========================================================================================

    /**
     * Routes SurfaceFlinger commands:
     * 1. When Shizuku is READY, ALWAYS executes via Shizuku's remote process API (`executedVia = "Shizuku"`).
     *    If Shizuku process execution fails, reports the exact Shizuku failure directly and NEVER falls back
     *    to unprivileged `direct` execution.
     * 2. If Shizuku is NOT READY, only attempts `direct` execution if `android.permission.DUMP` is granted
     *    on the app AND `directDumpDenied` is false.
     * 3. Never interprets `exitCode=0` as success if `stderr` or `stdout` contains `Permission Denial`.
     */
    private fun runSurfaceFlingerCommand(
        context: Context?,
        vararg args: String,
        timeoutMs: Long = 5000L
    ): CommandOutput {
        val fullArgs = listOf("dumpsys", "SurfaceFlinger") + args
        val cmdDisplay = fullArgs.joinToString(" ")
        val isFlagOnlyCommand = args.any { it == "-enable" || it == "-disable" || it == "-clear" } &&
            args.none { it == "-dump" }

        val shizukuState = ShizukuHelper.state()
        if (shizukuState == ShizukuHelper.State.READY) {
            val viaShizuku = runSurfaceFlingerViaShizuku(fullArgs, isFlagOnlyCommand, timeoutMs)
            Log.d(
                TAG,
                "SurfaceFlinger command [$cmdDisplay] executed via=Shizuku, exit=${viaShizuku.exitCode}, " +
                    "stdout=${viaShizuku.stdout.length}B, stderr=${viaShizuku.stderr.length}B, failure=${viaShizuku.failureType}"
            )
            if (viaShizuku.failureReason != null) {
                Log.w(TAG, "Shizuku SurfaceFlinger command failure [$cmdDisplay]: [${viaShizuku.failureType}] ${viaShizuku.failureReason}")
            }
            return viaShizuku
        }

        val directPermGranted = context?.let { hasDirectDumpPermission(it) } ?: false
        if (directDumpDenied || !directPermGranted) {
            val reason = if (directDumpDenied) {
                "Direct application-context dumpsys was denied by SurfaceFlinger (Permission Denial), and Shizuku is currently $shizukuState."
            } else {
                "DUMP permission is false on application context, and Shizuku is currently $shizukuState."
            }
            Log.w(TAG, "Refusing unprivileged direct execution [$cmdDisplay]: $reason")
            return CommandOutput(
                command = cmdDisplay,
                stdout = "",
                stderr = "",
                exitCode = -1,
                executedVia = "Shizuku-unavailable($shizukuState)",
                failureType = FailureType.PERMISSION_ERROR,
                failureReason = reason
            )
        }

        val direct = runDirectProcess(fullArgs, timeoutMs, isFlagOnlyCommand)
        Log.d(
            TAG,
            "SurfaceFlinger command [$cmdDisplay] executed via=direct, exit=${direct.exitCode}, " +
                "stdout=${direct.stdout.length}B, stderr=${direct.stderr.length}B, failure=${direct.failureType}"
        )
        if (direct.failureType == FailureType.PERMISSION_ERROR) {
            directDumpDenied = true
            Log.w(TAG, "Direct dumpsys denied by SurfaceFlinger [$cmdDisplay]: ${direct.failureReason}")
        }
        return direct
    }

    private fun runSurfaceFlingerViaShizuku(
        fullArgs: List<String>,
        allowEmptyStdout: Boolean,
        timeoutMs: Long
    ): CommandOutput {
        val cmdDisplay = fullArgs.joinToString(" ")
        val shizukuRes = ShizukuHelper.execShellArgs(fullArgs, timeoutMs)
        if (!shizukuRes.processCreated) {
            return CommandOutput(
                command = cmdDisplay,
                stdout = shizukuRes.stdout,
                stderr = shizukuRes.stderr,
                exitCode = shizukuRes.exitCode,
                executedVia = "Shizuku",
                failureType = FailureType.SHIZUKU_EXEC_ERROR,
                failureReason = "Shizuku remote process creation failed: ${shizukuRes.error ?: "unknown error"}"
            )
        }
        return classifyCommandOutput(
            command = cmdDisplay,
            stdout = shizukuRes.stdout,
            stderr = shizukuRes.stderr,
            exitCode = shizukuRes.exitCode,
            executedVia = "Shizuku",
            execError = shizukuRes.error,
            allowEmptyStdout = allowEmptyStdout
        )
    }

    private fun runDirectProcess(
        fullArgs: List<String>,
        timeoutMs: Long,
        allowEmptyStdout: Boolean
    ): CommandOutput {
        val cmdDisplay = fullArgs.joinToString(" ")
        var process: Process? = null
        return try {
            process = ProcessBuilder(fullArgs).start()
            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()
            val outThread = Thread {
                try {
                    process.inputStream.bufferedReader().use { stdoutBuilder.append(it.readText()) }
                } catch (_: Throwable) {
                }
            }
            val errThread = Thread {
                try {
                    process.errorStream.bufferedReader().use { stderrBuilder.append(it.readText()) }
                } catch (_: Throwable) {
                }
            }
            var exitCode = -1
            var waitErr: Throwable? = null
            val waitThread = Thread {
                try {
                    exitCode = process.waitFor()
                } catch (t: Throwable) {
                    waitErr = t
                }
            }
            outThread.start()
            errThread.start()
            waitThread.start()
            waitThread.join(timeoutMs)
            val timedOut = waitThread.isAlive
            if (timedOut) {
                process.destroyForcibly()
                waitThread.join(300L)
            }
            outThread.join(1000L)
            errThread.join(1000L)

            classifyCommandOutput(
                command = cmdDisplay,
                stdout = stdoutBuilder.toString(),
                stderr = stderrBuilder.toString(),
                exitCode = exitCode,
                executedVia = "direct",
                execError = when {
                    timedOut -> "Direct process timed out after ${timeoutMs}ms"
                    waitErr != null -> "${waitErr?.javaClass?.simpleName}: ${waitErr?.message}"
                    else -> null
                },
                allowEmptyStdout = allowEmptyStdout
            )
        } catch (e: Exception) {
            val msg = "${e.javaClass.simpleName}: ${e.message ?: "execution error"}"
            CommandOutput(
                command = cmdDisplay,
                stdout = "",
                stderr = "",
                exitCode = -1,
                executedVia = "direct",
                failureType = FailureType.COMMAND_ERROR,
                failureReason = msg
            )
        } finally {
            try {
                process?.destroy()
            } catch (_: Throwable) {
            }
        }
    }

    /**
     * Inspects `stdout`, `stderr`, and `exitCode` separately.
     * Never treats `exitCode=0` as success if `stderr` or `stdout` contains `Permission Denial`.
     */
    private fun classifyCommandOutput(
        command: String,
        stdout: String,
        stderr: String,
        exitCode: Int,
        executedVia: String,
        execError: String?,
        allowEmptyStdout: Boolean
    ): CommandOutput {
        // Check Permission Denial in stderr and stdout FIRST, regardless of exitCode == 0!
        val stderrPermissionDenial = containsPermissionDenial(stderr)
        val stdoutPermissionDenial = containsPermissionDenial(stdout)
        if (stderrPermissionDenial || stdoutPermissionDenial) {
            val sourceStream = if (stderrPermissionDenial) "stderr" else "stdout"
            val rawSource = if (stderrPermissionDenial) stderr else stdout
            val detail = rawSource.lineSequence().firstOrNull {
                containsPermissionDenial(it)
            }?.trim() ?: rawSource.trim().take(180)
            return CommandOutput(
                command = command,
                stdout = stdout,
                stderr = stderr,
                exitCode = exitCode,
                executedVia = executedVia,
                failureType = FailureType.PERMISSION_ERROR,
                failureReason = "Permission error in $sourceStream (via=$executedVia, exit=$exitCode): $detail"
            )
        }

        if (execError != null) {
            return CommandOutput(
                command = command,
                stdout = stdout,
                stderr = stderr,
                exitCode = exitCode,
                executedVia = executedVia,
                failureType = if (executedVia == "Shizuku") FailureType.SHIZUKU_EXEC_ERROR else FailureType.COMMAND_ERROR,
                failureReason = "Execution error (via=$executedVia, exit=$exitCode): $execError"
            )
        }

        if (exitCode != 0 && stdout.isBlank()) {
            val errDetail = stderr.trim().take(180).ifEmpty { "non-zero exit code $exitCode with empty stdout" }
            return CommandOutput(
                command = command,
                stdout = stdout,
                stderr = stderr,
                exitCode = exitCode,
                executedVia = executedVia,
                failureType = if (executedVia == "Shizuku") FailureType.SHIZUKU_EXEC_ERROR else FailureType.COMMAND_ERROR,
                failureReason = "Command exited with code $exitCode (via=$executedVia): $errDetail"
            )
        }

        if (!allowEmptyStdout && stdout.isBlank()) {
            val errNote = stderr.trim().take(180).ifEmpty { "stdout and stderr were both empty" }
            return CommandOutput(
                command = command,
                stdout = stdout,
                stderr = stderr,
                exitCode = exitCode,
                executedVia = executedVia,
                failureType = FailureType.EMPTY_DATA,
                failureReason = "Empty stdout from '$command' (via=$executedVia, exit=$exitCode): $errNote"
            )
        }

        return CommandOutput(
            command = command,
            stdout = stdout,
            stderr = stderr,
            exitCode = exitCode,
            executedVia = executedVia,
            failureType = FailureType.NONE,
            failureReason = null
        )
    }

    private fun containsPermissionDenial(text: String): Boolean {
        if (text.isEmpty()) return false
        return text.contains("Permission Denial", ignoreCase = true) ||
            text.contains("can't dump SurfaceFlinger", ignoreCase = true) ||
            text.contains("SecurityException", ignoreCase = true) ||
            text.contains("avc: denied", ignoreCase = true) ||
            text.contains("Operation not permitted", ignoreCase = true) ||
            text.contains("Can't find service: SurfaceFlinger", ignoreCase = true)
    }

    private fun isIgnorableNonGamePackage(context: Context, pkg: String): Boolean {
        if (pkg == context.packageName) return true
        if (IGNORABLE_SYSTEM_PACKAGES.contains(pkg)) return true
        val lower = pkg.lowercase(Locale.US)
        if (lower.contains("resolver") ||
            lower.contains("launcher") ||
            lower.contains("systemui") ||
            lower.contains("permissioncontroller") ||
            lower.contains("inputmethod") ||
            lower.contains("keyboard") ||
            lower.contains("shizuku")
        ) {
            return true
        }
        val homePkg = cachedHomePackage ?: run {
            val resolved = try {
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                    ?.activityInfo?.packageName
            } catch (_: Exception) {
                null
            }
            cachedHomePackage = resolved
            resolved
        }
        return homePkg != null && pkg == homePkg
    }
}
