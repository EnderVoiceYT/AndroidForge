# TempRamReader v14 — AndroidForge source (Shizuku Remote Process Execution & BGMI FPS Fix)

This archive preserves the AndroidForge project structure and package name (`com.example.tempramreader`). Upload the ZIP to AndroidForge and build the `app` module / debug APK as usual.

## Shizuku Execution Layer & BGMI (`com.pubg.imobile`) FPS Fixes

1. **Fixed `ShizukuRemoteProcess` Execution Crash**:
   - `ShizukuRemoteProcess` does not override `java.lang.Process.waitFor(long, TimeUnit)`. Calling `Process.waitFor(long, TimeUnit)` immediately invoked `exitValue()` at `t=0ms` while the remote process was still running, throwing a `RuntimeException` across Binder IPC and destroying the Shizuku process before any output could be read.
   - `ShizukuHelper.execShellArgs` now invokes `Shizuku.newProcess(arrayOf("sh", "-c", quotedArgs), null, null)` (with fallback to `Shizuku.requireService().newProcess`), drains `stdout` and `stderr` on separate threads, and waits using the 0-arg `ShizukuRemoteProcess.waitFor()` on a dedicated timeout-bounded waiter thread.
2. **Shizuku Shell Identity & SurfaceFlinger Confirmation Gate (`[Step 0]`)**:
   - Verifies Shizuku binder state, user authorization (`checkSelfPermission() == PERMISSION_GRANTED`), server UID (`2000`/`0`), and SELinux context.
   - Runs `id` and `dumpsys SurfaceFlinger --list` under the Shizuku remote process to confirm execution under the Shizuku shell identity before starting FPS acquisition.
3. **Strict Command Routing & Output Classification**:
   - Routes ALL SurfaceFlinger commands (`dumpsys SurfaceFlinger --list`, `dumpsys SurfaceFlinger --timestats -dump`, `dumpsys SurfaceFlinger --latency <layer>`) through the Shizuku shell execution path (`via=Shizuku`) whenever Shizuku is `READY` or direct `dumpsys` is denied.
   - Captures `stdout`, `stderr`, and `exitCode` separately, never treats `exitCode=0` as success if `stderr` or `stdout` contains `Permission Denial`, and never silently falls back to unprivileged `direct` execution when Shizuku is `READY`.
4. **Multi-Window & Share-Sheet Resolver Resilience**:
   - Prevents Infinix's share sheet (`com.transsion.resolver`) or the `TempRamReader` floating window from overriding or clearing the active `com.pubg.imobile` game session.
