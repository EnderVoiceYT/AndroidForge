package com.example.tempramreader.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/**
 * Uses Shizuku once to run `pm grant <this app> android.permission.DUMP`.
 * After that the app no longer needs Shizuku: Game FPS works on its own.
 */
object ShizukuHelper {
    enum class State { NOT_RUNNING, NEEDS_PERMISSION, READY }

    private const val REQUEST_CODE = 4242

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() || Shizuku.isPreV11() -> State.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NEEDS_PERMISSION
        }
    } catch (_: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
    }

    // Shizuku.newProcess is private in API 13+, so it is called through reflection (a common approach).
    private fun newShellProcess(command: Array<String>): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, command, null, null) as Process
    }

    /** Returns a short message for the UI. */
    suspend fun grantDump(context: Context): String = withContext(Dispatchers.IO) {
        if (state() != State.READY) return@withContext "Shizuku isn't ready."
        var proc: Process? = null
        try {
            val cmd = arrayOf("sh", "-c", "pm grant ${context.packageName} android.permission.DUMP")
            proc = newShellProcess(cmd)
            val output = proc.inputStream.bufferedReader().use { it.readText() }.trim()
            val err = proc.errorStream.bufferedReader().use { it.readText() }.trim()
            proc.waitFor()
            if (context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED) {
                "Permission granted. Game FPS is ready."
            } else {
                "Grant didn't work: ${(err.ifEmpty { output }).take(120).ifEmpty { "no output" }}"
            }
        } catch (t: Throwable) {
            "Shizuku call failed: ${t.javaClass.simpleName}"
        } finally {
            proc?.destroy()
        }
    }
}
