package com.example.tempramreader.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import kotlin.math.roundToInt

/** Reads game-layer frame data from SurfaceFlinger. Requires android.permission.DUMP. */
object GameFpsReader {
    class Result(
        val fps: Int?,
        val status: String,
        val session: FpsSessionStats? = null,
        val nextDelayMs: Long = 1000L
    )

    private data class FrameTimeData(
        val timestampsNs: List<Long>,
        val usesPresentationTimestamps: Boolean
    )

    private const val INVALID_TS = Long.MAX_VALUE
    private val WHITESPACE = Regex("\\s+")
    private val LAYER_RE = Regex("""(?:layerName|layer_name)\s*[=:]\s*"?([^"\r\n]+?)"?\s*$""")
    private val TOTAL_RE = Regex("""(?:totalFrames|total_frames)\s*[=:]\s*(\d+)""")

    private val recorder = FpsSessionRecorder()
    private var currentPkg: String? = null
    private var layer: String? = null
    private var lastTs = 0L
    private var staleStreak = 0

    private var latencyFailStreak = 0
    private var latencyRetryAtMs = 0L

    private var timeStatsEnabled = false
    private var timeStatsLayer: String? = null
    private var previousTimeStatsTotal: Long? = null
    private var previousTimeStatsAtNs = 0L

    private var failStreak = 0
    private var diagCaptured = false

    @Volatile
    var lastDiagnostics: String? = null
        private set

    fun hasPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED

    @Synchronized
    fun resetSession() {
        recorder.reset(currentPkg ?: "")
    }

    @Synchronized
    fun sample(context: Context): Result {
        if (!hasPermission(context)) return Result(null, "Game FPS needs the DUMP permission.")

        val (pkg, _) = ForegroundAppDetector.getForegroundApp(context)
        if (pkg == ForegroundAppDetector.NO_PERMISSION) {
            return Result(null, "Grant Usage Access so the app knows which game is open.")
        }
        if (pkg == ForegroundAppDetector.NO_FOREGROUND_APP) {
            return Result(null, "No foreground game detected. Open a game to start its FPS session.")
        }
        if (pkg == context.packageName) {
            return Result(null, "Open a game: the foreground app is this one.")
        }

        if (pkg != currentPkg) {
            currentPkg = pkg
            layer = null
            lastTs = 0L
            staleStreak = 0
            latencyFailStreak = 0
            latencyRetryAtMs = 0L
            timeStatsLayer = null
            previousTimeStatsTotal = null
            previousTimeStatsAtNs = 0L
            failStreak = 0
            diagCaptured = false
            lastDiagnostics = null
            recorder.reset(pkg)
        }

        val now = System.currentTimeMillis()
        if (now >= latencyRetryAtMs) {
            val latencyResult = sampleLatency(pkg)
            if (latencyResult != null) {
                latencyFailStreak = 0
                failStreak = 0
                return latencyResult
            }
            latencyFailStreak++
            if (latencyFailStreak >= 3) {
                latencyRetryAtMs = now + 30_000L
                latencyFailStreak = 0
            }
        }

        val timeStatsResult = sampleTimeStats(pkg)
        if (timeStatsResult != null) {
            failStreak = 0
            return timeStatsResult
        }

        failStreak++
        if (failStreak >= 6 && !diagCaptured) {
            lastDiagnostics = buildDiagnostics(context, pkg)
            diagCaptured = true
        }
        return Result(
            null,
            "No usable frame data for $pkg yet. Keep the game running; share diagnostics if this persists.",
            recorder.snapshot()
        )
    }

    // Strategy A: individual frame presentation timestamps from SurfaceFlinger --latency.
    private fun sampleLatency(pkg: String): Result? {
        if (layer == null || staleStreak >= 3) {
            layer = findLayer(pkg)
            staleStreak = 0
            lastTs = 0L
        }
        val name = layer ?: return null
        val data = frameTimes(name)
        val stamps = data.timestampsNs
        if (stamps.size < 2) {
            staleStreak++
            return null
        }

        val newest = stamps.last()
        if (lastTs == 0L) {
            lastTs = newest
            return Result(null, "Game FPS: calibrating frame timestamps for $pkg...", recorder.snapshot())
        }
        if (newest <= lastTs) {
            staleStreak++
            return null // paused or selected layer stopped producing frames
        }
        staleStreak = 0

        var previous: Long? = if (stamps.binarySearch(lastTs) >= 0) lastTs else null
        for (timestamp in stamps) {
            if (timestamp <= lastTs) continue
            val before = previous
            if (before != null) recorder.addFrame((timestamp - before) / 1e6)
            previous = timestamp
        }
        lastTs = newest

        val inWindow = stamps.filter { it >= newest - 1_000_000_000L }
        if (inWindow.size < 2) {
            return Result(null, "Game FPS: waiting for more presented frames ($pkg)...", recorder.snapshot())
        }
        val spanSec = (inWindow.last() - inWindow.first()) / 1e9
        if (spanSec <= 0.0) {
            return Result(null, "Game FPS: waiting for valid frame timestamps ($pkg)...", recorder.snapshot())
        }
        val fps = ((inWindow.size - 1) / spanSec).roundToInt().coerceIn(1, 1000)
        recorder.addSecondFps(fps)
        val sourceLabel = if (data.usesPresentationTimestamps) "presented" else "frame-ready estimate"
        return Result(
            fps,
            "Game FPS: $pkg ($sourceLabel)",
            recorder.snapshot(),
            if (fps >= 90) 700L else 1000L
        )
    }

    /** Prefer the game's primary SurfaceView (typically GameActivity) over auxiliary layers. */
    private fun findLayer(pkg: String): String? {
        val out = runDumpsys("SurfaceFlinger", "--list") ?: return null
        val candidates = out.lineSequence()
            .map { it.trim() }
            .filter {
                it.contains(pkg) &&
                    !it.startsWith("Background for") &&
                    !it.startsWith("Bounds for")
            }
            .distinct()
            .sortedWith(
                compareByDescending<String> { layerScore(it) }
            )
            .take(20)

        data class Candidate(val name: String, val score: Int, val newest: Long)
        val readable = candidates.mapNotNull { candidate ->
            val data = frameTimes(candidate)
            val newest = data.timestampsNs.lastOrNull() ?: return@mapNotNull null
            Candidate(candidate, layerScore(candidate), newest)
        }
        return readable.sortedWith(
            compareByDescending<Candidate> { it.score }.thenByDescending { it.newest }
        ).firstOrNull()?.name
    }

    private fun layerScore(name: String): Int {
        var score = 0
        if (name.contains("SurfaceView", ignoreCase = true)) score += 100
        if (name.contains("GameActivity", ignoreCase = true)) score += 40
        if (name.contains("BLAST", ignoreCase = true)) score += 10
        if (name.contains("Background", ignoreCase = true)) score -= 100
        if (name.contains("Bounds", ignoreCase = true)) score -= 100
        return score
    }

    /** The second column is actual-present time; third is frame-ready time. */
    private fun frameTimes(layerName: String): FrameTimeData {
        val out = runDumpsys("SurfaceFlinger", "--latency", layerName) ?:
            return FrameTimeData(emptyList(), true)
        val actualPresent = ArrayList<Long>()
        val frameReady = ArrayList<Long>()
        out.lineSequence().drop(1).forEach { line ->
            val parts = line.trim().split(WHITESPACE)
            if (parts.size >= 3) {
                parts[1].toLongOrNull()?.let {
                    if (it > 0L && it != INVALID_TS) actualPresent.add(it)
                }
                parts[2].toLongOrNull()?.let {
                    if (it > 0L && it != INVALID_TS) frameReady.add(it)
                }
            }
        }
        return if (actualPresent.size >= 2) {
            FrameTimeData(actualPresent.sorted(), true)
        } else {
            FrameTimeData(frameReady.sorted(), false)
        }
    }

    // Strategy B: use the counter delta for ONE stable primary layer, never the max across layers.
    private fun sampleTimeStats(pkg: String): Result? {
        if (!timeStatsEnabled) {
            val enableResult = runDumpsys("SurfaceFlinger", "--timestats", "-enable")
            if (enableResult != null) timeStatsEnabled = true else return null
        }
        val out = runDumpsys("SurfaceFlinger", "--timestats", "-dump", "-maxlayers", "50") ?: return null
        val totals = parseTimeStats(out, pkg)
        if (totals.isEmpty()) return null

        val selected = timeStatsLayer?.takeIf { totals.containsKey(it) }
            ?: layer?.takeIf { totals.containsKey(it) }
            ?: totals.keys.sortedWith(
                compareByDescending<String> { layerScore(it) }
                    .thenBy { it.length }
            ).firstOrNull()
            ?: return null
        if (selected != timeStatsLayer) {
            timeStatsLayer = selected
            previousTimeStatsTotal = null
            previousTimeStatsAtNs = 0L
        }
        val total = totals[selected] ?: return null
        val nowNs = SystemClock.elapsedRealtimeNanos()
        val previousTotal = previousTimeStatsTotal
        val previousAtNs = previousTimeStatsAtNs
        previousTimeStatsTotal = total
        previousTimeStatsAtNs = nowNs

        if (previousTotal == null || previousAtNs == 0L || total < previousTotal) {
            return Result(null, "Game FPS: warming up TimeStats for $pkg...", recorder.snapshot())
        }
        val elapsedMs = (nowNs - previousAtNs) / 1e6
        if (elapsedMs < 300.0) return Result(null, "Game FPS: collecting TimeStats for $pkg...", recorder.snapshot())
        val delta = total - previousTotal
        if (delta <= 0L) {
            return Result(null, "Game paused or no new frames ($pkg, TimeStats).", recorder.snapshot())
        }
        val fps = (delta * 1000.0 / elapsedMs).roundToInt().coerceIn(1, 1000)
        recorder.addEstimatedBatch(delta, elapsedMs, fps)
        return Result(fps, "Game FPS: $pkg (TimeStats estimate)", recorder.snapshot())
    }

    private fun parseTimeStats(out: String, pkg: String): Map<String, Long> {
        val result = LinkedHashMap<String, Long>()
        var currentLayer: String? = null
        for (line in out.lineSequence()) {
            val trimmed = line.trim()
            val layerMatch = LAYER_RE.find(trimmed)
            if (layerMatch != null) {
                currentLayer = layerMatch.groupValues[1].trim().trim('"')
                continue
            }
            val totalMatch = TOTAL_RE.find(trimmed)
            val name = currentLayer
            if (totalMatch != null && name != null) {
                if (name.contains(pkg)) {
                    totalMatch.groupValues[1].toLongOrNull()?.let { result[name] = it }
                }
                currentLayer = null
            }
        }
        return result
    }

    private fun buildDiagnostics(context: Context, pkg: String): String {
        val sb = StringBuilder()
        sb.appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("DUMP granted: ${hasPermission(context)}")
        sb.appendLine("Foreground package: $pkg")

        val list = runDumpsys("SurfaceFlinger", "--list")
        if (list == null) {
            sb.appendLine("--list: failed to run")
        } else {
            val lines = list.lines()
            val matches = lines.filter { it.contains(pkg) }
            sb.appendLine("--list: ${lines.size} lines, ${matches.size} match the package")
            lines.take(3).forEach { sb.appendLine("  list head: ${it.take(100)}") }
            for (match in matches.take(8)) {
                sb.appendLine("LAYER: ${match.take(160)}")
                val latency = runDumpsys("SurfaceFlinger", "--latency", match.trim())
                sb.appendLine("  latency: " + (latency?.lineSequence()?.take(5)?.joinToString(" | ") { it.take(70) } ?: "failed"))
            }
        }

        val stats = runDumpsys("SurfaceFlinger", "--timestats", "-dump", "-maxlayers", "50")
        if (stats == null) {
            sb.appendLine("timestats: failed to run")
        } else {
            sb.appendLine("timestats: ${stats.length} chars")
            stats.lineSequence()
                .filter {
                    it.contains(pkg) || it.contains("otalFrames") ||
                        it.contains("otal_frames") || it.contains("ayer")
                }
                .take(25)
                .forEach { sb.appendLine("  ${it.trim().take(120)}") }
        }
        return sb.toString()
    }

    private fun runDumpsys(vararg args: String): String? {
        var process: Process? = null
        return try {
            process = ProcessBuilder(listOf("dumpsys") + args)
                .redirectErrorStream(true)
                .start()
            process.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            process?.destroy()
        }
    }
}
