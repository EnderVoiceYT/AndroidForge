# TempRamReader v12 — AndroidForge source

This archive keeps the existing Android project structure and package name (`com.example.tempramreader`). Upload the ZIP to AndroidForge as a source project and build the `app` module / debug APK as usual.

## FPS changes in this revision

- Prefers the game's primary SurfaceView/GameActivity layer when selecting a SurfaceFlinger layer.
- Strategy A uses SurfaceFlinger actual-present timestamps when available. If the ROM only returns frame-ready timestamps, the status explicitly labels the reading as an estimate.
- Strategy B uses the frame-counter delta from one stable selected game layer. It no longer takes the highest counter increase across every matching layer.
- TimeStats session average is weighted by frames and elapsed sampling time rather than averaging poll values equally.
- The UI marks a TimeStats-derived average with `~` and does not claim a real 1% low or jank count when individual frame intervals are unavailable.
- Paused/no-new-frame states show `--` with a status message instead of a misleading `0 FPS`.
- Foreground detection uses the modern Activity Resumed/Paused UsageEvents constants on Android 10+ and the legacy names on older Android versions.
- Added an explicit Compose Material Icons Core dependency used by the overlay close icon.

## Permissions needed for Game FPS

1. Grant Usage Access so the app can identify the foreground game.
2. Grant `android.permission.DUMP` using the existing Shizuku one-tap flow or the ADB command shown in the app.
3. Keep the monitoring service active and select **Game** as the FPS source.

## Important measurement note

SurfaceFlinger access and layer reporting vary by Android version and OEM. Actual-present timestamps provide the best per-frame data. TimeStats is a counter-based estimate and cannot provide true per-frame 1% lows or jank. The final readings must be checked on the target phone while a game is running; this environment does not contain an Android SDK/Gradle installation, so a complete APK build or on-device validation could not be performed here.
