package com.example.tempramreader.data

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process

object ForegroundAppDetector {
    const val NO_PERMISSION = "Permission Required"
    private const val HOME_FALLBACK = "com.android.systemui"

    // Incremental event tracking: we remember the current foreground app and only read new events.
    private var currentPkg: String? = null
    private var lastQueryMs = 0L
    private val labelCache = HashMap<String, String>()

    fun hasUsageStatsPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    @Synchronized
    @Suppress("DEPRECATION")
    fun getForegroundApp(context: Context): Pair<String, String> {
        if (!hasUsageStatsPermission(context)) {
            return Pair(NO_PERMISSION, "Grant Usage Access in Settings")
        }

        try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            // First call looks back 6 h to learn what is open now; after that only new events are read.
            val from = if (lastQueryMs == 0L) now - 6L * 60 * 60 * 1000 else lastQueryMs
            val events = usm.queryEvents(from, now)
            val event = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                when (event.eventType) {
                    UsageEvents.Event.MOVE_TO_FOREGROUND -> currentPkg = event.packageName
                    UsageEvents.Event.MOVE_TO_BACKGROUND ->
                        if (event.packageName == currentPkg) currentPkg = null
                }
            }
            lastQueryMs = now - 1000 // small overlap so no event is missed; replaying is harmless
        } catch (_: Exception) {
        }

        val pkg = currentPkg ?: return Pair(HOME_FALLBACK, "System / Home")
        return Pair(pkg, labelFor(context, pkg))
    }

    private fun labelFor(context: Context, pkg: String): String =
        labelCache.getOrPut(pkg) {
            try {
                val pm = context.packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (_: Exception) {
                pkg
            }
        }
}
