package com.example.tempramreader.data

/** Summary of one play session (reset when the game changes or when you tap "Reset session"). */
data class FpsSessionStats(
    val pkg: String = "",
    val avgFps: Float = 0f,
    val lowFps1: Float = 0f,     // "1% low": FPS of the slowest 1% of frames
    val minFps: Int = 0,
    val maxFps: Int = 0,
    val jank: Int = 0,           // frame took > 2x the average of the previous 3 frames (and > 20 ms)
    val bigJank: Int = 0,        // frame took > 3x the average of the previous 3 frames (and > 50 ms)
    val seconds: Int = 0
)

private const val BIN_MS = 0.5
private const val BINS = 400   // frame-time histogram: 0.5 ms bins up to 200 ms

class FpsSessionRecorder {
    private val hist = LongArray(BINS + 1)
    private var pkg = ""
    private var startMs = System.currentTimeMillis()
    private var frames = 0L
    private var totalMs = 0.0
    private var minFps = Int.MAX_VALUE
    private var maxFps = 0
    private var jank = 0
    private var bigJank = 0
    private var fpsSum = 0.0
    private var fpsSamples = 0
    private val last3 = DoubleArray(3)
    private var last3Count = 0
    private var last3Pos = 0

    fun reset(newPkg: String) {
        hist.fill(0L)
        pkg = newPkg
        startMs = System.currentTimeMillis()
        frames = 0L
        totalMs = 0.0
        minFps = Int.MAX_VALUE
        maxFps = 0
        jank = 0
        bigJank = 0
        fpsSum = 0.0
        fpsSamples = 0
        last3Count = 0
        last3Pos = 0
    }

    /** One real frame interval in milliseconds. */
    fun addFrame(dtMs: Double) {
        if (dtMs <= 0.0) return
        if (dtMs > 1000.0) {          // pause / loading screen: don't count it
            last3Count = 0
            return
        }
        frames++
        totalMs += dtMs
        hist[(dtMs / BIN_MS).toInt().coerceAtMost(BINS)]++

        if (last3Count == 3) {
            val avg = (last3[0] + last3[1] + last3[2]) / 3.0
            if (dtMs > 2.0 * avg && dtMs > 20.0) {
                jank++
                if (dtMs > 3.0 * avg && dtMs > 50.0) bigJank++
            }
        }
        last3[last3Pos] = dtMs
        last3Pos = (last3Pos + 1) % 3
        if (last3Count < 3) last3Count++
    }

    /** One per-second FPS reading (used for min / max, and for the average when no frame data exists). */
    fun addSecondFps(fps: Int) {
        if (fps <= 0) return
        if (fps < minFps) minFps = fps
        if (fps > maxFps) maxFps = fps
        fpsSum += fps
        fpsSamples++
    }

    fun snapshot(): FpsSessionStats {
        val avg: Double = when {
            frames > 20 && totalMs > 0.0 -> frames * 1000.0 / totalMs
            fpsSamples > 0 -> fpsSum / fpsSamples
            else -> 0.0
        }
        val low: Double = if (frames >= 100) {
            val target = (frames / 100).coerceAtLeast(1L)
            var acc = 0L
            var idx = BINS
            while (idx > 0) {
                acc += hist[idx]
                if (acc >= target) break
                idx--
            }
            1000.0 / ((idx + 1) * BIN_MS)
        } else if (minFps != Int.MAX_VALUE) {
            minFps.toDouble()
        } else {
            0.0
        }
        return FpsSessionStats(
            pkg = pkg,
            avgFps = avg.toFloat(),
            lowFps1 = low.toFloat(),
            minFps = if (minFps == Int.MAX_VALUE) 0 else minFps,
            maxFps = maxFps,
            jank = jank,
            bigJank = bigJank,
            seconds = ((System.currentTimeMillis() - startMs) / 1000L).toInt()
        )
    }
}
