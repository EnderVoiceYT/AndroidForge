package com.example.tempramreader.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import kotlin.math.roundToInt

/**
 * Real game FPS from SurfaceFlinger (needs the DUMP permission, see ShizukuHelper).
 *
 * Strategy A - frame timestamps:  dumpsys SurfaceFlinger --latency <layer>
 *   gives real per-frame times -> FPS, average, 1% low, jank.
 * Strategy B - TimeStats frame counter (used if A returns nothing, e.g. some Android 12+ ROMs):
 *   dumpsys SurfaceFlinger --timestats ...  -> frames per second from the per-layer frame counter.
 */
object GameFpsReader {
    class Result(
        val fps: Int?,
        val status: String,
        val session: FpsSessionStats? = null,
        val nextDelayMs: Long = 1000L
    )

    private const val INVALID_TS = Long.MAX_VALUE
    private val WHITESPACE = Regex("\\s+")
    private val LAYER_RE = Regex("""(?:layerName|layer_name)\s*[=:]\s*"?([^"\r\n]+?)"?\s*$""")
    private val TOTAL_RE = Regex("""(?:totalFrames|total_frames)\s*[=:]\s*(\d+)""")

    private val recorder = FpsSessionRecorder()

    private var currentPkg: String? = null
    private var layer: String? = null
    private var lastTs = 0L
    private var staleStreak = 0

    private var latencyFailStreak = 0
    private var latencyRetryAtMs = 0L

    private var timeStatsEnabled = false
    private val tsPrev = HashMap<String, Long>()
    private var tsPrevTimeNs = 0L

    private var failStreak = 0
    private var diagCaptured = false

    /** Text report captured while a game was open but no FPS could be read (for sharing). */
    @Volatile
    var lastDiagnostics: String? = null
        private set

    fun hasPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED

    @Synchronized
    fun resetSession() {
        recorder.reset(currentPkg ?: "")
    }

    @Synchronized
    fun sample(context: Context): Result {
        if (!hasPermission(context)) return Result(null, "Game FPS needs the DUMP permission.")

        val (pkg, _) = ForegroundAppDetector.getForegroundApp(context)
        if (pkg == ForegroundAppDetector.NO_PERMISSION) {
            return Result(null, "Grant Usage Access so the app knows which game is open.")
        }
        if (pkg == context.packageName) {
            return Result(null, "Open a game: the foreground app is this one.")
        }

        if (pkg != currentPkg) {
            currentPkg = pkg
            layer = null
            lastTs = 0L
            staleStreak = 0
            tsPrev.clear()
            tsPrevTimeNs = 0L
            failStreak = 0
            latencyFailStreak = 0
            latencyRetryAtMs = 0L
            diagCaptured = false
            recorder.reset(pkg)
        }

        val now = System.currentTimeMillis()

        // Strategy A
        if (now >= latencyRetryAtMs) {
            val a = sampleLatency(pkg)
            if (a != null) {
                latencyFailStreak = 0
                failStreak = 0
                return a
            }
            latencyFailStreak++
            if (latencyFailStreak >= 3) {          // don't keep spawning processes if it never works
                latencyRetryAtMs = now + 30_000L
                latencyFailStreak = 0
            }
        }

        // Strategy B
        val b = sampleTimeStats(pkg)
        if (b != null) {
            failStreak = 0
            return b
        }

        failStreak++
        if (failStreak >= 6 && !diagCaptured) {
            lastDiagnostics = buildDiagnostics(context, pkg)
            diagCaptured = true
        }
        return Result(
            null,
            "No frame data for $pkg yet. If this stays, tap \"Share diagnostics\" below after a minute of play."
        )
    }

    // ---------------- Strategy A: layer latency ----------------
    private fun sampleLatency(pkg: String): Result? {
        if (layer == null || staleStreak >= 5) {
            layer = findLayer(pkg)
            staleStreak = 0
            lastTs = 0L
        }
        val name = layer ?: return null

        val stamps = frameTimes(name)
        if (stamps.size < 2) {
            staleStreak++
            return null
        }

        val newest = stamps.last()
        if (newest == lastTs) {
            staleStreak++
            return Result(0, "Game FPS: $pkg is not presenting new frames.", recorder.snapshot())
        }
        staleStreak = 0

        // Feed only frames we haven't seen yet into the session stats.
        var prev: Long? = if (lastTs != 0L && stamps.contains(lastTs)) lastTs else null
        for (t in stamps) {
            if (t <= lastTs) continue
            val p = prev
            if (p != null) recorder.addFrame((t - p) / 1e6)
            prev = t
        }
        lastTs = newest

        // Live FPS: frames presented in the last second
        val inWindow = stamps.filter { it >= newest - 1_000_000_000L }
        val fps = if (inWindow.size < 2) {
            0
        } else {
            val spanSec = (newest - inWindow.first()) / 1e9
            ((inWindow.size - 1) / spanSec).roundToInt().coerceIn(0, 1000)
        }
        recorder.addSecondFps(fps)
        return Result(
            fps,
            "Game FPS: $pkg",
            recorder.snapshot(),
            if (fps >= 100) 700L else 1000L   // the frame buffer holds ~127 frames: poll faster at high FPS
        )
    }

    private fun findLayer(pkg: String): String? {
        val out = runDumpsys("SurfaceFlinger", "--list") ?: return null
        val candidates = out.lines()
            .map { it.trim() }
            .filter { it.contains(pkg) && !it.startsWith("Background for") && !it.startsWith("Bounds for") }
            .sortedByDescending { it.startsWith("SurfaceView") }   // games render into a SurfaceView
        for (c in candidates.take(8)) {
            if (frameTimes(c).size >= 2) return c
        }
        return null
    }

    /** Frame presentation timestamps (ns, ascending) for one layer. */
    private fun frameTimes(layerName: String): List<Long> {
        val out = runDumpsys("SurfaceFlinger", "--latency", layerName) ?: return emptyList()
        val actualPresent = ArrayList<Long>()
        val frameReady = ArrayList<Long>()
        out.lineSequence().drop(1).forEach { line ->   // line 0 is the refresh period
            val parts = line.trim().split(WHITESPACE)
            if (parts.size >= 3) {
                parts[1].toLongOrNull()?.let { if (it > 0L && it != INVALID_TS) actualPresent.add(it) }
                parts[2].toLongOrNull()?.let { if (it > 0L && it != INVALID_TS) frameReady.add(it) }
            }
        }
        val src = if (actualPresent.size >= 2) actualPresent else frameReady
        return src.sorted()
    }

    // ---------------- Strategy B: TimeStats frame counter ----------------
    private fun sampleTimeStats(pkg: String): Result? {
        if (!timeStatsEnabled) {
            runDumpsys("SurfaceFlinger", "--timestats", "-enable")
            timeStatsEnabled = true
        }
        val out = runDumpsys("SurfaceFlinger", "--timestats", "-dump", "-maxlayers", "50") ?: return null
        val totals = parseTimeStats(out, pkg)
        if (totals.isEmpty()) return null

        val nowNs = SystemClock.elapsedRealtimeNanos()
        var best: Int? = null
        if (tsPrevTimeNs != 0L) {
            val dtSec = (nowNs - tsPrevTimeNs) / 1e9
            if (dtSec > 0.3) {
                for ((name, total) in totals) {
                    val prevTotal = tsPrev[name] ?: continue
                    val d = total - prevTotal
                    if (d < 0) continue
                    val f = (d / dtSec).roundToInt().coerceIn(0, 1000)
                    if (best == null || f > best!!) best = f
                }
            }
        }
        tsPrev.clear()
        tsPrev.putAll(totals)
        tsPrevTimeNs = nowNs

        val fps = best ?: return Result(null, "Game FPS: warming up (TimeStats)...")
        recorder.addSecondFps(fps)
        return Result(fps, "Game FPS: $pkg (TimeStats)", recorder.snapshot())
    }

    private fun parseTimeStats(out: String, pkg: String): Map<String, Long> {
        val result = HashMap<String, Long>()
        var cur: String? = null
        for (line in out.lineSequence()) {
            val t = line.trim()
            val lm = LAYER_RE.find(t)
            if (lm != null) {
                cur = lm.groupValues[1]
                continue
            }
            val tm = TOTAL_RE.find(t)
            val c = cur
            if (tm != null && c != null) {
                if (c.contains(pkg)) {
                    val v = tm.groupValues[1].toLongOrNull()
                    if (v != null) result[c] = v
                }
                cur = null
            }
        }
        return result
    }

    // ---------------- Diagnostics ----------------
    private fun buildDiagnostics(context: Context, pkg: String): String {
        val sb = StringBuilder()
        sb.appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("DUMP granted: ${hasPermission(context)}")
        sb.appendLine("Foreground package: $pkg")

        val list = runDumpsys("SurfaceFlinger", "--list")
        if (list == null) {
            sb.appendLine("--list: failed to run")
        } else {
            val lines = list.lines()
            val matches = lines.filter { it.contains(pkg) }
            sb.appendLine("--list: ${lines.size} lines, ${matches.size} match the package")
            lines.take(3).forEach { sb.appendLine("  list head: ${it.take(100)}") }
            for (m in matches.take(8)) {
                sb.appendLine("LAYER: ${m.take(160)}")
                val lat = runDumpsys("SurfaceFlinger", "--latency", m.trim())
                sb.appendLine("  latency: " + (lat?.lines()?.take(5)?.joinToString(" | ") { it.take(70) } ?: "failed"))
            }
        }

        val ts = runDumpsys("SurfaceFlinger", "--timestats", "-dump", "-maxlayers", "50")
        if (ts == null) {
            sb.appendLine("timestats: failed to run")
        } else {
            sb.appendLine("timestats: ${ts.length} chars")
            ts.lines()
                .filter { it.contains(pkg) || it.contains("otalFrames") || it.contains("otal_frames") || it.contains("ayer") }
                .take(25)
                .forEach { sb.appendLine("  ${it.trim().take(120)}") }
        }
        return sb.toString()
    }

    private fun runDumpsys(vararg args: String): String? {
        var proc: Process? = null
        return try {
            proc = ProcessBuilder(listOf("dumpsys") + args).redirectErrorStream(true).start()
            proc.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            proc?.destroy()
        }
    }
}
