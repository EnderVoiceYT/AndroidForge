package com.example.tempramreader.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.view.Choreographer
import android.view.Display
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

object HardwareRepository {
    private val _metrics = MutableStateFlow(HardwareMetrics())
    val metrics: StateFlow<HardwareMetrics> = _metrics.asStateFlow()

    private val _settings = MutableStateFlow(OverlaySettings())
    val settings: StateFlow<OverlaySettings> = _settings.asStateFlow()

    private val _hasShownFallbackDialog = MutableStateFlow(false)
    val hasShownFallbackDialog: StateFlow<Boolean> = _hasShownFallbackDialog.asStateFlow()

    private var frameCount = 0
    private var lastFpsTimestampNanos = 0L
    private var isFpsTracking = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isFpsTracking) return
            if (lastFpsTimestampNanos == 0L) lastFpsTimestampNanos = frameTimeNanos
            frameCount++

            val elapsedNanos = frameTimeNanos - lastFpsTimestampNanos
            if (elapsedNanos >= 500_000_000L) {
                val calculatedFps = ((frameCount * 1_000_000_000L) / elapsedNanos).toInt()
                _metrics.update { current ->
                    val clampedFps = calculatedFps.coerceIn(1, current.displayHz.coerceAtLeast(144))
                    current.copy(
                        currentFps = clampedFps,
                        fpsHistory = (current.fpsHistory + clampedFps.toFloat()).takeLast(30)
                    )
                }
                frameCount = 0
                lastFpsTimestampNanos = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun startFpsTracker() {
        if (isFpsTracking) return
        isFpsTracking = true
        frameCount = 0
        lastFpsTimestampNanos = 0L
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    fun stopFpsTracker() {
        isFpsTracking = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    fun updateSettings(transform: (OverlaySettings) -> OverlaySettings) {
        _settings.update(transform)
    }

    fun markFallbackDialogShown() {
        _hasShownFallbackDialog.value = true
    }

    suspend fun pollHardware(context: Context) = withContext(Dispatchers.IO) {
        val (temp, isFallback) = readTemperature(context)
        val (totalMb, usedMb, freeMb) = readRam(context)
        val hz = readDisplayRefreshRate(context)

        // Log App Heat Suspect Sample
        try {
            val (pkg, appName) = ForegroundAppDetector.getForegroundApp(context)
            val db = AppHeatDatabase.getDatabase(context)
            val sensor = if (isFallback) "Battery Sensor" else "SoC / CPU Thermal Zone"
            db.appHeatDao().insertSample(
                AppHeatEntity(
                    timestamp = System.currentTimeMillis(),
                    packageName = pkg,
                    appName = appName,
                    temperatureCelsius = temp,
                    sensorType = sensor
                )
            )
        } catch (_: Exception) {}


        _metrics.update { current ->
            val ramPct = (usedMb.toFloat() / totalMb.coerceAtLeast(1L)) * 100f
            current.copy(
                temperatureCelsius = temp,
                isBatteryFallback = isFallback,
                totalRamMb = totalMb,
                usedRamMb = usedMb,
                freeRamMb = freeMb,
                displayHz = hz,
                tempHistory = (current.tempHistory + temp).takeLast(30),
                ramPercentHistory = (current.ramPercentHistory + ramPct).takeLast(30)
            )
        }
    }

    private fun readDisplayRefreshRate(context: Context): Int {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        return display?.refreshRate?.roundToInt() ?: 60
    }

    private fun normalizeTemp(raw: Float): Float =
        if (raw > 1000f) raw / 1000f else if (raw > 200f) raw / 10f else raw

    // ---- Source 1: sysfs (works only if the ROM lets apps read it) ----
    private fun readSysfsZones(): Map<String, Float> {
        val readings = LinkedHashMap<String, Float>()
        for (root in listOf(File("/sys/class/thermal"), File("/sys/devices/virtual/thermal"))) {
            val zones = try {
                root.listFiles { f -> f.name.startsWith("thermal_zone") }
            } catch (_: Exception) { null } ?: continue
            for (zone in zones) {
                try {
                    val type = File(zone, "type").readText().trim().lowercase()
                    val raw = File(zone, "temp").readText().trim().toFloatOrNull() ?: continue
                    val t = normalizeTemp(raw)
                    if (t in 15f..120f) readings[type] = t
                } catch (_: Exception) { }
            }
            if (readings.isNotEmpty()) break
        }
        return readings
    }

    // ---- Source 2: `dumpsys thermalservice` (needs: adb shell pm grant <pkg> android.permission.DUMP) ----
    private val dumpsysRegex =
        Regex("""Temperature\{mValue=(-?[\d.]+),\s*mType=(\d+),\s*mName=([^,]+),""")
    private var lastDumpsysFailMs = 0L

    private fun readDumpsysZones(): Map<String, Float> {
        // If it failed recently (permission not granted), don't spawn a process every tick.
        if (System.currentTimeMillis() - lastDumpsysFailMs < 30_000L) return emptyMap()
        val readings = LinkedHashMap<String, Float>()
        try {
            val proc = ProcessBuilder("dumpsys", "thermalservice").redirectErrorStream(true).start()
            val out = proc.inputStream.bufferedReader().use { it.readText() }
            proc.destroy()
            // Prefer the "Current temperatures from HAL" block if present, else parse everything.
            val section = out.substringAfter("Current temperatures from HAL:", out)
            dumpsysRegex.findAll(section).forEach { m ->
                val v = m.groupValues[1].toFloatOrNull() ?: return@forEach
                val type = m.groupValues[3].trim().lowercase()
                if (v in 15f..120f) readings[type] = v
            }
        } catch (_: Exception) { }
        if (readings.isEmpty()) lastDumpsysFailMs = System.currentTimeMillis()
        return readings
    }

    private fun pickSocTemp(readings: Map<String, Float>): Float? {
        if (readings.isEmpty()) return null
        readings["soc_max"]?.let { return it }
        val cpu = readings.filterKeys { it.startsWith("cpu") || it.contains("mtktscpu") }.values
        if (cpu.isNotEmpty()) return cpu.max()
        val soc = readings.filterKeys {
            it.contains("soc") || it.contains("tsens") || it.contains("xo_therm") || it.startsWith("ap")
        }.values
        if (soc.isNotEmpty()) return soc.average().toFloat()
        return null
    }

    private fun readTemperature(context: Context): Pair<Float, Boolean> {
        pickSocTemp(readSysfsZones())?.let { return Pair(it, false) }
        pickSocTemp(readDumpsysZones())?.let { return Pair(it, false) }

        // Fallback: battery temperature
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawBatteryTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        return Pair(rawBatteryTemp / 10f, true)
    }

    private fun readRam(context: Context): Triple<Long, Long, Long> {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val totalMb = memoryInfo.totalMem / (1024 * 1024)
        val freeMb = memoryInfo.availMem / (1024 * 1024)
        val usedMb = totalMb - freeMb
        return Triple(totalMb, usedMb, freeMb)
    }
}
