package com.example.tempramreader.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import kotlin.math.roundToInt

/**
 * Real game FPS, read from SurfaceFlinger (the Android compositor) the same way shell-based FPS
 * counters do. Needs a one-time:  adb shell pm grant <package> android.permission.DUMP
 *
 * 1. Find which app is in the foreground (Usage Access).
 * 2. Find that app's on-screen layer:  dumpsys SurfaceFlinger --list
 * 3. Read its recent frame timestamps: dumpsys SurfaceFlinger --latency <layer>
 *    and count how many frames were presented in the last second.
 */
object GameFpsReader {
    class Result(val fps: Int?, val status: String)

    private const val INVALID_TS = Long.MAX_VALUE
    private val WHITESPACE = Regex("\\s+")

    private var layerPkg: String? = null
    private var layer: String? = null
    private var lastNewestTs = 0L
    private var staleStreak = 0

    fun hasPermission(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED

    @Synchronized
    fun sample(context: Context): Result {
        if (!hasPermission(context)) return Result(null, "Game FPS needs the DUMP permission.")

        val (pkg, _) = ForegroundAppDetector.getForegroundApp(context)
        if (pkg == ForegroundAppDetector.NO_PERMISSION) {
            return Result(null, "Grant Usage Access so the app knows which game is open.")
        }
        if (pkg == context.packageName) {
            return Result(null, "Open a game: the foreground app is this one.")
        }

        if (pkg != layerPkg || layer == null || staleStreak >= 5) {
            layerPkg = pkg
            layer = findLayer(pkg)
            staleStreak = 0
            lastNewestTs = 0L
        }
        val name = layer ?: return Result(null, "No on-screen layer found for $pkg.")

        val stamps = frameTimes(name)
        if (stamps.size < 2) {
            staleStreak++
            return Result(null, "No frame data from $pkg yet.")
        }

        val newest = stamps.last()
        if (newest == lastNewestTs) {
            // Nothing new was presented since the last check (paused / static screen).
            staleStreak++
            return Result(0, "Game FPS: $pkg is not presenting new frames.")
        }
        staleStreak = 0
        lastNewestTs = newest

        val inWindow = stamps.filter { it >= newest - 1_000_000_000L }
        if (inWindow.size < 2) return Result(0, "Game FPS: reading $pkg")
        val spanSec = (newest - inWindow.first()) / 1e9
        val fps = ((inWindow.size - 1) / spanSec).roundToInt().coerceIn(0, 1000)
        return Result(fps, "Game FPS: reading $pkg")
    }

    private fun findLayer(pkg: String): String? {
        val out = runDumpsys("SurfaceFlinger", "--list") ?: return null
        val candidates = out.lines()
            .map { it.trim() }
            .filter { it.contains(pkg) && !it.startsWith("Background for") && !it.startsWith("Bounds for") }
            .sortedByDescending { it.startsWith("SurfaceView") }   // games render into a SurfaceView
        for (c in candidates.take(5)) {
            if (frameTimes(c).size >= 2) return c
        }
        return null
    }

    /** Frame presentation timestamps (ns, ascending) for one layer. */
    private fun frameTimes(layerName: String): List<Long> {
        val out = runDumpsys("SurfaceFlinger", "--latency", layerName) ?: return emptyList()
        val actualPresent = ArrayList<Long>()
        val frameReady = ArrayList<Long>()
        out.lineSequence().drop(1).forEach { line ->   // line 0 is the refresh period
            val parts = line.trim().split(WHITESPACE)
            if (parts.size >= 3) {
                parts[1].toLongOrNull()?.let { if (it > 0L && it != INVALID_TS) actualPresent.add(it) }
                parts[2].toLongOrNull()?.let { if (it > 0L && it != INVALID_TS) frameReady.add(it) }
            }
        }
        val src = if (actualPresent.size >= 2) actualPresent else frameReady
        return src.sorted()
    }

    private fun runDumpsys(vararg args: String): String? {
        var proc: Process? = null
        return try {
            proc = ProcessBuilder(listOf("dumpsys") + args).redirectErrorStream(true).start()
            proc.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            proc?.destroy()
        }
    }
}
