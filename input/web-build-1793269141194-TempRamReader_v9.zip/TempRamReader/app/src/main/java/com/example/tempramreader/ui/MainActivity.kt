package com.example.tempramreader.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.tempramreader.data.*
import com.example.tempramreader.data.DisplayMode
import com.example.tempramreader.service.MonitorOverlayService

class MainActivity : ComponentActivity() {

    private val viewModel: MonitorViewModel by viewModels()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startMonitoringService() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startMonitoringService()
        }

        setContent {
            val darkTheme = isSystemInDarkTheme()
            val colorScheme = when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                    val context = LocalContext.current
                    if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
                }
                darkTheme -> darkColorScheme()
                else -> lightColorScheme()
            }

            MaterialTheme(colorScheme = colorScheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DashboardScreen(
                        viewModel = viewModel,
                        onRequestOverlayPermission = ::requestOverlayPermission,
                        onRequestBatteryUnrestricted = ::requestIgnoreBatteryOptimizations
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        HardwareRepository.setUiVisible(true)
    }

    override fun onStop() {
        HardwareRepository.setUiVisible(false)
        super.onStop()
    }

    private fun startMonitoringService() {
        val serviceIntent = Intent(this, MonitorOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requestIgnoreBatteryOptimizations() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: MonitorViewModel,
    onRequestOverlayPermission: () -> Unit,
    onRequestBatteryUnrestricted: () -> Unit
) {
    val context = LocalContext.current
    val metrics by viewModel.metrics.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val hasShownFallbackDialog by viewModel.hasShownFallbackDialog.collectAsState()

    // Shizuku one-tap grant (Game FPS)
    val shizukuScope = rememberCoroutineScope()
    var shizukuState by remember { mutableStateOf(ShizukuHelper.state()) }
    var shizukuMsg by remember { mutableStateOf("") }
    LaunchedEffect(settings.fpsSource) {
        if (settings.fpsSource == FpsSource.GAME) {
            while (true) {
                shizukuState = ShizukuHelper.state()
                delay(1500)
            }
        }
    }

    if (metrics.isBatteryFallback && !hasShownFallbackDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissFallbackDialog() },
            title = { Text("Thermal Sensor Restricted") },
            text = {
                Text(
                    "We apologize! Your device restricts direct access to CPU/SoC thermal nodes. " +
                    "The app has fallen back to the battery temperature sensor, so readings may be " +
                    "slightly inaccurate as they only reflect battery heat."
                )
            },
            confirmButton = {
                Button(onClick = { viewModel.dismissFallbackDialog() }) { Text("Got It") }
            }
        )
    }

    val tempColor by animateColorAsState(
        targetValue = when (metrics.thermalStatus) {
            ThermalStatus.COLD -> Color(0xFF2E7D32)
            ThermalStatus.MEDIUM -> Color(0xFFF9A825)
            ThermalStatus.HOT -> Color(0xFFC62828)
        },
        label = "TempColor"
    )

    val ramColor by animateColorAsState(
        targetValue = if (metrics.isRamHigh) Color(0xFFC62828) else Color(0xFF2E7D32),
        label = "RamColor"
    )

    Scaffold(
        topBar = {
            LargeTopAppBar(
                title = { Text("Temperature & RAM Reader", fontWeight = FontWeight.ExtraBold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = tempColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = if (metrics.isBatteryFallback) "TEMPERATURE (BATTERY FALLBACK)" else "SOC / CPU TEMPERATURE",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${"%.1f".format(metrics.temperatureCelsius)}°C",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = Color.Black.copy(alpha = 0.25f),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = "\"${metrics.statusQuote}\"",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = ramColor),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "SYSTEM RAM USAGE • ${if (metrics.fpsIsGame) "GAME " else ""}${metrics.currentFps} FPS (${metrics.displayHz} Hz)",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${metrics.usedRamMb} MB / ${metrics.totalRamMb} MB",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Free: ${metrics.freeRamMb} MB (${(metrics.ramUsageFraction * 100).toInt()}% used)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { metrics.ramUsageFraction },
                        color = Color.White,
                        trackColor = Color.Black.copy(alpha = 0.3f),
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp))
                    )
                }
            }

            ElevatedCard(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Floating Game Overlay (HUD)",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Enable Floating HUD")
                        Switch(
                            checked = settings.isOverlayVisible,
                            onCheckedChange = { enabled ->
                                if (enabled && !Settings.canDrawOverlays(context)) {
                                    onRequestOverlayPermission()
                                } else {
                                    viewModel.toggleOverlay(enabled)
                                }
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Show Live FPS & Refresh Rate (Hz)")
                        Switch(
                            checked = settings.showFps,
                            onCheckedChange = { viewModel.toggleFps(it) }
                        )
                    }

                    if (settings.showFps) {
                        Text("FPS Source", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = settings.fpsSource == FpsSource.DISPLAY,
                                onClick = { viewModel.setFpsSource(FpsSource.DISPLAY) },
                                label = { Text("Display") }
                            )
                            FilterChip(
                                selected = settings.fpsSource == FpsSource.GAME,
                                onClick = { viewModel.setFpsSource(FpsSource.GAME) },
                                label = { Text("Game (real FPS)") }
                            )
                        }
                        if (settings.fpsSource == FpsSource.GAME) {
                            if (!GameFpsReader.hasPermission(context)) {
                                Text(
                                    "Game FPS needs one permission, granted once:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                when (shizukuState) {
                                    ShizukuHelper.State.READY -> Button(onClick = {
                                        shizukuScope.launch { shizukuMsg = ShizukuHelper.grantDump(context) }
                                    }) { Text("Grant with Shizuku (one tap)") }

                                    ShizukuHelper.State.NEEDS_PERMISSION -> Button(onClick = {
                                        ShizukuHelper.requestPermission()
                                    }) { Text("Allow Shizuku access") }

                                    ShizukuHelper.State.NOT_RUNNING -> Text(
                                        "Shizuku isn't running. Open the Shizuku app, start it (Wireless debugging), then come back here.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                if (shizukuMsg.isNotEmpty()) {
                                    Text(
                                        shizukuMsg,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    "Or from a PC:\nadb shell pm grant com.example.tempramreader android.permission.DUMP",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else if (metrics.fpsStatus.isNotEmpty()) {
                                Text(
                                    metrics.fpsStatus,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    HorizontalDivider()

                    Text("Displayed Metrics", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DisplayMode.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.displayMode == mode,
                                onClick = { viewModel.setDisplayMode(mode) },
                                label = { Text(mode.name.replace("_", " ")) }
                            )
                        }
                    }

                    Text("Visualization Style", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        VisualizationType.entries.forEach { type ->
                            FilterChip(
                                selected = settings.visualizationType == type,
                                onClick = { viewModel.setVisualizationType(type) },
                                label = { Text(if (type == VisualizationType.BAR) "Bar" else "Real-time Graph") }
                            )
                        }
                    }

                    Text("Update Interval", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1000L to "1s", 3000L to "3s", 5000L to "5s").forEach { (ms, label) ->
                            FilterChip(
                                selected = settings.pollingIntervalMs == ms,
                                onClick = { viewModel.setPollingInterval(ms) },
                                label = { Text(label) }
                            )
                        }
                    }

                    Text("Overlay Width: ${settings.overlayWidthDp} dp", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = settings.overlayWidthDp.toFloat(),
                        onValueChange = { viewModel.setOverlayDimensions(it.toInt(), settings.overlayHeightDp) },
                        valueRange = 150f..420f
                    )

                    Text("Overlay Height: ${settings.overlayHeightDp} dp", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = settings.overlayHeightDp.toFloat(),
                        onValueChange = { viewModel.setOverlayDimensions(settings.overlayWidthDp, it.toInt()) },
                        valueRange = 90f..380f
                    )

                    HorizontalDivider()

                    OutlinedButton(
                        onClick = onRequestBatteryUnrestricted,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Disable Battery Optimizations (Keep Alive)")
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun AppHeatRankingSection(context: android.content.Context) {
    val scope = rememberCoroutineScope()
    val dao = remember { AppHeatDatabase.getDatabase(context).appHeatDao() }
    val summaries by dao.getAppHeatSummaries().collectAsState(initial = emptyList())
    var hasPermission by remember { mutableStateOf(ForegroundAppDetector.hasUsageStatsPermission(context)) }

    // Check permission periodically or on resume
    LaunchedEffect(Unit) {
        hasPermission = ForegroundAppDetector.hasUsageStatsPermission(context)
    }

    ElevatedCard(
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "App Heat Suspect Ranking",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (summaries.isNotEmpty()) {
                    TextButton(onClick = {
                        scope.launch {
                            dao.clearHistory()
                        }
                    }) {
                        Text("Clear", color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            if (!hasPermission) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Usage Access Required",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = "To rank which apps coincide with device heating, please grant Usage Access permission in Android Settings.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Button(
                            onClick = {
                                val intent = android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                context.startActivity(intent)
                            }
                        ) {
                            Text("Grant Usage Access")
                        }
                    }
                }
            } else if (summaries.isEmpty()) {
                Text(
                    text = "Collecting temperature & app correlations... Use your apps normally, and rankings will appear shortly.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    text = "🔥 Ranked by average temperature while the app was in use (Correlation ≠ Causation)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )

                summaries.forEachIndexed { index, item ->
                    val rankColor = when (index) {
                        0 -> Color(0xFFC62828)
                        1 -> Color(0xFFD84315)
                        2 -> Color(0xFFEF6C00)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                    val textColor = if (index < 3) Color.White else MaterialTheme.colorScheme.onSurface

                    Surface(
                        color = rankColor,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${index + 1}. ${item.appName}",
                                    fontWeight = FontWeight.Bold,
                                    color = textColor,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "Avg: ${"%.1f".format(item.avgTemp)}°C",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = textColor
                                )
                            }
                            Text(
                                text = "Peak: ${"%.1f".format(item.peakTemp)}°C • Active: ~${if (item.totalDurationSeconds < 60) "${item.totalDurationSeconds}s" else "${item.totalDurationSeconds / 60} min"} (${item.sampleCount} samples)",
                                style = MaterialTheme.typography.bodySmall,
                                color = textColor.copy(alpha = 0.9f)
                            )
                        }
                    }
                }
            }
        }
    }
}
