package com.example.tempramreader.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.view.Choreographer
import android.view.Display
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/** How often an App-Heat sample is written to the DB. AppHeatDao's duration maths uses the same 5 s. */
const val HEAT_SAMPLE_INTERVAL_MS = 5_000L
private const val HEAT_RETENTION_MS = 7L * 24 * 60 * 60 * 1000 // keep 7 days of samples
private const val PRUNE_INTERVAL_MS = 60L * 60 * 1000

object HardwareRepository {
    private val _metrics = MutableStateFlow(HardwareMetrics())
    val metrics: StateFlow<HardwareMetrics> = _metrics.asStateFlow()

    private val _settings = MutableStateFlow(OverlaySettings())
    val settings: StateFlow<OverlaySettings> = _settings.asStateFlow()

    private val _hasShownFallbackDialog = MutableStateFlow(false)
    val hasShownFallbackDialog: StateFlow<Boolean> = _hasShownFallbackDialog.asStateFlow()

    /** True while MainActivity is on screen. The FPS tracker only runs when something can actually show it. */
    private val _uiVisible = MutableStateFlow(false)
    val uiVisible: StateFlow<Boolean> = _uiVisible.asStateFlow()

    // ---------------- FPS tracker ----------------
    private var frameCount = 0
    private var lastFpsTimestampNanos = 0L
    private var isFpsTracking = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isFpsTracking) return

            if (lastFpsTimestampNanos == 0L) {
                // First frame only sets the reference point.
                lastFpsTimestampNanos = frameTimeNanos
                frameCount = 0
            } else {
                frameCount++
                val elapsedNanos = frameTimeNanos - lastFpsTimestampNanos
                if (elapsedNanos >= 1_000_000_000L) {
                    // Round instead of truncating (119.9 used to show as 119).
                    val fps = (frameCount * 1_000_000_000.0 / elapsedNanos).roundToInt()
                    _metrics.update { current ->
                        val clamped = fps.coerceIn(1, current.displayHz.coerceAtLeast(1))
                        current.copy(
                            currentFps = clamped,
                            fpsHistory = (current.fpsHistory + clamped.toFloat()).takeLast(30)
                        )
                    }
                    frameCount = 0
                    lastFpsTimestampNanos = frameTimeNanos
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    // Must be called on the main thread.
    fun startFpsTracker() {
        if (isFpsTracking) return
        isFpsTracking = true
        frameCount = 0
        lastFpsTimestampNanos = 0L
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    fun stopFpsTracker() {
        if (!isFpsTracking) return
        isFpsTracking = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    // ---------------- State setters ----------------
    fun updateSettings(transform: (OverlaySettings) -> OverlaySettings) {
        _settings.update(transform)
    }

    fun markFallbackDialogShown() {
        _hasShownFallbackDialog.value = true
    }

    /** fps == null means "no game data": keep the last value and let the display tracker fill in. */
    fun publishGameFps(fps: Int?, status: String) {
        _metrics.update { current ->
            if (fps == null) {
                current.copy(fpsIsGame = false, fpsStatus = status)
            } else {
                current.copy(
                    currentFps = fps,
                    fpsIsGame = true,
                    fpsStatus = status,
                    fpsHistory = (current.fpsHistory + fps.toFloat()).takeLast(30)
                )
            }
        }
    }

    fun setUiVisible(visible: Boolean) {
        _uiVisible.value = visible
    }

    // ---------------- Smoothing ----------------
    // The hottest-sensor reading jumps around by ~1 °C per tick, so show the average of the last few reads.
    private const val SMOOTH_WINDOW = 5
    private val tempWindow = ArrayDeque<Float>()
    private var lastWasFallback: Boolean? = null

    private fun smoothTemp(raw: Float, isFallback: Boolean): Float {
        if (lastWasFallback != isFallback) {   // source changed (e.g. battery -> SoC): start fresh
            tempWindow.clear()
            lastWasFallback = isFallback
        }
        tempWindow.addLast(raw)
        while (tempWindow.size > SMOOTH_WINDOW) tempWindow.removeFirst()
        return tempWindow.average().toFloat()
    }

    // ---------------- Polling ----------------
    private var lastHeatLogMs = 0L
    private var lastPruneMs = 0L

    suspend fun pollHardware(context: Context) = withContext(Dispatchers.IO) {
        val (rawTemp, isFallback) = readTemperature(context)
        val temp = smoothTemp(rawTemp, isFallback)
        val (totalMb, usedMb, freeMb) = readRam(context)
        val hz = readDisplayRefreshRate(context)

        // Update the UI first so the DB / usage-stats work below never delays it.
        _metrics.update { current ->
            val ramPct = (usedMb.toFloat() / totalMb.coerceAtLeast(1L)) * 100f
            current.copy(
                temperatureCelsius = temp,
                isBatteryFallback = isFallback,
                totalRamMb = totalMb,
                usedRamMb = usedMb,
                freeRamMb = freeMb,
                displayHz = hz,
                tempHistory = (current.tempHistory + temp).takeLast(30),
                ramPercentHistory = (current.ramPercentHistory + ramPct).takeLast(30)
            )
        }

        logHeatSample(context, temp, isFallback)
    }

    private suspend fun logHeatSample(context: Context, temp: Float, isFallback: Boolean) {
        val now = System.currentTimeMillis()
        if (now - lastHeatLogMs < HEAT_SAMPLE_INTERVAL_MS) return
        lastHeatLogMs = now

        try {
            val (pkg, appName) = ForegroundAppDetector.getForegroundApp(context)
            // Don't pollute the ranking with "no permission" rows or with our own dashboard.
            if (pkg == ForegroundAppDetector.NO_PERMISSION || pkg == context.packageName) return

            val dao = AppHeatDatabase.getDatabase(context).appHeatDao()
            dao.insertSample(
                AppHeatEntity(
                    timestamp = now,
                    packageName = pkg,
                    appName = appName,
                    temperatureCelsius = temp,
                    sensorType = if (isFallback) "Battery Sensor" else "SoC / CPU Thermal Zone"
                )
            )

            if (now - lastPruneMs > PRUNE_INTERVAL_MS) {
                lastPruneMs = now
                dao.deleteOlderThan(now - HEAT_RETENTION_MS)
            }
        } catch (_: Exception) {
        }
    }

    private fun readDisplayRefreshRate(context: Context): Int {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        return display?.refreshRate?.roundToInt() ?: 60
    }

    // ---------------- Temperature ----------------
    // Same idea as AIDA64 / Device Info HW: find every readable temperature file, then pick the SoC one.
    // Important: a zone whose "type" file is unreadable is NOT skipped, and if the folder can't be
    // listed we probe thermal_zone0..N directly (some ROMs block listing but allow reading the files).
    private class TempSrc(val name: String, val path: String, val tenths: Boolean = false)

    private var tempSources: List<TempSrc> = emptyList()
    private var discoverTick = 0
    private val readBuf = ByteArray(32)

    private val EXCLUDED = listOf("batt", "gauge", "supply")
    private val CPU_ISH = listOf("cpu", "soc", "tsens", "cluster", "big", "little")

    private fun readSmallText(path: String): String? =
        try { File(path).readText().trim() } catch (_: Exception) { null }

    private fun discoverTempSources(): List<TempSrc> {
        val out = mutableListOf<TempSrc>()

        // 1) thermal zones
        var zones = emptyList<String>()
        for (base in listOf("/sys/class/thermal", "/sys/devices/virtual/thermal")) {
            val names = try { File(base).list()?.filter { it.startsWith("thermal_zone") } } catch (_: Exception) { null }
            if (!names.isNullOrEmpty()) {
                zones = names.map { "$base/$it" }
                break
            }
        }
        if (zones.isEmpty()) {
            // Listing blocked: probe by index instead.
            var miss = 0
            var i = 0
            while (miss < 8 && i < 100) {
                val d = "/sys/class/thermal/thermal_zone$i"
                if (File("$d/temp").canRead()) { zones = zones + d; miss = 0 } else miss++
                i++
            }
        }
        zones.sortedBy { it.takeLastWhile(Char::isDigit).toIntOrNull() ?: 0 }.forEach { z ->
            out += TempSrc(readSmallText("$z/type") ?: z.substringAfterLast('/'), "$z/temp")
        }

        // 2) hwmon chips
        val hw = try { File("/sys/class/hwmon").list()?.toList() } catch (_: Exception) { null }
            ?: (0..15).map { "hwmon$it" }
        hw.sorted().forEach { h ->
            val dir = "/sys/class/hwmon/$h"
            val chip = readSmallText("$dir/name") ?: return@forEach
            for (n in 1..12) {
                val p = "$dir/temp${n}_input"
                if (File(p).canRead()) out += TempSrc("$chip " + (readSmallText("$dir/temp${n}_label") ?: "temp$n"), p)
            }
        }

        // 3) power supplies (battery etc.; value is in tenths of a degree)
        val ps = try { File("/sys/class/power_supply").list()?.toList() } catch (_: Exception) { null }
            ?: listOf("battery")
        ps.forEach { n ->
            val p = "/sys/class/power_supply/$n/temp"
            if (File(p).canRead()) out += TempSrc("$n (supply)", p, tenths = true)
        }

        // Make duplicate names unique
        val seen = HashMap<String, Int>()
        return out.map { src ->
            val c = (seen[src.name] ?: 0) + 1
            seen[src.name] = c
            if (c == 1) src else TempSrc("${src.name} $c", src.path, src.tenths)
        }
    }

    private fun readNumber(path: String): Float = try {
        java.io.FileInputStream(path).use { ins ->
            val n = ins.read(readBuf)
            if (n <= 0) Float.NaN else String(readBuf, 0, n).trim().toFloatOrNull() ?: Float.NaN
        }
    } catch (_: Exception) {
        Float.NaN
    }

    private fun readTemperature(context: Context): Pair<Float, Boolean> {
        // Nothing found yet? Retry discovery every 15th call (cheap) instead of every tick.
        if (tempSources.isEmpty() && discoverTick++ % 15 == 0) tempSources = discoverTempSources()

        val nodes = ArrayList<Pair<String, Float>>(tempSources.size)
        for (src in tempSources) {
            val raw = readNumber(src.path)
            if (raw.isNaN()) continue
            val v = if (src.tenths) raw / 10f else if (kotlin.math.abs(raw) >= 1000f) raw / 1000f else raw
            if (v in -30f..150f && v != 0f) nodes.add(src.name to v)
        }

        val real = nodes.filter { n -> EXCLUDED.none { n.first.contains(it, ignoreCase = true) } }
        val cpuIsh = real.filter { n -> CPU_ISH.any { n.first.contains(it, ignoreCase = true) } }

        val soc: Float? =
            nodes.firstOrNull { it.first.equals("soc_max", ignoreCase = true) }?.second
                ?: cpuIsh.ifEmpty { real }.maxOfOrNull { it.second }

        if (soc != null) return Pair(soc, false)

        // Fallback: battery temperature
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawBatteryTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        return Pair(rawBatteryTemp / 10f, true)
    }

    // ---------------- RAM ----------------
    private fun readRam(context: Context): Triple<Long, Long, Long> {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val totalMb = memoryInfo.totalMem / (1024 * 1024)
        val freeMb = memoryInfo.availMem / (1024 * 1024)
        val usedMb = totalMb - freeMb
        return Triple(totalMb, usedMb, freeMb)
    }
}
