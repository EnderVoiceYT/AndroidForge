package com.example.tempramreader.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

data class AppHeatSummary(
    val packageName: String,
    val appName: String,
    val sampleCount: Int,
    val avgTemp: Float,
    val peakTemp: Float,
    val totalDurationSeconds: Int
)

@Dao
interface AppHeatDao {
    @Insert
    suspend fun insertSample(sample: AppHeatEntity)

    // NOTE: the `* 5` = HEAT_SAMPLE_INTERVAL_MS / 1000 (one sample every 5 s).
    @Query("""
        SELECT packageName, appName, 
               COUNT(*) as sampleCount, 
               AVG(temperatureCelsius) as avgTemp, 
               MAX(temperatureCelsius) as peakTemp,
               (COUNT(*) * 5) as totalDurationSeconds
        FROM app_heat_samples 
        GROUP BY packageName 
        ORDER BY peakTemp DESC
    """)
    fun getAppHeatSummaries(): Flow<List<AppHeatSummary>>

    @Query("DELETE FROM app_heat_samples")
    suspend fun clearHistory()

    @Query("DELETE FROM app_heat_samples WHERE timestamp < :cutoffMs")
    suspend fun deleteOlderThan(cutoffMs: Long)
}
