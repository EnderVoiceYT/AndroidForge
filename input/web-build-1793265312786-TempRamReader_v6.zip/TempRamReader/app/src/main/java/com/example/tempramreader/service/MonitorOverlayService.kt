package com.example.tempramreader.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.tempramreader.data.*
import com.example.tempramreader.data.DisplayMode
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.roundToInt

class MonitorOverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager
    private var composeView: ComposeView? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private lateinit var overlayLayoutParams: WindowManager.LayoutParams
    private var lastNotificationText = ""
    private var lastNotificationMs = 0L

    companion object {
        private const val CHANNEL_ID = "HardwareMonitorChannel"
        private const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Monitoring hardware..."))
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager

        serviceScope.launch {
            while (isActive) {
                val interactive = powerManager.isInteractive
                val s = HardwareRepository.settings.value

                // The FPS tracker wakes the app on every display frame, so only run it
                // while the screen is on and something (HUD or dashboard) is showing FPS.
                val wantFps = interactive && s.showFps &&
                        (s.isOverlayVisible || HardwareRepository.uiVisible.value)
                if (wantFps) HardwareRepository.startFpsTracker() else HardwareRepository.stopFpsTracker()

                if (!interactive) {
                    // Screen off: nothing to show, skip sensor reads and DB writes.
                    delay(3000)
                    continue
                }

                HardwareRepository.pollHardware(applicationContext)

                val m = HardwareRepository.metrics.value
                val text = "Temp: ${"%.1f".format(m.temperatureCelsius)}°C | RAM: ${m.usedRamMb}/${m.totalRamMb} MB"
                val now = System.currentTimeMillis()
                if (text != lastNotificationText && now - lastNotificationMs >= 5000L) {
                    updateNotification(text)
                    lastNotificationText = text
                    lastNotificationMs = now
                }
                delay(s.pollingIntervalMs)
            }
        }

        serviceScope.launch {
            HardwareRepository.settings.collectLatest { settings ->
                if (settings.isOverlayVisible && Settings.canDrawOverlays(this@MonitorOverlayService)) {
                    showOverlay()
                } else {
                    removeOverlay()
                }
            }
        }
    }

    private fun showOverlay() {
        if (composeView != null) return

        val density = resources.displayMetrics.density
        val initialSettings = HardwareRepository.settings.value

        overlayLayoutParams = WindowManager.LayoutParams(
            (initialSettings.overlayWidthDp * density).roundToInt(),
            (initialSettings.overlayHeightDp * density).roundToInt(),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 48
            y = 160
        }

        lifecycleOwner = OverlayLifecycleOwner().apply { onCreate() }

        composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            setContent {
                val metrics by HardwareRepository.metrics.collectAsState()
                val settings by HardwareRepository.settings.collectAsState()

                LaunchedEffect(settings.overlayWidthDp, settings.overlayHeightDp) {
                    overlayLayoutParams.width = (settings.overlayWidthDp * density).roundToInt()
                    overlayLayoutParams.height = (settings.overlayHeightDp * density).roundToInt()
                    composeView?.let { windowManager.updateViewLayout(it, overlayLayoutParams) }
                }

                FloatingOverlayContent(
                    metrics = metrics,
                    settings = settings,
                    onMove = { dx, dy ->
                        overlayLayoutParams.x += dx.roundToInt()
                        overlayLayoutParams.y += dy.roundToInt()
                        composeView?.let { windowManager.updateViewLayout(it, overlayLayoutParams) }
                    },
                    onResize = { dw, dh ->
                        val newW = (settings.overlayWidthDp + (dw / density)).toInt().coerceIn(150, 420)
                        val newH = (settings.overlayHeightDp + (dh / density)).toInt().coerceIn(90, 380)
                        HardwareRepository.updateSettings {
                            it.copy(overlayWidthDp = newW, overlayHeightDp = newH)
                        }
                    },
                    onDismiss = {
                        HardwareRepository.updateSettings { it.copy(isOverlayVisible = false) }
                    }
                )
            }
        }

        windowManager.addView(composeView, overlayLayoutParams)
    }

    private fun removeOverlay() {
        composeView?.let {
            windowManager.removeView(it)
            lifecycleOwner?.onDestroy()
            composeView = null
            lifecycleOwner = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hardware Monitor Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(content: String): Notification {
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Temperature and RAM Reader")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .build()
    }

    private fun updateNotification(content: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(content))
    }

    override fun onDestroy() {
        HardwareRepository.stopFpsTracker()
        removeOverlay()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

@Composable
fun FloatingOverlayContent(
    metrics: HardwareMetrics,
    settings: OverlaySettings,
    onMove: (Float, Float) -> Unit,
    onResize: (Float, Float) -> Unit,
    onDismiss: () -> Unit
) {
    val tempColor = when (metrics.thermalStatus) {
        ThermalStatus.COLD -> Color(0xFF4CAF50)
        ThermalStatus.MEDIUM -> Color(0xFFFFC107)
        ThermalStatus.HOT -> Color(0xFFF44336)
    }
    val ramColor = if (metrics.isRamHigh) Color(0xFFF44336) else Color(0xFF4CAF50)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xD9121212))
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onMove(dragAmount.x, dragAmount.y)
                }
            }
            .padding(10.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "GAME HUD",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(20.dp)) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Overlay",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (settings.showFps) {
                val fpsColor = when {
                    metrics.currentFps >= 55 -> Color(0xFF4CAF50)
                    metrics.currentFps >= 30 -> Color(0xFFFFC107)
                    else -> Color(0xFFF44336)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "FPS: ${metrics.currentFps}",
                        color = fpsColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "${metrics.displayHz} Hz",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            if (settings.displayMode == DisplayMode.BOTH || settings.displayMode == DisplayMode.TEMP_ONLY) {
                Text(
                    text = "Temp: ${"%.1f".format(metrics.temperatureCelsius)}°C",
                    color = tempColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (settings.visualizationType == VisualizationType.BAR) {
                    LinearProgressIndicator(
                        progress = { (metrics.temperatureCelsius / 85f).coerceIn(0f, 1f) },
                        color = tempColor,
                        trackColor = Color.DarkGray,
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                    )
                } else {
                    RealTimeLineGraph(
                        dataPoints = metrics.tempHistory,
                        minVal = 20f,
                        maxVal = 85f,
                        lineColor = tempColor,
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            if (settings.displayMode == DisplayMode.BOTH || settings.displayMode == DisplayMode.RAM_ONLY) {
                Text(
                    text = "RAM: ${metrics.usedRamMb}/${metrics.totalRamMb} MB",
                    color = ramColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (settings.visualizationType == VisualizationType.BAR) {
                    LinearProgressIndicator(
                        progress = { metrics.ramUsageFraction },
                        color = ramColor,
                        trackColor = Color.DarkGray,
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                    )
                } else {
                    RealTimeLineGraph(
                        dataPoints = metrics.ramPercentHistory,
                        minVal = 0f,
                        maxVal = 100f,
                        lineColor = ramColor,
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(20.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onResize(dragAmount.x, dragAmount.y)
                    }
                }
        ) {
            Text(
                text = "◢",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.BottomEnd)
            )
        }
    }
}

@Composable
fun RealTimeLineGraph(
    dataPoints: List<Float>,
    minVal: Float,
    maxVal: Float,
    lineColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.padding(vertical = 2.dp)) {
        if (dataPoints.size < 2) return@Canvas
        val path = Path()
        val range = (maxVal - minVal).coerceAtLeast(1f)
        val stepX = size.width / (dataPoints.size - 1).coerceAtLeast(1)

        dataPoints.forEachIndexed { index, value ->
            val normalizedY = ((value - minVal) / range).coerceIn(0f, 1f)
            val x = index * stepX
            val y = size.height - (normalizedY * size.height)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(path = path, color = lineColor, style = Stroke(width = 2.dp.toPx()))
    }
}
