package com.example.tempramreader.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_heat_samples")
data class AppHeatEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestamp: Long,
    val packageName: String,
    val appName: String,
    val temperatureCelsius: Float,
    val sensorType: String
)
