package com.example.tempramreader.data

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.view.Choreographer
import android.view.Display
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/** How often an App-Heat sample is written to the DB. AppHeatDao's duration maths uses the same 5 s. */
const val HEAT_SAMPLE_INTERVAL_MS = 5_000L
private const val HEAT_RETENTION_MS = 7L * 24 * 60 * 60 * 1000 // keep 7 days of samples
private const val PRUNE_INTERVAL_MS = 60L * 60 * 1000

object HardwareRepository {
    private val _metrics = MutableStateFlow(HardwareMetrics())
    val metrics: StateFlow<HardwareMetrics> = _metrics.asStateFlow()

    private val _settings = MutableStateFlow(OverlaySettings())
    val settings: StateFlow<OverlaySettings> = _settings.asStateFlow()

    private val _hasShownFallbackDialog = MutableStateFlow(false)
    val hasShownFallbackDialog: StateFlow<Boolean> = _hasShownFallbackDialog.asStateFlow()

    /** True while MainActivity is on screen. The FPS tracker only runs when something can actually show it. */
    private val _uiVisible = MutableStateFlow(false)
    val uiVisible: StateFlow<Boolean> = _uiVisible.asStateFlow()

    // ---------------- FPS tracker ----------------
    private var frameCount = 0
    private var lastFpsTimestampNanos = 0L
    private var isFpsTracking = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isFpsTracking) return

            if (lastFpsTimestampNanos == 0L) {
                // First frame only sets the reference point.
                lastFpsTimestampNanos = frameTimeNanos
                frameCount = 0
            } else {
                frameCount++
                val elapsedNanos = frameTimeNanos - lastFpsTimestampNanos
                if (elapsedNanos >= 1_000_000_000L) {
                    // Round instead of truncating (119.9 used to show as 119).
                    val fps = (frameCount * 1_000_000_000.0 / elapsedNanos).roundToInt()
                    _metrics.update { current ->
                        val clamped = fps.coerceIn(1, current.displayHz.coerceAtLeast(1))
                        current.copy(
                            currentFps = clamped,
                            fpsHistory = (current.fpsHistory + clamped.toFloat()).takeLast(30)
                        )
                    }
                    frameCount = 0
                    lastFpsTimestampNanos = frameTimeNanos
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    // Must be called on the main thread.
    fun startFpsTracker() {
        if (isFpsTracking) return
        isFpsTracking = true
        frameCount = 0
        lastFpsTimestampNanos = 0L
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    fun stopFpsTracker() {
        if (!isFpsTracking) return
        isFpsTracking = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    // ---------------- State setters ----------------
    fun updateSettings(transform: (OverlaySettings) -> OverlaySettings) {
        _settings.update(transform)
    }

    fun markFallbackDialogShown() {
        _hasShownFallbackDialog.value = true
    }

    fun setUiVisible(visible: Boolean) {
        _uiVisible.value = visible
    }

    // ---------------- Polling ----------------
    private var lastHeatLogMs = 0L
    private var lastPruneMs = 0L

    suspend fun pollHardware(context: Context) = withContext(Dispatchers.IO) {
        val (temp, isFallback) = readTemperature(context)
        val (totalMb, usedMb, freeMb) = readRam(context)
        val hz = readDisplayRefreshRate(context)

        // Update the UI first so the DB / usage-stats work below never delays it.
        _metrics.update { current ->
            val ramPct = (usedMb.toFloat() / totalMb.coerceAtLeast(1L)) * 100f
            current.copy(
                temperatureCelsius = temp,
                isBatteryFallback = isFallback,
                totalRamMb = totalMb,
                usedRamMb = usedMb,
                freeRamMb = freeMb,
                displayHz = hz,
                tempHistory = (current.tempHistory + temp).takeLast(30),
                ramPercentHistory = (current.ramPercentHistory + ramPct).takeLast(30)
            )
        }

        logHeatSample(context, temp, isFallback)
    }

    private suspend fun logHeatSample(context: Context, temp: Float, isFallback: Boolean) {
        val now = System.currentTimeMillis()
        if (now - lastHeatLogMs < HEAT_SAMPLE_INTERVAL_MS) return
        lastHeatLogMs = now

        try {
            val (pkg, appName) = ForegroundAppDetector.getForegroundApp(context)
            // Don't pollute the ranking with "no permission" rows or with our own dashboard.
            if (pkg == ForegroundAppDetector.NO_PERMISSION || pkg == context.packageName) return

            val dao = AppHeatDatabase.getDatabase(context).appHeatDao()
            dao.insertSample(
                AppHeatEntity(
                    timestamp = now,
                    packageName = pkg,
                    appName = appName,
                    temperatureCelsius = temp,
                    sensorType = if (isFallback) "Battery Sensor" else "SoC / CPU Thermal Zone"
                )
            )

            if (now - lastPruneMs > PRUNE_INTERVAL_MS) {
                lastPruneMs = now
                dao.deleteOlderThan(now - HEAT_RETENTION_MS)
            }
        } catch (_: Exception) {
        }
    }

    private fun readDisplayRefreshRate(context: Context): Int {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        return display?.refreshRate?.roundToInt() ?: 60
    }

    // ---------------- Temperature ----------------
    private fun normalizeTemp(raw: Float): Float =
        if (raw > 1000f) raw / 1000f else if (raw > 200f) raw / 10f else raw

    // Source 1: sysfs (only works if the ROM lets apps read it)
    private var sysfsRetryAtMs = 0L

    private fun readSysfsZones(): Map<String, Float> {
        val readings = LinkedHashMap<String, Float>()
        for (root in listOf(File("/sys/class/thermal"), File("/sys/devices/virtual/thermal"))) {
            val zones = try {
                root.listFiles { f -> f.name.startsWith("thermal_zone") }
            } catch (_: Exception) {
                null
            } ?: continue
            for (zone in zones) {
                try {
                    val type = File(zone, "type").readText().trim().lowercase()
                    val raw = File(zone, "temp").readText().trim().toFloatOrNull() ?: continue
                    val t = normalizeTemp(raw)
                    if (t in 15f..120f) readings[type] = t
                } catch (_: Exception) {
                }
            }
            if (readings.isNotEmpty()) break
        }
        return readings
    }

    // Source 2: `dumpsys thermalservice` (needs: adb shell pm grant <pkg> android.permission.DUMP)
    private val dumpsysRegex =
        Regex("""Temperature\{mValue=(-?[\d.]+),\s*mType=(\d+),\s*mName=([^,]+),""")
    private var dumpsysCache: Map<String, Float> = emptyMap()
    private var dumpsysAtMs = 0L

    private fun readDumpsysZones(): Map<String, Float> {
        val now = System.currentTimeMillis()
        // Spawning a process is costly: reuse the last result for 2 s (30 s after a failure).
        val ttl = if (dumpsysCache.isEmpty()) 30_000L else 2_000L
        if (now - dumpsysAtMs < ttl) return dumpsysCache
        dumpsysAtMs = now

        val readings = LinkedHashMap<String, Float>()
        var proc: Process? = null
        try {
            proc = ProcessBuilder("dumpsys", "thermalservice").redirectErrorStream(true).start()
            val out = proc.inputStream.bufferedReader().use { it.readText() }
            val section = out.substringAfter("Current temperatures from HAL:", out)
            dumpsysRegex.findAll(section).forEach { m ->
                val v = m.groupValues[1].toFloatOrNull() ?: return@forEach
                val name = m.groupValues[3].trim().lowercase()
                if (v in 15f..120f) readings[name] = v
            }
        } catch (_: Exception) {
        } finally {
            proc?.destroy()
        }
        dumpsysCache = readings
        return readings
    }

    private fun pickSocTemp(readings: Map<String, Float>): Float? {
        if (readings.isEmpty()) return null
        readings["soc_max"]?.let { return it }
        val cpu = readings.filterKeys { it.startsWith("cpu") || it.contains("mtktscpu") }.values
        if (cpu.isNotEmpty()) return cpu.max()
        val soc = readings.filterKeys {
            it.contains("soc") || it.contains("tsens") || it.contains("xo_therm") || it.startsWith("ap")
        }.values
        if (soc.isNotEmpty()) return soc.average().toFloat()
        return null
    }

    private fun readTemperature(context: Context): Pair<Float, Boolean> {
        val now = System.currentTimeMillis()

        // If sysfs is blocked, only re-check once a minute instead of every tick.
        if (now >= sysfsRetryAtMs) {
            val zones = readSysfsZones()
            if (zones.isEmpty()) sysfsRetryAtMs = now + 60_000L
            pickSocTemp(zones)?.let { return Pair(it, false) }
        }

        // Only try dumpsys when the permission was actually granted.
        if (context.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED) {
            pickSocTemp(readDumpsysZones())?.let { return Pair(it, false) }
        }

        // Fallback: battery temperature
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawBatteryTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        return Pair(rawBatteryTemp / 10f, true)
    }

    // ---------------- RAM ----------------
    private fun readRam(context: Context): Triple<Long, Long, Long> {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val totalMb = memoryInfo.totalMem / (1024 * 1024)
        val freeMb = memoryInfo.availMem / (1024 * 1024)
        val usedMb = totalMb - freeMb
        return Triple(totalMb, usedMb, freeMb)
    }
}
